﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.ApplicationBlocks.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Net.Mail;
using System.Net;
using iTextSharp.text;
using System.IO;
using iTextSharp.text.pdf;
using System.Data.SqlClient;
using System.Configuration;
using ClosedXML.Excel;
using System.Data;
using System.Threading;
using DocumentFormat.OpenXml.Spreadsheet;

public partial class AdminPannel_CurrentInvoice : System.Web.UI.Page
{
    List<string> FinalFileList = new List<string>();
    List<string> excelFileList = new List<string>();
    DataSet excelDs = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            BindReportMonthYear();
            BindCustomer();
            TBInvDate.Text = "";
            TBInvID.Text = "";
            TBDOB.Text = "";
            TBAdmissionDate.Text = "";
            gvjob.DataSource = null;
            gvjob.DataBind();
        }

    }

    #region binders
    private void BindReportMonthYear()
    {
        try
        {
            //  TBYear.Text = DateTime.Now.Year.ToString();
            //DDLYear.SelectedValue = "0";
            //DDLMonth.SelectedValue = "0";
            //DDLMonth.Enabled = false;
            //TBYear.Enabled = false;
        }
        catch (Exception ex)
        { }
    }

    private void BindCustomer()
    {
        try
        {
            string Qry = "SELECT code, CONVERT(NVARCHAR, code) + ' - ' + Name + ' ( ' + Altercode + ' )' As Customer FROM Acm WHERE Status <> '*' AND Slcd='CL' Order By code";
            DataSet ds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DDLCustomer.DataSource = ds.Tables[0];
                DDLCustomer.DataTextField = "Customer";
                DDLCustomer.DataValueField = "code";
                DDLCustomer.DataBind();
                DDLCustomer.Items.Insert(0, new System.Web.UI.WebControls.ListItem("--SELECT--", "0"));
            }
        }
        catch (Exception ex)
        { }
    }

    private void BindGridData(string session)
    {
        // mp1.Show();
        try
        {
            string Qry = "";
            DataSet ds = null;
            switch (session)
            {
                case "INV":
                    {
                        Qry = "select a.vno as 'Invoice',a.acno as 'Customer ID',c.name as 'Customer Name',CONVERT(NVARCHAR,CONVERT(varchar,a.vdt,105) )+'-' +CONVERT(NVARCHAR,a.mTime)   as 'Date'  From Salepurchase1 a,billtrackdet b,ACM c  where a.acno = c.code and  a.Vno = '" + TBInvID.Text + "'and  b.Srl=2 and b.SubSrl in (6,7) and a.Vno = b.Vno and a.Vdt = b.Vdt and cast(b.SubSrl as int) !=1  order by a.vdt  desc "; //and DATEPART(YEAR,a.Vdt) = DATEPART(YEAR,GETDATE())
                        ds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
                        btn_InvForCustomer.Visible = false;
                        btn_InvForCustomer.Text = "Send  Invoice To Customer  ";
                    }
                    break;
                case "DATE":
                    {

                        Qry = "select a.vno as 'Invoice',a.acno as 'Customer ID',c.name as 'Customer Name',CONVERT(NVARCHAR,CONVERT(varchar,a.vdt,105) )+'-' +CONVERT(NVARCHAR,a.mTime) as  'Date' From Salepurchase1 a,billtrackdet b,ACM c  where a.acno = c.code  AND  a.Vdt = CONVERT(Date,'" + TBInvDate.Text + "',103)  and  b.Srl=2 and b.SubSrl in (6,7) and a.Vno = b.Vno and a.Vdt = b.Vdt and cast(b.SubSrl as int) !=1 order by a.vdt  desc ";//and DATEPART(YEAR,a.Vdt) = DATEPART(YEAR,GETDATE())";
                        ds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
                        Session["DateInv"] = ds;
                        btn_InvForCustomer.Visible = true;
                        btn_InvForCustomer.Text = "Send All Invoice To Customer for  Date" + TBInvDate.Text;
                        break;
                    }
                case "CUST":
                    {
                        Qry = "select a.vno as 'Invoice',a.acno as 'Customer ID',c.name as 'Customer Name',CONVERT(NVARCHAR,CONVERT(varchar,a.vdt,105))+'-' +CONVERT(NVARCHAR,a.mTime) as  'Date' From Salepurchase1 a,billtrackdet b, ACM c  where a.acno = c.code  AND a.Vdt BETWEEN CONVERT(datetime,'" + TBDOB.Text + "',103) AND CONVERT(datetime,'" + TBAdmissionDate.Text + "',103)  and a.acno = '" + DDLCustomer.SelectedValue + "' and   b.Srl=2 and b.SubSrl in (6,7) and a.Vno = b.Vno and a.Vdt = b.Vdt and cast(b.SubSrl as int) !=1  order by a.vdt,a.vno,a.acno desc ";
                        ds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
                        Session["CustInv"] = ds;
                        btn_InvForCustomer.Visible = true;
                        btn_InvForCustomer.Text = "Send All Invoice To Customer for Date between " + TBDOB.Text + "and" + TBAdmissionDate.Text;
                        break;
                    }
                case "DATERANGE":
                    {
                        Qry = "select a.vno as 'Invoice',a.acno as 'Customer ID',c.name as 'Customer Name',CONVERT(NVARCHAR,CONVERT(varchar,a.vdt,105) )+'-' +CONVERT(NVARCHAR,a.mTime) as  'Date' From Salepurchase1 a,billtrackdet b, ACM c  where a.acno = c.code  AND a.Vdt BETWEEN CONVERT(datetime,'" + TBDOB.Text + "',103) AND CONVERT(datetime,'" + TBAdmissionDate.Text + "',103)  and   b.Srl=2 and b.SubSrl in (6,7) and a.Vno = b.Vno and a.Vdt = b.Vdt and cast(b.SubSrl as int) !=1  order by a.vdt,a.vno,a.acno desc ";
                        ds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
                        Session["DateRangeInv"] = ds;
                        btn_InvForCustomer.Visible = true;
                        btn_InvForCustomer.Text = "Send All Invoice To Customer for Date between " + TBDOB.Text + "and" + TBAdmissionDate.Text;
                        break;
                    }
                default:
                    //Qry = "select a.Vno as 'Invoice NO.',a.Vdt as 'Invoice Date' from BillTrackDet a where CONVERT(datetime, CONVERT(datetime, a.ScanDt, 5) + ' ' + a.mTime, 105) >DATEADD(MINUTE, -" + lastMinuts + ", GETDATE()) and Srl=2 and SubSrl=7";
                    break;
            }

            if (ds.Tables[0].Rows.Count > 0)
            {

                lbl_count.Text = "Total Count:" + ds.Tables[0].Rows.Count;
                gvjob.DataSource = ds.Tables[0];
                gvjob.DataBind();
            }
            else
            {
                gvjob.DataSource = new DataTable();
                gvjob.DataBind();
                gvjob.EmptyDataText = "No Record Found!";
                btn_InvForCustomer.Visible = false;
            }
        }
        catch (Exception ex)
        { }

    }

    #endregion

    #region gridcontrol
    protected void gvjob_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        // mp1.Show();
        try
        {
            gvjob.PageIndex = e.NewPageIndex;
            BindGridData(Session["SEARCH"].ToString());
            gvjob.DataBind();
        }
        catch (Exception ex)
        { }
    }

    protected void gbjob_rowcommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {

            #region code
            string timestm = "";
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            string VnoID = commandArgs[0];
            string AcnoID = commandArgs[1];
            string[] vdt = commandArgs[1].Split(new char[] { '-' });

            string acno = "";
            string qryacno = "select Acno,Vno,Vdt from Salepurchase1  where  vno = '" + Convert.ToInt64(VnoID) + "' and Vdt= '" + vdt[2] + "-" + vdt[1] + "-" + vdt[0] + "'";
            string CustAcnoID = "-1";
            DataSet dsacno = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, qryacno);
            if (dsacno.Tables[0].Rows.Count > 0)
            {
                CustAcnoID = dsacno.Tables[0].Rows[0]["Acno"].ToString();
                acno = dsacno.Tables[0].Rows[0]["Vdt"].ToString();
            }
            DataTable dst = GetCustomer(Convert.ToInt16(CustAcnoID));
            string cname = dst.Rows[0]["Name"].ToString();
            string excel = GetExcelFile(Convert.ToInt32(VnoID), acno);
            timestm = GetpdfFile(Convert.ToInt32(VnoID), acno);
            string pdfpath = Server.MapPath("~/InvRpts/" + "Invoice-" + cname + "(" + VnoID + "_" + timestm + ").pdf");
            #endregion


            if (e.CommandName == "MailRecord")
            {

                SendEmailwithAttachment(VnoID, CustAcnoID, pdfpath, "Invoice-" + cname + "(" + VnoID + "_" + timestm + ").pdf", excel, null);
            }


            if (e.CommandName == "Download")
            {
                try
                {
                    FileInfo file = new FileInfo(pdfpath);
                    if (file.Exists)
                    {
                        Response.Clear();
                        Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
                        Response.AddHeader("Content-Length", file.Length.ToString());
                        Response.ContentType = "text/pdf";
                        Response.Flush();
                        Response.TransmitFile(file.FullName);
                        Response.End();
                        string script = "<script>alert('File Download Success !!')</script>";
                        ClientScript.RegisterStartupScript(this.GetType(), "maildownSent", script);
                    }
                    else
                    {

                        string script = "<script>alert('Download USuccessfully')</script>";
                        ClientScript.RegisterStartupScript(this.GetType(), "maildownSent", script);
                    }

                }
                catch (Exception viewe)
                {
                    Errlbl.Text = viewe.Message.ToString() + "ROW CMD FILE DOWNLOAD ";
                    viewe.Message.ToString();
                }
            }

        }
        catch (Exception ex)
        {
            Errlbl.Text = ex.Message + "ROW COMMAND TRY";
        }
    }
    #endregion

    #region PDf


    private string GetpdfFile(int VnoID, string AcnoID)
    {
        string timestamp = "";
        #region Generate Sale Return PDf

        DataTable DTForInvoice = new DataTable();
        if (DTForInvoice.Columns.Count == 0)
        {
            DTForInvoice.Columns.Add("Sr", typeof(int));
            DTForInvoice.Columns.Add("QTY", typeof(string));
            DTForInvoice.Columns.Add("SDIS%", typeof(string));
            DTForInvoice.Columns.Add("PACK", typeof(string));
            DTForInvoice.Columns.Add("PARTICULARS", typeof(string));
            DTForInvoice.Columns.Add("Mfg", typeof(string));
            DTForInvoice.Columns.Add("HSN CODE", typeof(string));
            DTForInvoice.Columns.Add("Batch No", typeof(string));
            DTForInvoice.Columns.Add("Exp", typeof(string));
            DTForInvoice.Columns.Add("MRP", typeof(decimal));
            DTForInvoice.Columns.Add("Rate", typeof(decimal));
            DTForInvoice.Columns.Add("DIS%", typeof(decimal));
            DTForInvoice.Columns.Add("GST%", typeof(decimal));
            DTForInvoice.Columns.Add("Amount", typeof(decimal));
        }

        decimal GST28_GrossAmt = 0, GST28_Scm = 0, GST28_DisAmt = 0, GST28_Taxable = 0, GST28_CGSTAmt = 0, GST28_IGSTAmt = 0;
        decimal GST18_GrossAmt = 0, GST18_Scm = 0, GST18_DisAmt = 0, GST18_Taxable = 0, GST18_CGSTAmt = 0, GST18_IGSTAmt = 0;
        decimal GST12_GrossAmt = 0, GST12_Scm = 0, GST12_DisAmt = 0, GST12_Taxable = 0, GST12_CGSTAmt = 0, GST12_IGSTAmt = 0;
        decimal GST5_GrossAmt = 0, GST5_Scm = 0, GST5_DisAmt = 0, GST5_Taxable = 0, GST5_CGSTAmt = 0, GST5_IGSTAmt = 0;
        decimal GST0_GrossAmt = 0, GST0_Scm = 0, GST0_DisAmt = 0, GST0_Taxable = 0, GST0_CGSTAmt = 0, GST0_IGSTAmt = 0;
        decimal T_GrossAmt = 0, T_Scm = 0, T_DisAmt = 0, T_Taxable = 0, T_CGSTAmt = 0, T_IGSTAmt = 0;


        SqlParameter[] array = new SqlParameter[2];
        //  VnoID = 45870; AcnoID = "15-Sep-20 00:00:00";
        array[0] = new SqlParameter("@Vno", VnoID);
        array[1] = new SqlParameter("@Vdt", AcnoID);
        DataSet DSP = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.StoredProcedure, "fetchTaxInvoice", array);

        int Totqyt = 0;
        if (DSP.Tables[0].Rows.Count > 0)
        {

            for (int i = 0; i < DSP.Tables[0].Rows.Count; i++)
            {

                //compare and put dictinory 

                string QItemINSR = "SELECT * FROM Item WHERE code='" + DSP.Tables[0].Rows[i]["Itemc"] + "'";
                DataSet DSItemInSR = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QItemINSR);
                if (DSItemInSR.Tables[0].Rows.Count > 0)
                {
                    string pack = "", expiry = "";
                    if (!string.IsNullOrEmpty(DSP.Tables[0].Rows[i]["Pack"].ToString()))
                    { pack = DSP.Tables[0].Rows[i]["Pack"].ToString(); }
                    else
                    { pack = ""; }

                    if (!string.IsNullOrEmpty(DSP.Tables[0].Rows[i]["expiry"].ToString()))
                    {
                        expiry = DSP.Tables[0].Rows[i]["expiry"].ToString();
                    }
                    else
                    {
                        expiry = "";
                    }

                    string[] qty = DSP.Tables[0].Rows[i]["totQty"].ToString().Split('.');

                    Totqyt += Convert.ToInt32(qty[0]);
                    DTForInvoice.Rows.Add(i + 1,
                                        qty[0],
                                        DSP.Tables[0].Rows[i]["S.DIS%"].ToString(),
                                        pack,
                                        DSP.Tables[0].Rows[i]["Particulars"].ToString(),
                                        DSP.Tables[0].Rows[i]["MFG"].ToString(),
                                        DSP.Tables[0].Rows[i]["HSNCode"].ToString(),
                                        DSP.Tables[0].Rows[i]["Batch"],
                                        expiry,
                                        DSP.Tables[0].Rows[i]["Mrp"].ToString(),
                                         DSP.Tables[0].Rows[i]["Rate"].ToString(),
                                        DSP.Tables[0].Rows[i]["DIS%"].ToString(),
                                        DSP.Tables[0].Rows[i]["GST"].ToString(),
                                        DSP.Tables[0].Rows[i]["TotGrossAmt"].ToString());

                    decimal Qty, Rate, GA, SCM, DA, Taxable, CGST, IGST, SGST;
                    switch (DSP.Tables[0].Rows[i]["GST"].ToString())
                    {
                        case "28.00":
                            Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totQty"].ToString());
                            Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Rate"].ToString());
                            GA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["TotGrossAmt"].ToString());    //Qty * Rate;
                            SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["SchemeAmt"].ToString());//ScmAmt
                            DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totdisQty"].ToString());
                            Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totalNet"].ToString());//**
                            IGST = Convert.ToDecimal("0.00");
                            CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totCGST"].ToString());
                            SGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totSGST"].ToString());

                            GST28_GrossAmt += GA;
                            GST28_Scm += SCM;
                            GST28_DisAmt += DA;
                            GST28_Taxable += Taxable;
                            GST28_CGSTAmt += CGST;
                            GST28_IGSTAmt += IGST;
                            break;
                        case "18.00":
                            Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totQty"].ToString());
                            Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Rate"].ToString());
                            GA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["TotGrossAmt"].ToString());    //Qty * Rate;
                            SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["SchemeAmt"].ToString());//ScmAmt
                            DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totdisQty"].ToString());
                            Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totalNet"].ToString());//**
                            IGST = Convert.ToDecimal("0.00");
                            CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totCGST"].ToString());
                            SGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totSGST"].ToString());

                            GST18_GrossAmt += GA;
                            GST18_Scm += SCM;
                            GST18_DisAmt += DA;
                            GST18_Taxable += Taxable;
                            GST18_CGSTAmt += CGST;
                            GST18_IGSTAmt += IGST;
                            break;
                        case "12.00":
                            Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totQty"].ToString());
                            Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Rate"].ToString());
                            GA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["TotGrossAmt"].ToString());    //Qty * Rate;
                            SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["SchemeAmt"].ToString());//ScmAmt
                            DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totdisQty"].ToString());
                            Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totalNet"].ToString());//**
                            IGST = Convert.ToDecimal("0.00");
                            CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totCGST"].ToString());
                            SGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totSGST"].ToString());

                            GST12_GrossAmt += GA;
                            GST12_Scm += SCM;
                            GST12_DisAmt += DA;
                            GST12_Taxable += Taxable;
                            GST12_CGSTAmt += CGST;
                            GST12_IGSTAmt += IGST;
                            break;
                        case "5.00":
                            Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totQty"].ToString());
                            Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Rate"].ToString());
                            GA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["TotGrossAmt"].ToString());    //Qty * Rate;
                            SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["SchemeAmt"].ToString());//ScmAmt
                            DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totdisQty"].ToString());
                            Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totalNet"].ToString());//**
                            IGST = Convert.ToDecimal("0.00");
                            CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totCGST"].ToString());
                            SGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totSGST"].ToString());

                            GST5_GrossAmt += GA;
                            GST5_Scm += SCM;
                            GST5_DisAmt += DA;
                            GST5_Taxable += Taxable;
                            GST5_CGSTAmt += CGST;
                            GST5_IGSTAmt += IGST;
                            break;
                        case "0.00":
                            Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totQty"].ToString());
                            Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Rate"].ToString());
                            GA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["TotGrossAmt"].ToString());    //Qty * Rate;
                            SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["SchemeAmt"].ToString());//ScmAmt
                            DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totdisQty"].ToString());
                            Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totalNet"].ToString());//**
                            IGST = Convert.ToDecimal("0.00");
                            CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totCGST"].ToString());
                            SGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["totSGST"].ToString());

                            GST0_GrossAmt += GA;
                            GST0_Scm += SCM;
                            GST0_DisAmt += DA;
                            GST0_Taxable += Taxable;
                            GST0_CGSTAmt += CGST;
                            GST0_IGSTAmt += IGST;
                            break;
                        default:
                            break;
                    }
                }
            }


            T_GrossAmt = GST28_GrossAmt + GST18_GrossAmt + GST12_GrossAmt + GST5_GrossAmt + GST0_GrossAmt;
            T_Scm = GST28_Scm + GST18_Scm + GST12_Scm + GST5_Scm + GST0_Scm;
            T_DisAmt = GST28_DisAmt + GST18_DisAmt + GST12_DisAmt + GST5_DisAmt + GST0_DisAmt;
            T_Taxable = GST28_Taxable + GST18_Taxable + GST12_Taxable + GST5_Taxable + GST0_Taxable;
            T_CGSTAmt = GST28_CGSTAmt + GST18_CGSTAmt + GST12_CGSTAmt + GST5_CGSTAmt + GST0_CGSTAmt;
            T_IGSTAmt = GST28_IGSTAmt + GST18_IGSTAmt + GST12_IGSTAmt + GST5_IGSTAmt + GST0_IGSTAmt;
        #endregion
            ReportDocument crystalReportSR = new ReportDocument(); // creating object of crystal report
            crystalReportSR.Load(Server.MapPath("~/CryRpts/DemoInvoice.rpt")); // path of report 
            DataSet DSSR = new DataSet();
            crystalReportSR.SetDataSource(DTForInvoice); // binding dataSet
            crystalReportSR.SetParameterValue("MadeBy", DSP.Tables[0].Rows[0]["Uid"].ToString());
            crystalReportSR.SetParameterValue("MakeTime", DSP.Tables[0].Rows[0]["MakeTime"].ToString());

            #region Bind Company Info
            DataTable DTControl11 = GetCompany();
            if (DTControl11.Rows.Count > 0)
            {
                crystalReportSR.SetParameterValue("pCompanyName", DTControl11.Rows[0]["Compname1"].ToString());
                crystalReportSR.SetParameterValue("pCompAdd1", DTControl11.Rows[0]["Address"].ToString());
                crystalReportSR.SetParameterValue("pCompAdd2", DTControl11.Rows[0]["Address1"].ToString());
                crystalReportSR.SetParameterValue("pTelno", DTControl11.Rows[0]["Tel"].ToString());
                crystalReportSR.SetParameterValue("pGSTNo", "GST No. : " + DTControl11.Rows[0]["GSTNo"].ToString());
                crystalReportSR.SetParameterValue("pCompStateCode", "State Code : " + DTControl11.Rows[0]["StateCode"].ToString());
                crystalReportSR.SetParameterValue("pDLno", "DL No. : " + DTControl11.Rows[0]["Dlno"].ToString());
                crystalReportSR.SetParameterValue("pCompCIN", "CIN : " + DTControl11.Rows[0]["CINNO"].ToString());
                crystalReportSR.SetParameterValue("pCompEmail", "E mail : " + DTControl11.Rows[0]["Email"].ToString());
                crystalReportSR.SetParameterValue("pFASSAI", "FSSAI No. : " + DTControl11.Rows[0]["FoodLicNo"].ToString());
            }
            #endregion

            #region DT For Customer
            DataTable DTControl2 = GetCustomer(Convert.ToInt32(DSP.Tables[0].Rows[0]["custid"].ToString()));
            string cname = "customer";
            if (DTControl2.Rows.Count > 0)
            {
                cname = DTControl2.Rows[0]["Name"].ToString();
                //   crystalReportSR.SetParameterValue("Date", ":" + DateTime.Now.ToString("dd/MM/yyyy"));
                crystalReportSR.SetParameterValue("pCode", "<" + DSP.Tables[0].Rows[0]["custid"].ToString() + ">");
                crystalReportSR.SetParameterValue("PName", DTControl2.Rows[0]["Name"].ToString());
                crystalReportSR.SetParameterValue("address1", DTControl2.Rows[0]["address"].ToString());
                crystalReportSR.SetParameterValue("address2", DTControl2.Rows[0]["address1"].ToString());
                crystalReportSR.SetParameterValue("address3", DTControl2.Rows[0]["address2"].ToString());
                crystalReportSR.SetParameterValue("CustTel", "Tel. " + DTControl2.Rows[0]["telephone"].ToString() + "," + DTControl2.Rows[0]["telephone1"].ToString());
                crystalReportSR.SetParameterValue("CUstStateCode", "State Code : " + DTControl2.Rows[0]["StateCode"].ToString());
                crystalReportSR.SetParameterValue("mInvNo", DSP.Tables[0].Rows[0]["Bill NO."]); //"MNN/19-20/ " + VnoID
                crystalReportSR.SetParameterValue("vdt", DSP.Tables[0].Rows[0]["date"].ToString());  //Convert.ToDateTime(DSP.Tables[0].Rows[0]["date"]).ToString("dd/MM/yyyy")
                crystalReportSR.SetParameterValue("CustGST", DTControl2.Rows[0]["GSTNo"].ToString());
                if (DTControl2.Rows[0]["DLNo"].ToString().Equals(DTControl2.Rows[0]["DLNO1"].ToString()))
                {
                    crystalReportSR.SetParameterValue("CustDLNo", DTControl2.Rows[0]["DLNo"].ToString());
                }
                else
                {
                    crystalReportSR.SetParameterValue("CustDLNo", DTControl2.Rows[0]["DLNo"].ToString() + "," + DTControl2.Rows[0]["DLNO1"].ToString());
                }
                //  crystalReportSR.SetParameterValue("CustFassaiNo", DTControl2.Rows[0]["PAN"].ToString());
                if (DTControl2.Rows[0]["GSTNo"].ToString().Length == 0)
                {
                    crystalReportSR.SetParameterValue("NOGSTNo.", "** NOT VALID FOR INPUT TAX **");
                }
                else
                {
                    crystalReportSR.SetParameterValue("NOGSTNo.", "** VALID FOR INPUT TAX **");
                }
            }
            #endregion

            #region OtherParameters

            crystalReportSR.SetParameterValue("TotGrossGST28", GST28_GrossAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotGrossGST18", GST18_GrossAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotGrossGST12", GST12_GrossAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotGrossGST5", GST5_GrossAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotGrossGSTFree", GST0_GrossAmt.ToString("0.00"));

            crystalReportSR.SetParameterValue("TotHsAmtGST28", GST28_Scm.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotHsAmtGST18", GST18_Scm.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotHsAmtGST12", GST12_Scm.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotHsAmtGST5", GST5_Scm.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotHsAmtGSTFree", GST0_Scm.ToString("0.00"));

            crystalReportSR.SetParameterValue("TotDisGST28", GST28_DisAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotDisGST18", GST18_DisAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotDisGST12", GST12_DisAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotDisGST5", GST5_DisAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotDisGSTFree", GST0_DisAmt.ToString("0.00"));


            crystalReportSR.SetParameterValue("TaxableGST28", GST28_Taxable.ToString("0.00"));
            crystalReportSR.SetParameterValue("TaxableGST18", GST18_Taxable.ToString("0.00"));
            crystalReportSR.SetParameterValue("TaxableGST12", GST12_Taxable.ToString("0.00"));
            crystalReportSR.SetParameterValue("TaxableGST5", GST5_Taxable.ToString("0.00"));
            crystalReportSR.SetParameterValue("TaxableGSTFree", GST0_Taxable.ToString("0.00"));


            crystalReportSR.SetParameterValue("TotCGST28", GST28_CGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotCGST18", GST18_CGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotCGST12", GST12_CGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotCGST5", GST5_CGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotCGSTFree", GST0_CGSTAmt.ToString("0.00"));


            crystalReportSR.SetParameterValue("TotSGST28", GST28_CGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotSGST18", GST18_CGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotSGST12", GST12_CGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotSGST5", GST5_CGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotSGSTFree", GST0_CGSTAmt.ToString("0.00"));


            crystalReportSR.SetParameterValue("TotIGST28", GST28_IGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotIGST18", GST18_IGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotIGST12", GST12_IGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotIGST5", GST5_IGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("TotIGSTFree", GST0_IGSTAmt.ToString("0.00"));


            crystalReportSR.SetParameterValue("T_GrossAmt", T_GrossAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("T_Scm", T_Scm.ToString("0.00"));
            crystalReportSR.SetParameterValue("T_DisAmt", T_DisAmt.ToString("0.00"));//T_Disamt DSP.Tables[0].Rows[0]["totDiscount"].ToString()
            crystalReportSR.SetParameterValue("T_Taxable", T_Taxable.ToString("0.00"));
            crystalReportSR.SetParameterValue("T_SGST", T_CGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("T_CGSTAmt", T_CGSTAmt.ToString("0.00"));
            crystalReportSR.SetParameterValue("T_IGSTAmt", T_IGSTAmt.ToString("0.00"));

            crystalReportSR.SetParameterValue("NoOfItems", DSP.Tables[0].Rows.Count.ToString());
            crystalReportSR.SetParameterValue("TotQty", Convert.ToString(Totqyt));
            string acno = DSP.Tables[0].Rows[0]["custid"].ToString();
            string QRy1 = "select acno,vdt, Vno,vtype, amt, dc, narr  from Trn where Vno='" + VnoID + "' AND Acno='" + Convert.ToInt32(DSP.Tables[0].Rows[0]["custid"].ToString()) + "' and CAST(vdt as DATE) = CAST('" + AcnoID + "' as DATE)  ";
            DataSet DSP1 = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy1);
            if (DSP1.Tables[0].Rows.Count > 0)
            {
                double tds = Convert.ToDouble(DSP1.Tables[0].Rows[0]["amt"].ToString()) * 0.075 / 100;
                double ntamt = Convert.ToDouble(DSP1.Tables[0].Rows[0]["amt"].ToString()) - tds;
                DataTable dtacm = GetCustomer(Convert.ToInt32(DSP.Tables[0].Rows[0]["custid"].ToString()));
                if (dtacm.Rows[0]["TCS"].ToString().Equals("Y"))
                {
                    crystalReportSR.SetParameterValue("TCS", "TCS% (0.075): " + tds.ToString("0.00"));
                    crystalReportSR.SetParameterValue("ntamt", "Net Amount: " + ntamt.ToString("0.00"));
                }
                else
                {
                    crystalReportSR.SetParameterValue("TCS", "");
                    crystalReportSR.SetParameterValue("ntamt", "Net Amount: " + DSP1.Tables[0].Rows[0]["amt"].ToString());
                }

                
                crystalReportSR.SetParameterValue("BillAmount", DSP1.Tables[0].Rows[0]["amt"].ToString());
                crystalReportSR.SetParameterValue("For", "For " + DTControl11.Rows[0]["Compname1"].ToString());
                crystalReportSR.SetParameterValue("Towards1", AmountInWord(DSP1.Tables[0].Rows[0]["amt"].ToString()));
            }


            //Term and Condition 
            crystalReportSR.SetParameterValue("INVF1", "All disputes are subject to G.B.NAGAR Jurisdiction. ");
            crystalReportSR.SetParameterValue("INVF2", "ORDER ONLINE AT  HTTPS://SHREEMARUTINANDAN.COM  24 HOURS (AVAIL ADDITIONAL  BENIFITS)");
            crystalReportSR.SetParameterValue("INVF3", "EXPIRY  WILL NOT BE  ENTERTAINED MORE THAN  3% "); //(9891500095,9990500094,97,98)   5555



            string QRy2 = "select BankName,BankAccount,IFSCCode,MICRCode from Control";
            DataSet DSP2 = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy2);
            if (DSP2.Tables[0].Rows.Count > 0)
            {
                crystalReportSR.SetParameterValue("BankName", "Bank Name:" + DSP2.Tables[0].Rows[0]["BankName"].ToString().Trim());
                crystalReportSR.SetParameterValue("BankAc", "Bank A/C:" + DSP2.Tables[0].Rows[0]["BankAccount"].ToString().Trim());
                crystalReportSR.SetParameterValue("IFSCCode", "IFSC Code:" + DSP2.Tables[0].Rows[0]["IFSCCode"].ToString().Trim());
                //crystalReportSR.SetParameterValue("MICR", DSP2.Tables[0].Rows[0]["MICRCode"].ToString());

                // DateTime datetime = new DateTime();

                crystalReportSR.SetParameterValue("PrintTime", DateTime.Now.ToString("h:mm tt"));
            }

            #endregion
            try
            {

                CrystalReportViewer.ReportSource = crystalReportSR;
                //var dateString1 = DateTime.Now.ToString("yyyyMMdd");
                timestamp = DateTime.Now.ToString("yyyyMMddHHmmssffff");
                string invpdfname = "Invoice-" + cname + "(" + VnoID + "_" + timestamp + ").pdf";
                string FilePathBE = Server.MapPath("~/InvRpts/" + "Invoice-" + cname + "(" + VnoID + "_" + timestamp + ").pdf");
                crystalReportSR.ExportToDisk(ExportFormatType.PortableDocFormat, FilePathBE);
                List<string> SRFileList = new List<string>();
                SRFileList.Add(FilePathBE);
                crystalReportSR.Dispose();
                FinalFileList.Add(FilePathBE);
                SaveStatementFileToServer(FilePathBE, acno);

            }
            catch (Exception excep)
            {
                Errlbl.Text = excep.Message;
            }
        }
        return timestamp;
    }
    #region PDF Merger
    public static void CombineMultiplePDFs(List<string> fileNames, string outFile)
    {
        try
        {
            // step 1: creation of a document-object
            Document document = new Document();
            //create newFileStream object which will be disposed at the end
            using (FileStream newFileStream = new FileStream(outFile, FileMode.Create))
            {
                // step 2: we create a writer that listens to the document
                PdfCopy writer = new PdfCopy(document, newFileStream);
                if (writer == null)
                {
                    return;
                }

                // step 3: we open the document
                document.Open();

                foreach (string fileName in fileNames)
                {
                    // we create a reader for a certain document
                    PdfReader reader = new PdfReader(fileName);
                    reader.ConsolidateNamedDestinations();

                    // step 4: we add content
                    for (int i = 1; i <= reader.NumberOfPages; i++)
                    {
                        PdfImportedPage page = writer.GetImportedPage(reader, i);
                        writer.AddPage(page);
                    }

                    PRAcroForm form = reader.AcroForm;
                    if (form != null)
                    {
                        writer.CopyAcroForm(reader);
                    }

                    reader.Close();
                }

                // step 5: we close the document and writer
                writer.Close();
                document.Close();
            }//disposes the newFileStream object
        }
        catch (Exception combinepdf)
        {
            combinepdf.Message.ToString();
        }
    }
    #endregion

    #endregion

    #region getMAster for Com and Cust
    private string[] GetCustDetails(string Acno)
    {
        string[] CustMail = new string[4];
        try
        {
            string GetCustMail = "SELECT Name,Email,code,mobile FROM Acm WHERE code='" + Acno + "'";
            DataSet DSCustMail = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, GetCustMail);
            if (DSCustMail.Tables[0].Rows.Count > 0)
            {
                CustMail[0] = DSCustMail.Tables[0].Rows[0]["Name"].ToString();
                CustMail[1] = DSCustMail.Tables[0].Rows[0]["Email"].ToString();
                CustMail[2] = DSCustMail.Tables[0].Rows[0]["Code"].ToString();
                CustMail[3] = DSCustMail.Tables[0].Rows[0]["mobile"].ToString();
            }
        }
        catch (Exception ex)
        { }
        return CustMail;
    }

    private DataTable GetCompany()
    {
        DataTable DTCompany = new DataTable();
        try
        {
            string Qry = "SELECT * FROM Control";
            DataSet DSData = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (DSData.Tables[0].Rows.Count > 0)
                DTCompany = DSData.Tables[0];
        }
        catch (Exception ex)
        {

        }
        return DTCompany;
    }

    private DataTable GetCustomer(int CustID)
    {
        DataTable DTCust = new DataTable();
        try
        {
            string Qry = "SELECT * FROM Acm WHERE code='" + CustID + "'";
            DataSet DSData = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (DSData.Tables[0].Rows.Count > 0)
                DTCust = DSData.Tables[0];
        }
        catch (Exception ex)
        {

        }
        return DTCust;
    }
    #endregion

    #region Helper Methods
    private string AmountInWord(string p)
    {
        string isNegative = "";
        string number = Convert.ToDouble(p).ToString();

        if (number.Contains("-"))
        {
            isNegative = "Minus ";
            number = number.Substring(1, number.Length - 1);
        }
        if (number == "0")
        {
            return ("Zero Only");
        }
        else
        {
            return (isNegative + ConvertToWords(number));
        }
    }

    private static String ConvertToWords(String numb)
    {
        String val = "", wholeNo = numb, points = "", andStr = "", pointStr = "";
        String endStr = "Only";
        try
        {
            int decimalPlace = numb.IndexOf(".");
            if (decimalPlace > 0)
            {
                wholeNo = numb.Substring(0, decimalPlace);
                points = numb.Substring(decimalPlace + 1);
                if (Convert.ToInt32(points) > 0)
                {
                    andStr = "and";// just to separate whole numbers from points/cents  
                    endStr = "Paisa " + endStr;//Cents  
                    pointStr = ConvertDecimals(points);
                }
            }
            val = String.Format("{0} {1}{2} {3}", ConvertWholeNumber(wholeNo).Trim(), andStr, pointStr, endStr);
        }
        catch { }
        return val;
    }
    private static String ConvertWholeNumber(String Number)
    {
        string word = "";
        try
        {
            bool beginsZero = false;//tests for 0XX
            bool isDone = false;//test if already translated
            double dblAmt = (Convert.ToDouble(Number));
            //if ((dblAmt > 0) && number.StartsWith("0"))
            if (dblAmt > 0)
            {//test for zero or digit zero in a nuemric
                beginsZero = Number.StartsWith("0");

                int numDigits = Number.Length;
                int pos = 0;//store digit grouping
                String place = "";//digit grouping name:hundres,thousand,etc...
                switch (numDigits)
                {
                    case 1://ones' range

                        word = ones(Number);
                        isDone = true;
                        break;
                    case 2://tens' range
                        word = tens(Number);
                        isDone = true;
                        break;
                    case 3://hundreds' range
                        pos = (numDigits % 3) + 1;
                        place = " Hundred ";
                        break;
                    case 4://thousands' range
                    case 5:
                    case 6:
                        pos = (numDigits % 4) + 1;
                        place = " Thousand ";
                        break;
                    case 7://millions' range
                    case 8:
                    case 9:
                        pos = (numDigits % 7) + 1;
                        place = " Million ";
                        break;
                    case 10://Billions's range
                    case 11:
                    case 12:

                        pos = (numDigits % 10) + 1;
                        place = " Billion ";
                        break;
                    //add extra case options for anything above Billion...
                    default:
                        isDone = true;
                        break;
                }
                if (!isDone)
                {//if transalation is not done, continue...(Recursion comes in now!!)
                    if (Number.Substring(0, pos) != "0" && Number.Substring(pos) != "0")
                    {
                        try
                        {
                            word = ConvertWholeNumber(Number.Substring(0, pos)) + place + ConvertWholeNumber(Number.Substring(pos));
                        }
                        catch { }
                    }
                    else
                    {
                        word = ConvertWholeNumber(Number.Substring(0, pos)) + ConvertWholeNumber(Number.Substring(pos));
                    }

                    //check for trailing zeros
                    //if (beginsZero) word = " and " + word.Trim();
                }
                //ignore digit grouping names
                if (word.Trim().Equals(place.Trim())) word = "";
            }
        }
        catch { }
        return word.Trim();
    }
    private static String tens(String Number)
    {
        int _Number = Convert.ToInt32(Number);
        String name = null;
        switch (_Number)
        {
            case 10:
                name = "Ten";
                break;
            case 11:
                name = "Eleven";
                break;
            case 12:
                name = "Twelve";
                break;
            case 13:
                name = "Thirteen";
                break;
            case 14:
                name = "Fourteen";
                break;
            case 15:
                name = "Fifteen";
                break;
            case 16:
                name = "Sixteen";
                break;
            case 17:
                name = "Seventeen";
                break;
            case 18:
                name = "Eighteen";
                break;
            case 19:
                name = "Nineteen";
                break;
            case 20:
                name = "Twenty";
                break;
            case 30:
                name = "Thirty";
                break;
            case 40:
                name = "Fourty";
                break;
            case 50:
                name = "Fifty";
                break;
            case 60:
                name = "Sixty";
                break;
            case 70:
                name = "Seventy";
                break;
            case 80:
                name = "Eighty";
                break;
            case 90:
                name = "Ninety";
                break;
            default:
                if (_Number > 0)
                {
                    name = tens(Number.Substring(0, 1) + "0") + " " + ones(Number.Substring(1));
                }
                break;
        }
        return name;
    }
    private static String ones(String Number)
    {
        int _Number = Convert.ToInt32(Number);
        String name = "";
        switch (_Number)
        {

            case 1:
                name = "One";
                break;
            case 2:
                name = "Two";
                break;
            case 3:
                name = "Three";
                break;
            case 4:
                name = "Four";
                break;
            case 5:
                name = "Five";
                break;
            case 6:
                name = "Six";
                break;
            case 7:
                name = "Seven";
                break;
            case 8:
                name = "Eight";
                break;
            case 9:
                name = "Nine";
                break;
        }
        return name;
    }
    private static String ConvertDecimals(String number)
    {
        String cd = "", digit = "", engOne = "";
        for (int i = 0; i < number.Length; i++)
        {
            digit = number[i].ToString();
            if (digit.Equals("0"))
            {
                engOne = "Zero";
            }
            else
            {
                engOne = ones(digit);
            }
            cd += " " + engOne;
        }
        return cd;
    }

    protected void LBGetAPI_Click(object sender, EventArgs e)
    {
        //"../ProvideFile.asmx/GetStatementRecord?jsn={"Action":"GET_STMT","CustID":"9203","Month":"May","Year":"2020"}");
        Response.Redirect("../ProvideFile.asmx");
    }

    #endregion

    #region Insert Resulted Data Into Server
    private void SaveStatementFileToServer(string filePath, string cust_code)
    {
        try
        {
            string Pdf_ContentData = "application/pdf";
            FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            Byte[] bytes = br.ReadBytes((Int32)fs.Length);
            br.Close();
            fs.Close();
            DateTime dt = DateTime.Now;

            string Query_Select = "SELECT * FROM SMNPPL_TaxInvoice WHERE Customer='" + cust_code + "' AND Month='" + dt.Month.ToString() + "' AND Year='" + dt.Year.ToString() + "'";
            DataSet DS_ExistingRecords = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Query_Select);
            if (DS_ExistingRecords.Tables[0].Rows.Count > 0)
            {
                string Qry_Update = "UPDATE SMNPPL_TaxInvoice SET Customer='" + cust_code + "',Month='" + dt.Month.ToString() + "',Year='"
                                    + dt.Year.ToString() + "',FileName='" + filePath + "',FileContentType='" + Pdf_ContentData + "',FileData=CONVERT(VARBINARY(MAX),'" + bytes + "') WHERE ID='" + DS_ExistingRecords.Tables[0].Rows[0][0].ToString() + "'";
                int Result = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, Qry_Update);
            }
            else
            {
                string Qry_Insert = "INSERT INTO SMNPPL_TaxInvoice (Customer,Month,Year,FileName,FileContentType,FileData) VALUES ('" + cust_code + "','"
                                + dt.Month.ToString() + "','" + dt.Year.ToString() + "','" + filePath + "','" + Pdf_ContentData + "',CONVERT(VARBINARY(MAX),'" + bytes + "'))";
                int Result = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, Qry_Insert);
            }
        }
        catch (Exception ex)
        {

        }
    }
    #endregion

    # region mail
    public void SendEmail(string MailTo, string MailSubject, string MailBody, string VnoID, string pdfpath, string excel, List<string> excelList)
    {
        MailMessage mail = new MailMessage();
        //  var dateString1 = DateTime.Now.ToString("yyyyMMdd");

        try
        {
            string file = excel;
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
             mail.From = new MailAddress("contactus@shreemarutinandan.com");
           // mail.From = new MailAddress("laxmayatech@gmail.com");
            mail.To.Add(MailTo);                            // Sending MailTo

            List<string> li = new List<string>();
            li.Add(MailTo);
            mail.CC.Add(string.Join<string>(",", li));       // Sending CC
            mail.Bcc.Add(string.Join<string>(",", li));      // Sending Bcc     
            mail.Subject = MailSubject;                      // Mail Subject
            mail.Body = MailBody;

            System.Net.Mail.Attachment attachment;
            if (excelList != null)
            {
                for (int i = 0; i < excelList.Count; i++)
                {
                    string[] name = excelList[i].Split('/');
                    attachment = new System.Net.Mail.Attachment(excelList[i]); //Attaching File to Mail
                    mail.Attachments.Add(attachment);
                    attachment.Name = name[6];
                }
            }
            else
            {
                string[] name = file.Split('/');
                attachment = new System.Net.Mail.Attachment(file); //Attaching File to Mail
                mail.Attachments.Add(attachment);
                attachment.Name = name[6];
            }

            attachment = new System.Net.Mail.Attachment(pdfpath);
            mail.Attachments.Add(attachment);

            SmtpServer.Port = Convert.ToInt32(587); //PORT
            SmtpServer.EnableSsl = true;
            SmtpServer.DeliveryMethod = SmtpDeliveryMethod.Network;
            SmtpServer.UseDefaultCredentials = true;
            SmtpServer.Credentials = new NetworkCredential("contactus@shreemarutinandan.com", "shreeall123");
        //   SmtpServer.Credentials = new NetworkCredential("laxmayatech@gmail.com", "laxmaya1379");

            SmtpServer.Send(mail);

            string script = "<script>alert('Mail Sent Successfully')</script>";
            ClientScript.RegisterStartupScript(this.GetType(), "mailSent", script);
        }
        catch (Exception ex)
        {
            throw ex;
            string script = "<script>alert('" + ex.Message + "')</script>";
            ClientScript.RegisterStartupScript(this.GetType(), "Error", script);
        }
        finally
        {
            mail.Dispose();
        }
    }

    public void SendEmailwithAttachment(string VnoID, string CustAcnoID, string pdfpath, string filename, string excel, List<string> excelFileList)
    {
        #region sendMail BulkorSingle
        string[] CustDetails = GetCustDetails(CustAcnoID);
        string CustName = CustDetails[0]; //"Laxmaya Technologies...."; // CustDetails[0];
        string CustEmail = CustDetails[1]; // ritu.laxmayatechnologies@gmail.com
        string MailSubject = "SMNPPL";
        string foldername = DateTime.Now.ToString("dd-MMM-yyyy");
        if (Session["SEARCH"].ToString() == "DATERANGE" || Session["SEARCH"].ToString() == "CUST")
        {
            MailSubject = " SMNPPL : Requested Invoices for <" + TBDOB.Text.ToString() + "> to <" + TBAdmissionDate.Text.ToString() + ">";
            if (Session["SEARCH"].ToString() == "DATERANGE")
            {
                foldername = TBDOB.Text.ToString() + "To" + TBAdmissionDate.Text.ToString();
                foldername = foldername.Replace("/", "-");
            }
            else if (Session["SEARCH"].ToString() == "CUST")
            {
                foldername = TBDOB.Text.ToString() + "To" + TBAdmissionDate.Text.ToString() + "_" + DDLCustomer.SelectedItem.ToString();
                foldername = foldername.Replace("/", "-");
            }
        }
        else
        {
            MailSubject = " SMNPPL : Invoice <" + VnoID + ">  ";
            foldername = TBInvDate.Text;//DateTime.Now.ToString("dd-MMM-yyyy");
            foldername = foldername.Replace("/", "-");
        }

        string MailBody = @"Dear " + CustName + '<' + CustAcnoID + @">,Please find attached the copy of the invoice. 
                            THANKS N REGARDS,
                            SHREE MARUTI NANDAN PHARMACEUTICALS PVT LTD.
                            NOIDA
                            CUSTOMER SATISFACTION IS OUR MOTO";

        string CustId = CustDetails[2];
        string CustMob = CustDetails[3];
        string cname = CustDetails[0];
        if (CustEmail.Length < 0 || CustEmail.ToString() == "")
        {
            string sql = "INSERT INTO send_log_new VALUES ('" + CustMob + "','Failed to send Invoice email from webserver', 'Email Failed', 'WEBSERVER', '" + DateTime.Now.ToString() + "'," + CustId + ",'TAX INVOICE BY WEBSERVER')";
            int Result = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, sql);
            try
            {
                string subPath = "D:/SMNPPL by LAXMAYA/generated PDF for STTMT & INVC/Invoices/FailInvoice/" + foldername;//DateTime.Now.ToString("dd-MMM-yyyy"); // your code goes here
                //string subPath = "D:/Invoices/FailInvoice/" + foldername;//DateTime.Now.ToString("dd-MMM-yyyy"); // your code goes here
                bool exists = System.IO.Directory.Exists(subPath);
                if (!exists)
                    System.IO.Directory.CreateDirectory(subPath);
                string pdfFile = Path.Combine(subPath, filename);
                File.Copy(pdfpath, pdfFile);
                if (excelFileList != null)
                {
                    for (int i = 0; i < excelFileList.Count; i++)
                    {
                        string[] excelname = excelFileList[i].Split('/');
                        string xclFile = Path.Combine(subPath, excelname[6].ToString());
                        File.Move(excelFileList[i], xclFile);
                        //   File.Delete(excel);
                    }

                }
                else
                {
                    string[] excelname = excel.Split('/');
                    string xclFile = Path.Combine(subPath, excelname[6].ToString());
                    File.Move(excel, xclFile);
                    //  File.Delete(excel);
                }
            }
            catch (Exception e1)
            {
                Errlbl.Text = e1.Message;
            }
        }
        else
        {
            try
            {
                string subPath = "D:/SMNPPL by LAXMAYA/generated PDF for STTMT & INVC/Invoices/SentInvoice/" + foldername;//DateTime.Now.ToString("dd-MMM-yyyy"); // your code goes here
               // string subPath = "D:/Invoices/SentInvoice/" + foldername;//DateTime.Now.ToString("dd-MMM-yyyy"); // your code goes here
                bool exists = System.IO.Directory.Exists(subPath);
                if (!exists)
                    System.IO.Directory.CreateDirectory(subPath);
                string pdfFile = Path.Combine(subPath, filename);
                File.Copy(pdfpath, pdfFile);
                SendEmail(CustEmail, MailSubject, MailBody, Convert.ToString(VnoID), pdfpath, excel, excelFileList);
            }
            catch (Exception e1)
            {
                Errlbl.Text = e1.Message;
            }

        }


        #endregion
    }
    #endregion

    #region link for bulk process
    protected void LBAutomaticStmt_Click(DataSet ds)
    {

        string timestm = "";
        // DataSet ds = (DataSet)Session["DateInv"];

        if (ds.Tables[0].Rows.Count > 0)
        {

            int l = ds.Tables[0].Rows.Count;
            for (int p = 0; p < l; p++)
            {
                int VnoID = Convert.ToInt32(ds.Tables[0].Rows[p]["Invoice"]);
                string acno = ds.Tables[0].Rows[p]["Date"].ToString();
                string cname = ds.Tables[0].Rows[p]["Customer Name"].ToString();
                string[] vdt = acno.Split(new char[] { '-' });
                try
                {
                   // string qryacno = "select Acno,Vno,Vdt from Salepurchase1  where  vno = '" + VnoID + "' and DATEPART(YEAR,Vdt) = " + vdt[2];
                    string qryacno = "select Acno,Vno,Vdt from Salepurchase1  where  vno = '" + VnoID + "' and DATEPART(MONTH,Vdt) = '" + vdt[1] + "' and DATEPART(DAY,Vdt) = '" + vdt[0] + "'  and DATEPART(YEAR,Vdt) = " + vdt[2];
                    string CustAcnoID = "-1";
                    DataSet dsacno = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, qryacno);
                    try
                    {
                        if (dsacno.Tables[0].Rows.Count > 0)
                        {
                            CustAcnoID = dsacno.Tables[0].Rows[0]["Acno"].ToString();
                            acno = dsacno.Tables[0].Rows[0]["Vdt"].ToString();
                        }
                    }
                    catch (Exception e2)
                    {
                        e2.Message.ToString();
                    }
                    string excel = GetExcelFile(Convert.ToInt32(VnoID), acno);
                    timestm = GetpdfFile(Convert.ToInt32(VnoID), acno);
                    string timestamp = DateTime.Now.ToString("yyyyMMddHHmmssffff");
                    string pdfpath = Server.MapPath("~/InvRpts/" + "Invoice-" + cname + "(" + VnoID + "_" + timestm + ").pdf");
                    SendEmailwithAttachment(VnoID.ToString(), CustAcnoID, pdfpath, "Invoice-" + cname + "(" + VnoID + "_" + timestm + ").pdf", excel, null);

                }
                catch (Exception ex)
                {
                    Errlbl1.Text = ex.Message + "GET PDF METHOD";
                }
            }
        }
        else
        {

        }

    }

    protected void LBAutomaticStmtForCustomer_Click(DataSet ds)
    {
        string timestm = "";
        // img.Visible = true; 
        if (ds != null)
        {
            //DataSet ds = (DataSet)Session["CustInv"];

            #region creatonbyone
            string excel = "";
            if (ds.Tables[0].Rows.Count > 0)
            {
                // GetBulkExcelFile(ds);
                int VnoID = 0; string CustAcnoID = "-1";
                int l = ds.Tables[0].Rows.Count;
                for (int p = 0; p < l; p++)
                {
                    VnoID = Convert.ToInt32(ds.Tables[0].Rows[p]["Invoice"]);
                    string acno = ds.Tables[0].Rows[p]["Date"].ToString();

                    string[] vdt = acno.Split(new char[] { '-' });
                    try
                    {
                       // string qryacno = "select Acno,Vno,Vdt from Salepurchase1  where  vno = '" + VnoID + "' and DATEPART(YEAR,Vdt) = " + vdt[2];
                        string qryacno = "select Acno,Vno,Vdt from Salepurchase1  where  vno = '" + VnoID + "' and DATEPART(MONTH,Vdt) = '" + vdt[1] + "' and DATEPART(DAY,Vdt) = '" + vdt[0] + "'  and DATEPART(YEAR,Vdt) = " + vdt[2];
                        DataSet dsacno = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, qryacno);
                        try
                        {
                            if (dsacno.Tables[0].Rows.Count > 0)
                            {
                                CustAcnoID = dsacno.Tables[0].Rows[0]["Acno"].ToString();
                                acno = dsacno.Tables[0].Rows[0]["Vdt"].ToString();
                            }
                        }
                        catch (Exception e2)
                        {
                            e2.Message.ToString();
                        }
                        excel = GetExcelFile(Convert.ToInt32(VnoID), acno);
                        excelFileList.Add(excel);
                        timestm = GetpdfFile(Convert.ToInt32(VnoID), acno);

                    }
                    catch (Exception ex)
                    {
                        Errlbl1.Text = ex.Message;
                    }
                }
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmssffff");
                string mergepdfpath = Server.MapPath("~/InvRpts/SMNPPL_Invoice_" + DDLCustomer.SelectedItem + "_" + timestamp + ".pdf");
                CombineMultiplePDFs(FinalFileList, mergepdfpath);
                string filename = "SMNPPL_Invoice_" + DDLCustomer.SelectedItem + "_" + timestamp + ".pdf";
                SendEmailwithAttachment(VnoID.ToString(), CustAcnoID, mergepdfpath, filename, excel, excelFileList);

            }
            else
            {
            }
            #endregion
        }
    }

    protected void LBAutomatic(object sender, EventArgs e)
    {

        //  mp1.Show(); 
        try
        {
            string session = Session["SEARCH"].ToString();
            switch (session)
            {
                case "CUST":
                    DataSet ds = (DataSet)Session["CustInv"];
                    LBAutomaticStmtForCustomer_Click(ds);
                    break;
                case "DATE":
                    DataSet ds1 = (DataSet)Session["DateInv"];
                    LBAutomaticStmt_Click(ds1);
                    break;
                case "DATERANGE":
                    DataSet ds2 = (DataSet)Session["DateRangeInv"];
                    LBAutomaticStmt_Click(ds2);
                    break;
            }

            //Session.Clear();
            gvjob.DataSource = null; ;
            gvjob.DataBind();
            lbl_count.Text = "";
            lbl_count.Visible = false;
        }
        catch (Exception bindEx)
        {
            Errlbl.Text = bindEx.Message.ToString(); 
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Some Parameters missing')", true);
        }
    }
    #endregion

    #region link
    protected void LBReset(object sender, EventArgs e)
    {
        // mp1.Show();
        TBInvDate.Text = "";
        TBInvID.Text = "";
        TBDOB.Text = "";
        TBAdmissionDate.Text = "";
        Session.Clear();
        gvjob.DataSource = null;
        gvjob.DataBind();
        lbl_count.Text = "";
        btn_InvForCustomer.Visible = false;

    }


    protected void LinkButtonDate_Click(object sender, EventArgs e)
    {

        TBInvID.Text = "";
        TBDOB.Text = "";
        TBAdmissionDate.Text = "";
        lbl_count.Text = "";
        DDLCustomer.SelectedIndex = 0;
        Session["SEARCH"] = "DATE";
        BindGridData(Session["SEARCH"].ToString());
    }

    protected void LinkButtonInv_Click(object sender, EventArgs e)
    {

        TBInvDate.Text = "";
        TBDOB.Text = "";
        TBAdmissionDate.Text = "";
        lbl_count.Text = "";
        DDLCustomer.SelectedIndex = 0;
        Session["SEARCH"] = "INV";
        BindGridData(Session["SEARCH"].ToString());
    }



    protected void LinkButton_DateRangee(object sender, EventArgs e)
    {
        //mp1.Show();
        TBInvDate.Text = "";
        TBInvID.Text = "";
        lbl_count.Text = "";
        if (DDLCustomer.SelectedIndex == 0)
        {
            Session["SEARCH"] = "DATERANGE";
        }
        else
        {
            Session["SEARCH"] = "CUST";
        }
        // mp1.Hide(); 
        BindGridData(Session["SEARCH"].ToString());
    }
    #endregion

    #region excelmerge

    public string GetExcelFile(int VnoID, string vdt)
    {
        DataSet ds = null;

        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString))
        {
            string excelPAth = "";
            try
            {
                string Qry = @"select b.name as Supplier, a.GSTVno as 'Bill NO.' , convert(varchar(10),a.Vdt,103) as date,e.name as company, c.Itemc as code,
                            d.Barcode,d.name,d.Pack,c.Batch, c.expiry,c.Qty, c.fqty,c.Halfp,c.Ftrate,c.Trate, c.Mrp,c.Dis,c.excise,a.Vat4 as VAT,c.AdnlVat,
                            c.NetAmt,c.LocalCent,c.scm1,c.scm2,c.ScmPer,c.HSNCode,c.CGST, c.SGST, c.igst from Salepurchase1 a, Acm b, Salepurchase2 c, Item d, Company e
                            where a.acno = b.code and a.Vno = c.Vno and a.Vdt = c.Vdt and c.Itemc = d.code and  a.Vno = '" + VnoID + "' and a.vdt = '" + vdt + "'  and d.Compcode = e.code order by d.name ";
                SqlCommand cmd = new SqlCommand(Qry, con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                excelPAth = ExportDataSetToExcel(ds, Convert.ToString(VnoID));
                return excelPAth;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                ds.Dispose();
            }
        }
    }
    //private string ExportDataSetToExcel(DataSet ds, string VnoID)
    //{
    //    try
    //    {
    //        string custName = ds.Tables[0].Rows[0]["Supplier"].ToString();
    //        string code = ds.Tables[0].Rows[0]["Code"].ToString();
    //        string timestamp = DateTime.Now.ToString("yyyyMMddHHmmssffff");
    //        string path = "D:/Invoices/SentInvoice/" + DateTime.Now.ToString("dd-MMM-yyyy") + "/SMNPPL_Invoice_" + custName + "(" + code + ")" + "_" + timestamp + ".xlsx";
    //        using (XLWorkbook wb = new XLWorkbook())
    //        {
    //            wb.Worksheets.Add(ds.Tables[0]);
    //            wb.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
    //            wb.Style.Font.Bold = true;
    //            wb.SaveAs(path);
    //        }

    //        return path;
    //    }
    //    catch (Exception)
    //    {
    //        throw;
    //    }


    //}

    private string ExportDataSetToExcel(DataSet ds, string VnoID)
    {
        try
        {
            string custName = ds.Tables[0].Rows[0]["Supplier"].ToString();
            string code = ds.Tables[0].Rows[0]["Code"].ToString();
            string timestamp = DateTime.Now.ToString("yyyyMMddHHmmssffff");
            string foldername = DateTime.Now.ToString("dd-MMM-yyyy");
            if (Session["SEARCH"].ToString() == "DATERANGE" || Session["SEARCH"].ToString() == "CUST")
            {
                if (Session["SEARCH"].ToString() == "DATERANGE")
                {
                    foldername = TBDOB.Text.ToString() + "To" + TBAdmissionDate.Text.ToString();
                    foldername = foldername.Replace("/", "-");
                }
                else if (Session["SEARCH"].ToString() == "CUST")
                {
                    foldername = TBDOB.Text.ToString() + "To" + TBAdmissionDate.Text.ToString() + "_" + DDLCustomer.SelectedItem.ToString();
                    foldername = foldername.Replace("/", "-");
                }
            }
            else
            {
                foldername = TBInvDate.Text;//DateTime.Now.ToString("dd-MMM-yyyy");
                foldername = foldername.Replace("/", "-");
            }
           
            string path = "D:/SMNPPL by LAXMAYA/generated PDF for STTMT & INVC/Invoices/SentInvoice/" + foldername + "/SMNPPL_Invoice_" + custName + "(" + code + ")" + "_" + timestamp + ".xlsx";
            //string path = "D:/Invoices/SentInvoice/" + foldername + "/SMNPPL_Invoice_" + custName + "(" + code + ")" + "_" + timestamp + ".xlsx";
            string subPath = "D:/SMNPPL by LAXMAYA/generated PDF for STTMT & INVC/Invoices/SentInvoice/" + foldername;//DateTime.Now.ToString("dd-MMM-yyyy"); // your code goes here
            bool exists = System.IO.Directory.Exists(subPath);
            if (!exists)
                System.IO.Directory.CreateDirectory(subPath);
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(ds.Tables[0]);
                wb.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                wb.Style.Font.Bold = true;
                wb.SaveAs(path);
            }

            return path;
        }
        catch (Exception)
        {
            throw;
        }


    }

    #region bulkexcel not in use
    public void GetBulkExcelFile(DataSet dss)
    {
        DataSet ds = null;
        string custName = "", code = "", excelPAth = "";
        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString))
        {
            for (int i = 0; i < dss.Tables[0].Rows.Count; i++)
            {
                int VnoID = Convert.ToInt32(dss.Tables[0].Rows[i]["Invoice"]);
                string acno = dss.Tables[0].Rows[i]["Date"].ToString();
                custName = dss.Tables[0].Rows[0]["Customer Name"].ToString();
                code = dss.Tables[0].Rows[0]["Customer ID"].ToString();
                string[] vdt = acno.Split(new char[] { '-' });

                try
                {
                    string Qry = @"select b.name as Supplier, a.GSTVno as 'Bill NO.' , convert(varchar(10),a.Vdt,103) as date,e.name as company, c.Itemc as code,
                            d.Barcode,d.name,d.Pack,c.Batch, c.expiry,c.Qty, c.fqty,c.Halfp,c.Ftrate,c.Trate, c.Mrp,c.Dis,c.excise,a.Vat4 as VAT,c.AdnlVat,
                            c.NetAmt,c.LocalCent,c.scm1,c.scm2,c.ScmPer,c.HSNCode,c.CGST, c.SGST, c.igst from Salepurchase1 a, Acm b, Salepurchase2 c, Item d, Company e
                            where a.acno = b.code and a.Vno = c.Vno and a.Vdt = c.Vdt and c.Itemc = d.code and  a.Vno = '" + VnoID + "' and DATEPART(YEAR,a.vdt) = '" + vdt[0] + "'  and d.Compcode = e.code order by d.name ";

                    SqlCommand cmd = new SqlCommand(Qry, con);
                    cmd.CommandType = CommandType.Text;
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = cmd;
                    ds = new DataSet();
                    da.Fill(ds);
                    DataTable dtCopy = ds.Tables[0].Copy();
                    dtCopy.TableName = "Invoice_" + VnoID;
                    excelDs.Tables.Add(dtCopy);
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    ds.Dispose();
                }
            }

            excelPAth = ExportBulkDataSetToExcel(excelDs, custName, code);

        }
    }

    private string ExportBulkDataSetToExcel(DataSet ds, string custname, string code)
    {
        string AppLocations = "";
        try
        {
            //  string AppLocation = "D:\\SentInvoice\\SMNPPL-.xlsx";
            // AppLocation = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
            // AppLocation = AppLocation.Replace("file:\\", "");
            // string file = AppLocation + "\\ExcelFiles\\DataFile.xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                for (int i = 0; i < ds.Tables.Count; i++)
                {
                    wb.Worksheets.Add(ds.Tables[i]);
                    wb.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    wb.Style.Font.Bold = true;
                }
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmssffff");
                AppLocations = "D:\\Invoices\\DateINv\\SMNPPL_Invoice_" + custname + "(" + code + ")" + "_" + timestamp + ".xlsx";
                wb.SaveAs(AppLocations);
                return "D:\\Invoices\\DateINv\\SMNPPL_Invoice_" + custname + "(" + code + ")" + "_" + timestamp + ".xlsx"; ;
            }
        }
        catch (Exception)
        {
            throw;
        }


    }
    #endregion



    #endregion
}









