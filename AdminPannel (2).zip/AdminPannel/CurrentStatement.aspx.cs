﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.ApplicationBlocks.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Net.Mail;
using System.Net;
using iTextSharp.text;
using System.IO;
using iTextSharp.text.pdf;
using System.Data.SqlClient;

public partial class AdminPannel_CurrentStatement : System.Web.UI.Page
{
    ReportDocument crystalReportStt = new ReportDocument();
    ReportDocument crystalReportSR = new ReportDocument();
    ReportDocument crystalReportBE = new ReportDocument();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindReportMonthYear();
            BindCustomer();
        }
    }

    private void BindReportMonthYear()
    {
        try
        {
            TBYear.Text = DateTime.Now.Year.ToString();
            DDLMonth.SelectedValue = (DateTime.Now.Month - 1).ToString();
            //DDLMonth.Enabled = false;
            //TBYear.Enabled = false;
        }
        catch (Exception ex)
        { }
    }

    private void BindCustomer()
    {
        try
        {
            string Qry = "SELECT code, CONVERT(NVARCHAR, code) + ' - ' + Name + ' ( ' + Altercode + ' )' As Customer FROM Acm WHERE Status <> '*' AND Slcd='CL' Order By code";
            DataSet ds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DDLCustomer.DataSource = ds.Tables[0];
                DDLCustomer.DataTextField = "Customer";
                DDLCustomer.DataValueField = "code";
                DDLCustomer.DataBind();
            }
        }
        catch (Exception ex)
        { }
    }

    public void fetchjob()
    {
        string query = "select job_id,name,date_created,date_modified,enabled,CASE  enabled WHEN 1 THEN 'ENABLED' else 'DISABLED'END AS Status from msdb.dbo.sysjobs order by date_created desc";
        DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, query);
        gvjob.DataSource = jds.Tables[0];
        gvjob.DataBind();
    }


    List<int> SaleReturnIDList = new List<int>();
    List<int> BreakageExpiraryList = new List<int>();
    decimal TotalSales = 0, TotalBE = 0;

    protected void LBFilter_Click(object sender, EventArgs e)
    {
        try
        {
            // Get Customer Record From MonthlyStmtView
            string CurrMonth = DDLMonth.SelectedItem.Text.Trim().ToString() + "-" + TBYear.Text.Trim().ToString();
            DataSet CusMonthStmt = new DataSet();
            CusMonthStmt = FilterRec(DDLCustomer.SelectedValue, CurrMonth);
            gvjob.DataSource = CusMonthStmt.Tables[0];
            gvjob.DataBind();
            DateTime StartingDate = new DateTime(Convert.ToInt32(TBYear.Text), Convert.ToInt32(DDLMonth.SelectedValue), 1);
            DateTime EndingDate = new DateTime(Convert.ToInt32(TBYear.Text), Convert.ToInt32(DDLMonth.SelectedValue), 1).AddMonths(1).AddDays(-1);

            // Generate Ledger DataSet

            DataTable DTSttLedger = new DataTable();
            DTSttLedger = GenerateLedgerDS(DDLCustomer.SelectedValue);

            List<string> FinalFileList = new List<string>();
            List<string> BEFileList = new List<string>();
            List<string> SRFileList = new List<string>();

            #region Generate Ledger PDF

            DataTable DTChequeLdgr = GetChequeDetails(DDLCustomer.SelectedValue);

            crystalReportStt = new ReportDocument(); // creating object of crystal report
            crystalReportStt.Load(Server.MapPath("~/CryRpts/CurrDemo.rpt")); // path of report 
            //crystalReportStt.SetDataSource(DTSttLedger); // binding datatable
            crystalReportStt.Database.Tables["LedgerRecord"].SetDataSource(DTSttLedger);
            crystalReportStt.Database.Tables["LedgerChequeRecord"].SetDataSource(DTChequeLdgr);

            // Bind Company Parameters
            DataTable DTControl1 = GetCompany();
            if (DTControl1.Rows.Count > 0)
            {
                crystalReportStt.SetParameterValue("pCompanyName", DTControl1.Rows[0]["Compname1"].ToString());
                crystalReportStt.SetParameterValue("pCompAdd1", DTControl1.Rows[0]["Address"].ToString());
                crystalReportStt.SetParameterValue("pCompAdd2", DTControl1.Rows[0]["Address1"].ToString());
                crystalReportStt.SetParameterValue("pTelno", DTControl1.Rows[0]["Tel"].ToString());
                crystalReportStt.SetParameterValue("pGSTNo", "GST No. :" + DTControl1.Rows[0]["GSTNo"].ToString());
                crystalReportStt.SetParameterValue("pCompStateCode", "State Code :" + DTControl1.Rows[0]["StateCode"].ToString());
                crystalReportStt.SetParameterValue("pCompCIN", "CIN" + DTControl1.Rows[0]["CINNO"].ToString());
                crystalReportStt.SetParameterValue("pFSSAINo", "FASSAI NO. :" + DTControl1.Rows[0]["FoodLicNo"].ToString());
                crystalReportStt.SetParameterValue("pDLno", "DL No. :" + DTControl1.Rows[0]["Dlno"].ToString());
                crystalReportStt.SetParameterValue("pCompEmail", "E-Mail :" + DTControl1.Rows[0]["Email"].ToString());
            }

            // Bind Customer Info
            DataTable DTAcm1 = GetCustomer(Convert.ToInt32(DDLCustomer.SelectedValue));
            if (DTAcm1.Rows.Count > 0)
            {
                crystalReportStt.SetParameterValue("PName", DTAcm1.Rows[0]["Name"].ToString());
                crystalReportStt.SetParameterValue("address1", DTAcm1.Rows[0]["address"].ToString());
                crystalReportStt.SetParameterValue("address2", DTAcm1.Rows[0]["address1"].ToString());
                crystalReportStt.SetParameterValue("address3", DTAcm1.Rows[0]["address2"].ToString());
                crystalReportStt.SetParameterValue("CustTel", DTAcm1.Rows[0]["telephone"].ToString());
                crystalReportStt.SetParameterValue("CUstStateCode", DTAcm1.Rows[0]["StateCode"].ToString());
                crystalReportStt.SetParameterValue("mInvNo", "");
                crystalReportStt.SetParameterValue("vdt", DateTime.Now.ToString("dd/MM/yyyy"));
                crystalReportStt.SetParameterValue("CustGST", DTAcm1.Rows[0]["GSTNo"].ToString());
                crystalReportStt.SetParameterValue("CustDLNo", DTAcm1.Rows[0]["DLNO"].ToString());
                crystalReportStt.SetParameterValue("CustFassaiNo", "");
                crystalReportStt.SetParameterValue("pCustomerCode", DTAcm1.Rows[0]["Altercode"].ToString());
                crystalReportStt.SetParameterValue("pKeyValue", DTAcm1.Rows[0]["code"].ToString());
            }

            string Qry = "SELECT * FROM MonthlyStmtView WHERE MonthlyStmtView.KeyValue='" + DDLCustomer.SelectedValue + "' AND MonthlyStmtView.MonthInfo='" + CurrMonth + "'";
            DataTable DTCustInfo = new DataTable();
            DataSet DSReturn = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (DSReturn.Tables[0].Rows.Count > 0)
            {
                decimal PDue = Convert.ToDecimal(DSReturn.Tables[0].Rows[0]["PreviousDue"].ToString());
                decimal TInvAmt = Convert.ToDecimal(DSReturn.Tables[0].Rows[0]["LastMonthSale"].ToString());
                decimal NetOutIncludingChq = Convert.ToDecimal(DSReturn.Tables[0].Rows[0]["NetOutInclCheq"].ToString());

                decimal NetCBDis;
                if (!string.IsNullOrEmpty(DSReturn.Tables[0].Rows[0]["DiscountAmt"].ToString()))
                    NetCBDis = Convert.ToDecimal(DSReturn.Tables[0].Rows[0]["DiscountAmt"].ToString());
                else
                    NetCBDis = 0;

                // Calculations Logic As Provided by Client
                decimal GrossDueAmt, PreviousDue, TotalDueAmt, PaymentReceived, NetDueAmt;
                PreviousDue = (PDue <= 0) ? 0 : PDue;
                GrossDueAmt = TInvAmt - (TotalSales + TotalBE + NetCBDis);
                TotalDueAmt = GrossDueAmt + PreviousDue;

                if (NetOutIncludingChq <= 0)
                    PaymentReceived = 0 - TotalDueAmt;
                else
                    PaymentReceived = NetOutIncludingChq - TotalDueAmt;

                NetDueAmt = TotalDueAmt + PaymentReceived;


                //decimal NewDeu = Convert.ToDecimal(DSReturn.Tables[0].Rows[0]["LastMonthSale"].ToString()) - (TotalSales + TotalBE);
                //string FinalDue = (NetOutIncludingChq <= 0) ? "-" + NewDeu : DSReturn.Tables[0].Rows[0]["PreviousDue"].ToString();
                //string NetDue = (NetOutIncludingChq <= 0) ? "0.00" : DSReturn.Tables[0].Rows[0]["NetOutInclCheq"].ToString();

                crystalReportStt.SetParameterValue("pTotalInvoiceValue", TInvAmt.ToString("0.00"));
                crystalReportStt.SetParameterValue("pTotalGrossDueAmt", GrossDueAmt.ToString("0.00"));
                crystalReportStt.SetParameterValue("pPreDueAmt", PreviousDue.ToString("0.00"));
                crystalReportStt.SetParameterValue("pTotalBalanceDue", TotalDueAmt.ToString("0.00"));
                crystalReportStt.SetParameterValue("pPaymentReceived", PaymentReceived.ToString("0.00"));
                crystalReportStt.SetParameterValue("pNetDueAmount", NetDueAmt.ToString("0.00"));
                crystalReportStt.SetParameterValue("pTotalDueAmt", TotalDueAmt.ToString("0.00"));
                crystalReportStt.SetParameterValue("pCBDiscount", NetCBDis.ToString("0.00"));
            }
            else
            {
                crystalReportStt.SetParameterValue("pPreDueAmt", "0.00");
                crystalReportStt.SetParameterValue("pTotalBalanceDue", "0.00");
                crystalReportStt.SetParameterValue("pTotalInvoiceValue", "0.00");
                crystalReportStt.SetParameterValue("pNetDueAmount", "0.00");
                crystalReportStt.SetParameterValue("pTotalDueAmt", "0.00");
                crystalReportStt.SetParameterValue("pTotalGrossDueAmt", "0.00");
                crystalReportStt.SetParameterValue("pPaymentReceived", "0.00");
                crystalReportStt.SetParameterValue("pCBDiscount", "0.00");
            }

            string LastMonth = GetItem(DDLMonth.SelectedIndex);
            string QryLM = "SELECT * FROM MonthlyStmtView WHERE MonthlyStmtView.KeyValue='" + DDLCustomer.SelectedValue + "' AND MonthlyStmtView.MonthInfo='" + LastMonth + "'";
            DataTable DTCustInfoLM = new DataTable();
            DataSet DSReturnLM = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QryLM);
            if (DSReturnLM.Tables[0].Rows.Count > 0)
                crystalReportStt.SetParameterValue("pOpeningBalance", DSReturnLM.Tables[0].Rows[0][13].ToString());
            else
                crystalReportStt.SetParameterValue("pOpeningBalance", "");


            crystalReportStt.SetParameterValue("pTotalSalesReturn", TotalSales.ToString("0.00"));
            crystalReportStt.SetParameterValue("pTotalBreakageExpirary", TotalBE.ToString("0.00"));
            crystalReportStt.SetParameterValue("pMonthDetails", DDLMonth.SelectedItem.ToString() + TBYear.Text);

            CrystalReportViewer1.ReportSource = crystalReportStt;

            string pss = "";

            if (DTSttLedger.Rows.Count > 0)
                pss = DTSttLedger.Rows[0][0].ToString();
            else
                pss = "Data";
            string FilePath = Server.MapPath("~/CryRpts/" + "Stt" + pss + ".pdf");
            crystalReportStt.ExportToDisk(ExportFormatType.PortableDocFormat, FilePath);
            FinalFileList.Add(FilePath);
            crystalReportStt.Dispose();

            #endregion


            #region Generate Sale Return PDf
            foreach (int NoID in SaleReturnIDList)
            {
                DataTable DTSRLedger = new DataTable();
                if (DTSRLedger.Columns.Count == 0)
                {
                    DTSRLedger.Columns.Add("Srn", typeof(int));
                    DTSRLedger.Columns.Add("ItName", typeof(string));
                    DTSRLedger.Columns.Add("HSNCode", typeof(string));
                    DTSRLedger.Columns.Add("Pack", typeof(string));
                    DTSRLedger.Columns.Add("Batch", typeof(string));
                    DTSRLedger.Columns.Add("Expiry", typeof(string));
                    DTSRLedger.Columns.Add("Mrp", typeof(decimal));
                    DTSRLedger.Columns.Add("NQty", typeof(decimal));
                    DTSRLedger.Columns.Add("Ftrate", typeof(decimal));
                    DTSRLedger.Columns.Add("Itamt", typeof(decimal));
                    DTSRLedger.Columns.Add("GST", typeof(decimal));
                    DTSRLedger.Columns.Add("ItDis", typeof(decimal));
                }

                decimal GST28_GrossAmt = 0, GST28_Scm = 0, GST28_DisAmt = 0, GST28_Taxable = 0, GST28_CGSTAmt = 0, GST28_IGSTAmt = 0;
                decimal GST18_GrossAmt = 0, GST18_Scm = 0, GST18_DisAmt = 0, GST18_Taxable = 0, GST18_CGSTAmt = 0, GST18_IGSTAmt = 0;
                decimal GST12_GrossAmt = 0, GST12_Scm = 0, GST12_DisAmt = 0, GST12_Taxable = 0, GST12_CGSTAmt = 0, GST12_IGSTAmt = 0;
                decimal GST5_GrossAmt = 0, GST5_Scm = 0, GST5_DisAmt = 0, GST5_Taxable = 0, GST5_CGSTAmt = 0, GST5_IGSTAmt = 0;
                decimal GST0_GrossAmt = 0, GST0_Scm = 0, GST0_DisAmt = 0, GST0_Taxable = 0, GST0_CGSTAmt = 0, GST0_IGSTAmt = 0;
                decimal T_GrossAmt = 0, T_Scm = 0, T_DisAmt = 0, T_Taxable = 0, T_CGSTAmt = 0, T_IGSTAmt = 0;
                //'2020-02-01' AND '2020-02-29'
                string QRy = "select * FROm SalePurchase2 WHERE Vdt between '" + StartingDate.ToString("yyyy-MM-dd") + "' AND '" + EndingDate.ToString("yyyy-MM-dd") + "'  AND Acno='" + DDLCustomer.SelectedValue + "' AND Vno='" + NoID + "'";
                DataSet DSP = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy);
                if (DSP.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < DSP.Tables[0].Rows.Count; i++)
                    {
                        string QItemINSR = "SELECT * FROM Item WHERE code='" + DSP.Tables[0].Rows[i]["itemc"] + "'";
                        DataSet DSItemInSR = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QItemINSR);
                        if (DSItemInSR.Tables[0].Rows.Count > 0)
                        {
                            decimal IGST_TAX = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGST"]) + Convert.ToDecimal(DSP.Tables[0].Rows[i]["SGST"]);
                            decimal amt = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString()) * Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());

                            DTSRLedger.Rows.Add(i + 1,
                                                DSItemInSR.Tables[0].Rows[0]["Name"].ToString(),
                                                DSItemInSR.Tables[0].Rows[0]["HSNCode"].ToString(),
                                                DSItemInSR.Tables[0].Rows[0]["Pack"].ToString(),
                                                DSP.Tables[0].Rows[i]["Batch"].ToString(),
                                                DSP.Tables[0].Rows[i]["expiry"].ToString(),
                                                DSP.Tables[0].Rows[i]["Mrp"].ToString(),
                                                DSP.Tables[0].Rows[i]["Qty"],
                                                DSP.Tables[0].Rows[i]["Ntrate"].ToString(),
                                                amt.ToString(),
                                                IGST_TAX.ToString("0.00"),    // All Changes as per saurabh sir on 5/9/20
                                                DSP.Tables[0].Rows[i]["Dis"].ToString());

                            decimal Qty, Rate, GA, SCM, DA, Taxable, CGST, IGST;
                            switch (IGST_TAX.ToString("0.00"))
                            {
                                case "28.00":
                                    Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                    Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                    GA = Qty * Rate;
                                    SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                    DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                    Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                    IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                    CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                    GST28_GrossAmt += GA;
                                    GST28_Scm += SCM;
                                    GST28_DisAmt += DA;
                                    GST28_Taxable += Taxable;
                                    GST28_CGSTAmt += CGST;
                                    GST28_IGSTAmt += IGST;
                                    break;
                                case "18.00":
                                    Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                    Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                    GA = Qty * Rate;
                                    SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                    DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                    Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                    IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                    CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                    GST18_GrossAmt += GA;
                                    GST18_Scm += SCM;
                                    GST18_DisAmt += DA;
                                    GST18_Taxable += Taxable;
                                    GST18_CGSTAmt += CGST;
                                    GST18_IGSTAmt += IGST;
                                    break;
                                case "12.00":
                                    Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                    Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                    GA = Qty * Rate;
                                    SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                    DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                    Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                    IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                    CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                    GST12_GrossAmt += GA;
                                    GST12_Scm += SCM;
                                    GST12_DisAmt += DA;
                                    GST12_Taxable += Taxable;
                                    GST12_CGSTAmt += CGST;
                                    GST12_IGSTAmt += IGST;
                                    break;
                                case "5.00":
                                    Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                    Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                    GA = Qty * Rate;
                                    SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                    DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                    Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                    IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                    CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                    GST5_GrossAmt += GA;
                                    GST5_Scm += SCM;
                                    GST5_DisAmt += DA;
                                    GST5_Taxable += Taxable;
                                    GST5_CGSTAmt += CGST;
                                    GST5_IGSTAmt += IGST;
                                    break;
                                case "0.00":
                                    Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                    Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                    GA = Qty * Rate;
                                    SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                    DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                    Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                    IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                    CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                    GST0_GrossAmt += GA;
                                    GST0_Scm += SCM;
                                    GST0_DisAmt += DA;
                                    GST0_Taxable += Taxable;
                                    GST0_CGSTAmt += CGST;
                                    GST0_IGSTAmt += IGST;
                                    break;
                                default:
                                    break;
                            }
                        }
                    }



                    T_GrossAmt = GST28_GrossAmt + GST18_GrossAmt + GST12_GrossAmt + GST5_GrossAmt + GST0_GrossAmt;
                    T_Scm = GST28_Scm + GST18_Scm + GST12_Scm + GST5_Scm + GST0_Scm;
                    T_DisAmt = GST28_DisAmt + GST18_DisAmt + GST12_DisAmt + GST5_DisAmt + GST0_DisAmt;
                    T_Taxable = GST28_Taxable + GST18_Taxable + GST12_Taxable + GST5_Taxable + GST0_Taxable;
                    T_CGSTAmt = GST28_CGSTAmt + GST18_CGSTAmt + GST12_CGSTAmt + GST5_CGSTAmt + GST0_CGSTAmt;
                    T_IGSTAmt = GST28_IGSTAmt + GST18_IGSTAmt + GST12_IGSTAmt + GST5_IGSTAmt + GST0_IGSTAmt;



                    crystalReportSR = new ReportDocument(); // creating object of crystal report
                    crystalReportSR.Load(Server.MapPath("~/CryRpts/DemoSR.rpt")); // path of report 
                    DataSet DSSR = new DataSet();
                    crystalReportSR.SetDataSource(DTSRLedger); // binding dataSet

                    // Bind Company Info
                    DataTable DTControl11 = GetCompany();
                    if (DTControl11.Rows.Count > 0)
                    {
                        crystalReportSR.SetParameterValue("pCompanyName", DTControl11.Rows[0]["Compname1"].ToString());
                        crystalReportSR.SetParameterValue("pCompAdd1", DTControl11.Rows[0]["Address"].ToString());
                        crystalReportSR.SetParameterValue("pCompAdd2", DTControl11.Rows[0]["Address1"].ToString());
                        crystalReportSR.SetParameterValue("pTelno", DTControl11.Rows[0]["Tel"].ToString());
                        crystalReportSR.SetParameterValue("pGSTNo", "GST No. : " + DTControl11.Rows[0]["GSTNo"].ToString());
                        crystalReportSR.SetParameterValue("pCompStateCode", "State Code : " + DTControl11.Rows[0]["StateCode"].ToString());
                        crystalReportSR.SetParameterValue("pDLno", "DL No. : " + DTControl11.Rows[0]["Dlno"].ToString());
                        crystalReportSR.SetParameterValue("pCompCIN", "CIN : " + DTControl11.Rows[0]["CINNO"].ToString());
                        crystalReportSR.SetParameterValue("pCompEmail", "E mail : " + DTControl11.Rows[0]["Email"].ToString());
                        crystalReportSR.SetParameterValue("pFSSAINo", "FSSAI No. : " + DTControl11.Rows[0]["FoodLicNo"].ToString());
                    }

                    // DT For Customer
                    DataTable DTControl2 = GetCustomer(Convert.ToInt32(DDLCustomer.SelectedValue));
                    if (DTControl2.Rows.Count > 0)
                    {
                        crystalReportSR.SetParameterValue("PName", DTControl2.Rows[0]["Name"].ToString());
                        crystalReportSR.SetParameterValue("address1", DTControl2.Rows[0]["address"].ToString());
                        crystalReportSR.SetParameterValue("address2", DTControl2.Rows[0]["address1"].ToString());
                        crystalReportSR.SetParameterValue("address3", DTControl2.Rows[0]["address2"].ToString());
                        crystalReportSR.SetParameterValue("CustTel", "Tel. " + DTControl2.Rows[0]["telephone"].ToString());
                        crystalReportSR.SetParameterValue("CUstStateCode", "State Code : " + DTControl2.Rows[0]["StateCode"].ToString());
                        crystalReportSR.SetParameterValue("mInvNo", "MNN/19-20/ " + NoID);
                        crystalReportSR.SetParameterValue("vdt", Convert.ToDateTime(DSP.Tables[0].Rows[0]["vdt"]).ToString("dd/MM/yyyy"));
                        crystalReportSR.SetParameterValue("CustGST", DTControl2.Rows[0]["GSTNo"].ToString());
                        crystalReportSR.SetParameterValue("CustDLNo", DTControl2.Rows[0]["DLNo"].ToString() + "," + DTControl2.Rows[0]["DLNO1"].ToString());
                        crystalReportSR.SetParameterValue("CustFassaiNo", DTControl2.Rows[0]["DLNo"].ToString());
                    }

                    crystalReportSR.SetParameterValue("TotGrossGST28", GST28_GrossAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotGrossGST18", GST18_GrossAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotGrossGST12", GST12_GrossAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotGrossGST5", GST5_GrossAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotGrossGSTFree", GST0_GrossAmt.ToString("0.00"));

                    crystalReportSR.SetParameterValue("TotHsAmtGST28", GST28_Scm.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotHsAmtGST18", GST18_Scm.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotHsAmtGST12", GST12_Scm.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotHsAmtGST5", GST5_Scm.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotHsAmtGSTFree", GST0_Scm.ToString("0.00"));

                    crystalReportSR.SetParameterValue("TotDisGST28", GST28_DisAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotDisGST18", GST18_DisAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotDisGST12", GST12_DisAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotDisGST5", GST5_DisAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotDisGSTFree", GST0_DisAmt.ToString("0.00"));


                    crystalReportSR.SetParameterValue("TaxableGST28", GST28_Taxable.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TaxableGST18", GST18_Taxable.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TaxableGST12", GST12_Taxable.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TaxableGST5", GST5_Taxable.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TaxableGSTFree", GST0_Taxable.ToString("0.00"));


                    crystalReportSR.SetParameterValue("TotCGST28", GST28_CGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotCGST18", GST18_CGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotCGST12", GST12_CGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotCGST5", GST5_CGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotCGSTFree", GST0_CGSTAmt.ToString("0.00"));


                    crystalReportSR.SetParameterValue("TotSGST28", GST28_CGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotSGST18", GST18_CGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotSGST12", GST12_CGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotSGST5", GST5_CGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotSGSTFree", GST0_CGSTAmt.ToString("0.00"));


                    crystalReportSR.SetParameterValue("TotIGST28", GST28_IGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotIGST18", GST18_IGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotIGST12", GST12_IGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotIGST5", GST5_IGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("TotIGSTFree", GST0_IGSTAmt.ToString("0.00"));


                    crystalReportSR.SetParameterValue("T_GrossAmt", T_GrossAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("T_Scm", T_Scm.ToString("0.00"));
                    crystalReportSR.SetParameterValue("T_DisAmt", T_DisAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("T_Taxable", T_Taxable.ToString("0.00"));
                    crystalReportSR.SetParameterValue("T_CGSTAmt", T_CGSTAmt.ToString("0.00"));
                    crystalReportSR.SetParameterValue("T_IGSTAmt", T_IGSTAmt.ToString("0.00"));

                    crystalReportSR.SetParameterValue("NoOfItems", DTSRLedger.Rows.Count);
                    string QRy1 = "select acno,vdt, Vno,vtype, amt, dc, narr  from Trn where Vno='" + NoID + "' AND Acno='" + DDLCustomer.SelectedValue + "' and Vdt between '" + StartingDate.ToString("yyyy-MM-dd") + "' AND '" + EndingDate.ToString("yyyy-MM-dd") + "' ";
                    DataSet DSP1 = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy1);
                    if (DSP1.Tables[0].Rows.Count > 0)
                    {
                        double tds = Convert.ToDouble(DSP1.Tables[0].Rows[0]["amt"].ToString()) * 0.075 / 100;
                        double ntamt = Convert.ToDouble(DSP1.Tables[0].Rows[0]["amt"].ToString()) - tds;

                        DataTable DTACM = GetCustomer(Convert.ToInt32(DDLCustomer.SelectedValue));
                        if (DTACM.Rows[0]["TCS"].ToString().Equals("Y"))
                        {
                            crystalReportSR.SetParameterValue("Tcs", tds.ToString("0.00"));
                            crystalReportSR.SetParameterValue("ntamt", ntamt.ToString("0.00"));
                        }
                        else
                        {
                            crystalReportSR.SetParameterValue("Tcs", "");
                            crystalReportSR.SetParameterValue("ntamt", DSP1.Tables[0].Rows[0]["amt"].ToString());
                        }

                        crystalReportSR.SetParameterValue("BillAmount", DSP1.Tables[0].Rows[0]["amt"].ToString());
                        crystalReportSR.SetParameterValue("For", DTControl1.Rows[0]["Compname1"].ToString());
                        crystalReportSR.SetParameterValue("Towards1", AmountInWord(DSP1.Tables[0].Rows[0]["amt"].ToString()));
                    }
                    CrystalReportViewer3.ReportSource = crystalReportSR;
                    string FilePathBE = Server.MapPath("~/CryRpts/" + "SR-" + NoID + ".pdf");
                    crystalReportSR.ExportToDisk(ExportFormatType.PortableDocFormat, FilePathBE);

                    SRFileList.Add(FilePathBE);

                    crystalReportSR.Dispose();
                }
            }
            if (SaleReturnIDList.Capacity > 0)
            {
                CombineMultiplePDFs(SRFileList, Server.MapPath("~/CryRpts/FinalSR.pdf"));
                FinalFileList.Add(Server.MapPath("~/CryRpts/FinalSR.pdf"));
            }

            #endregion

            #region Generate Breakage Expiry Pdf

            foreach (int NoID in BreakageExpiraryList)
            {
                DataTable DTBELedger = new DataTable();
                if (DTBELedger.Columns.Count == 0)
                {
                    DTBELedger.Columns.Add("SR", typeof(int));
                    DTBELedger.Columns.Add("Qty", typeof(decimal));
                    DTBELedger.Columns.Add("Pack", typeof(string));
                    DTBELedger.Columns.Add("ProdDesc", typeof(string));
                    DTBELedger.Columns.Add("HSN", typeof(string));
                    DTBELedger.Columns.Add("Batch", typeof(string));
                    DTBELedger.Columns.Add("Expiry", typeof(string));
                    DTBELedger.Columns.Add("Mrp", typeof(decimal));
                    DTBELedger.Columns.Add("Rate", typeof(decimal));
                    DTBELedger.Columns.Add("Amount", typeof(decimal));
                    DTBELedger.Columns.Add("DIS", typeof(decimal));
                    DTBELedger.Columns.Add("SCM", typeof(decimal));
                    DTBELedger.Columns.Add("GST", typeof(decimal));
                    DTBELedger.Columns.Add("NetAmt", typeof(decimal));
                    DTBELedger.Columns.Add("Status", typeof(string));
                }

                decimal GST28_GrossAmt = 0, GST28_Scm = 0, GST28_DisAmt = 0, GST28_Taxable = 0, GST28_CGSTAmt = 0, GST28_IGSTAmt = 0;
                decimal GST18_GrossAmt = 0, GST18_Scm = 0, GST18_DisAmt = 0, GST18_Taxable = 0, GST18_CGSTAmt = 0, GST18_IGSTAmt = 0;
                decimal GST12_GrossAmt = 0, GST12_Scm = 0, GST12_DisAmt = 0, GST12_Taxable = 0, GST12_CGSTAmt = 0, GST12_IGSTAmt = 0;
                decimal GST5_GrossAmt = 0, GST5_Scm = 0, GST5_DisAmt = 0, GST5_Taxable = 0, GST5_CGSTAmt = 0, GST5_IGSTAmt = 0;
                decimal GST0_GrossAmt = 0, GST0_Scm = 0, GST0_DisAmt = 0, GST0_Taxable = 0, GST0_CGSTAmt = 0, GST0_IGSTAmt = 0;
                decimal T_GrossAmt = 0, T_Scm = 0, T_DisAmt = 0, T_Taxable = 0, T_CGSTAmt = 0, T_IGSTAmt = 0;

                // '2020-02-01' AND '2020-02-29'
                string QRy = "select * FROm SalePurchase2 WHERE Vdt between '" + StartingDate.ToString("yyyy-MM-dd") + "' AND '" + EndingDate.ToString("yyyy-MM-dd") + "' AND Acno='" + DDLCustomer.SelectedValue + "' AND Vno='" + NoID + "'";
                DataSet DSP = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy);
                if (DSP.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < DSP.Tables[0].Rows.Count; i++)
                    {
                        string QItemINBE = "SELECT * FROM Item WHERE code='" + DSP.Tables[0].Rows[i]["itemc"] + "'";
                        DataSet DSItemInBE = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QItemINBE);
                        if (DSItemInBE.Tables[0].Rows.Count > 0)
                        {
                            decimal IGST_TAX = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGST"]) + Convert.ToDecimal(DSP.Tables[0].Rows[i]["SGST"]);
                            decimal amt = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString()) * Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                            DTBELedger.Rows.Add(i + 1,
                                                DSP.Tables[0].Rows[i]["Qty"],
                                                DSItemInBE.Tables[0].Rows[0]["Pack"].ToString(),
                                                DSItemInBE.Tables[0].Rows[0]["Name"].ToString(),
                                                DSP.Tables[0].Rows[i]["HSNCode"].ToString(),
                                                DSP.Tables[0].Rows[i]["Batch"].ToString(),
                                                DSP.Tables[0].Rows[i]["expiry"].ToString(),
                                                DSP.Tables[0].Rows[i]["Mrp"].ToString(),
                                                DSP.Tables[0].Rows[i]["Ntrate"].ToString(),
                                                amt.ToString(),
                                                DSP.Tables[0].Rows[i]["Dis"].ToString(),
                                //DSP.Tables[0].Rows[i]["ScmPer"].ToString(),
                                               DSP.Tables[0].Rows[i]["hsamt"].ToString(),
                                                IGST_TAX.ToString("0.00"),
                                                DSP.Tables[0].Rows[i]["NetAmt"].ToString(),
                                                ((DSP.Tables[0].Rows[i]["betype"].ToString() == "B") ? "Brk." : (DSP.Tables[0].Rows[i]["betype"].ToString() == "E") ? "Exp.." : "NA"));
                            decimal Qty, Rate, GA, SCM, DA, Taxable, CGST, IGST;
                            switch (IGST_TAX.ToString("0.00"))
                            {
                                case "28.00":
                                    Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                    Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                    GA = Qty * Rate;
                                    //   SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                    SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                    DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                    Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                    IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                    CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                    GST28_GrossAmt += GA;
                                    GST28_Scm += SCM;
                                    GST28_DisAmt += DA;
                                    GST28_Taxable += Taxable;
                                    GST28_CGSTAmt += CGST;
                                    GST28_IGSTAmt += IGST;
                                    break;
                                case "18.00":
                                    Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                    Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                    GA = Qty * Rate;
                                    //  SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                    SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                    DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                    Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                    IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                    CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                    GST18_GrossAmt += GA;
                                    GST18_Scm += SCM;
                                    GST18_DisAmt += DA;
                                    GST18_Taxable += Taxable;
                                    GST18_CGSTAmt += CGST;
                                    GST18_IGSTAmt += IGST;
                                    break;
                                case "12.00":
                                    Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                    Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                    GA = Qty * Rate;
                                    //SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                    SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                    DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                    Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                    IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                    CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                    GST12_GrossAmt += GA;
                                    GST12_Scm += SCM;
                                    GST12_DisAmt += DA;
                                    GST12_Taxable += Taxable;
                                    GST12_CGSTAmt += CGST;
                                    GST12_IGSTAmt += IGST;
                                    break;
                                case "5.00":
                                    Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                    Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                    GA = Qty * Rate;
                                    // SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                    SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                    DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                    Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                    IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                    CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                    GST5_GrossAmt += GA;
                                    GST5_Scm += SCM;
                                    GST5_DisAmt += DA;
                                    GST5_Taxable += Taxable;
                                    GST5_CGSTAmt += CGST;
                                    GST5_IGSTAmt += IGST;
                                    break;
                                case "0.00":
                                    Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                    Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                    GA = Qty * Rate;
                                    // SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                    SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                    DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                    Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                    IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                    CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                    GST0_GrossAmt += GA;
                                    GST0_Scm += SCM;
                                    GST0_DisAmt += DA;
                                    GST0_Taxable += Taxable;
                                    GST0_CGSTAmt += CGST;
                                    GST0_IGSTAmt += IGST;
                                    break;
                                default:
                                    break;
                            }
                        }
                    }

                    T_GrossAmt = GST28_GrossAmt + GST18_GrossAmt + GST12_GrossAmt + GST5_GrossAmt + GST0_GrossAmt;
                    T_Scm = GST28_Scm + GST18_Scm + GST12_Scm + GST5_Scm + GST0_Scm;
                    T_DisAmt = GST28_DisAmt + GST18_DisAmt + GST12_DisAmt + GST5_DisAmt + GST0_DisAmt;
                    T_Taxable = GST28_Taxable + GST18_Taxable + GST12_Taxable + GST5_Taxable + GST0_Taxable;
                    T_CGSTAmt = GST28_CGSTAmt + GST18_CGSTAmt + GST12_CGSTAmt + GST5_CGSTAmt + GST0_CGSTAmt;
                    T_IGSTAmt = GST28_IGSTAmt + GST18_IGSTAmt + GST12_IGSTAmt + GST5_IGSTAmt + GST0_IGSTAmt;

                    crystalReportBE = new ReportDocument(); // creating object of crystal report
                    crystalReportBE.Load(Server.MapPath("~/CryRpts/DemoBE.rpt")); // path of report 
                    DataSet DSSR = new DataSet();
                    crystalReportBE.SetDataSource(DTBELedger); // binding dataSet

                    // Bind Company Info
                    DataTable DTControl12 = GetCompany();
                    if (DTControl12.Rows.Count > 0)
                    {
                        crystalReportBE.SetParameterValue("pCompanyName", DTControl12.Rows[0]["Compname1"].ToString());
                        crystalReportBE.SetParameterValue("pCompAdd1", DTControl12.Rows[0]["Address"].ToString());
                        crystalReportBE.SetParameterValue("pCompAdd2", DTControl12.Rows[0]["Address1"].ToString());
                        crystalReportBE.SetParameterValue("pTelno", DTControl12.Rows[0]["Tel"].ToString());
                        crystalReportBE.SetParameterValue("pGSTNo", "GST No. :" + DTControl12.Rows[0]["GSTNo"].ToString());
                        crystalReportBE.SetParameterValue("pCompStateCode", DTControl12.Rows[0]["StateCode"].ToString());
                        crystalReportBE.SetParameterValue("pDLno", "DL No. :" + DTControl12.Rows[0]["Dlno"].ToString());
                    }

                    // DT For Customer
                    DataTable DTControl2 = GetCustomer(Convert.ToInt32(DDLCustomer.SelectedValue));
                    if (DTControl2.Rows.Count > 0)
                    {
                        DateTime VdtDate = DateTime.Parse(DSP.Tables[0].Rows[0]["vdt"].ToString());
                        crystalReportBE.SetParameterValue("PName", DTControl2.Rows[0]["Name"].ToString());
                        crystalReportBE.SetParameterValue("address1", DTControl2.Rows[0]["address"].ToString());
                        crystalReportBE.SetParameterValue("address2", DTControl2.Rows[0]["address1"].ToString());
                        crystalReportBE.SetParameterValue("CustTel", DTControl2.Rows[0]["telephone"].ToString());
                        crystalReportBE.SetParameterValue("CUstStateCode", DTControl2.Rows[0]["StateCode"].ToString());
                        crystalReportBE.SetParameterValue("mInvNo", "BE / " + NoID);
                        crystalReportBE.SetParameterValue("vdt", VdtDate.ToString("dd/MM/yyyy"));
                        crystalReportBE.SetParameterValue("CustGST", DTControl2.Rows[0]["GSTNo"].ToString());
                        crystalReportBE.SetParameterValue("CustDLNo", DTControl2.Rows[0]["DLNo"].ToString());
                    }

                    crystalReportBE.SetParameterValue("TotGrossGST28", GST28_GrossAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotGrossGST18", GST18_GrossAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotGrossGST12", GST12_GrossAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotGrossGST5", GST5_GrossAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotGrossGSTFree", GST0_GrossAmt.ToString("0.00"));

                    crystalReportBE.SetParameterValue("TotHsAmtGST28", GST28_Scm.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotHsAmtGST18", GST18_Scm.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotHsAmtGST12", GST12_Scm.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotHsAmtGST5", GST5_Scm.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotHsAmtGSTFree", GST0_Scm.ToString("0.00"));

                    crystalReportBE.SetParameterValue("TotDisGST28", GST28_DisAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotDisGST18", GST18_DisAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotDisGST12", GST12_DisAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotDisGST5", GST5_DisAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotDisGSTFree", GST0_DisAmt.ToString("0.00"));


                    crystalReportBE.SetParameterValue("TaxableGST28", GST28_Taxable.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TaxableGST18", GST18_Taxable.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TaxableGST12", GST12_Taxable.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TaxableGST5", GST5_Taxable.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TaxableGSTFree", GST0_Taxable.ToString("0.00"));


                    crystalReportBE.SetParameterValue("TotCGST28", GST28_CGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotCGST18", GST18_CGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotCGST12", GST12_CGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotCGST5", GST5_CGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotCGSTFree", GST0_CGSTAmt.ToString("0.00"));


                    crystalReportBE.SetParameterValue("TotSGST28", GST28_CGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotSGST18", GST18_CGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotSGST12", GST12_CGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotSGST5", GST5_CGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotSGSTFree", GST0_CGSTAmt.ToString("0.00"));


                    crystalReportBE.SetParameterValue("TotIGST28", GST28_IGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotIGST18", GST18_IGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotIGST12", GST12_IGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotIGST5", GST5_IGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("TotIGSTFree", GST0_IGSTAmt.ToString("0.00"));

                    crystalReportBE.SetParameterValue("T_GrossAmt", T_GrossAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("T_Scm", T_Scm.ToString("0.00"));
                    crystalReportBE.SetParameterValue("T_DisAmt", T_DisAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("T_Taxable", T_Taxable.ToString("0.00"));
                    crystalReportBE.SetParameterValue("T_CGSTAmt", T_CGSTAmt.ToString("0.00"));
                    crystalReportBE.SetParameterValue("T_IGSTAmt", T_IGSTAmt.ToString("0.00"));


                    string QRy1 = "select acno,vdt, Vno,vtype, amt, dc, narr  from Trn where Vno='" + NoID + "' AND Acno='" + DDLCustomer.SelectedValue + "' and Vdt between '" + StartingDate.ToString("yyyy-MM-dd") + "' AND '" + EndingDate.ToString("yyyy-MM-dd") + "'";
                    DataSet DSP1 = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy1);
                    if (DSP1.Tables[0].Rows.Count > 0)
                    {
                        crystalReportBE.SetParameterValue("NoOfItems", DTBELedger.Rows.Count);
                        crystalReportBE.SetParameterValue("BillAmount", DSP1.Tables[0].Rows[0]["amt"].ToString());
                        crystalReportBE.SetParameterValue("For", DTControl1.Rows[0]["Compname1"].ToString());
                        crystalReportBE.SetParameterValue("Towards1", "Amount In Words :" + AmountInWord(DSP1.Tables[0].Rows[0]["amt"].ToString()));
                    }
                    CrystalReportViewer3.ReportSource = crystalReportBE;
                    string FilePathBE = Server.MapPath("~/CryRpts/" + "BE-" + NoID + ".pdf");
                    crystalReportBE.ExportToDisk(ExportFormatType.PortableDocFormat, FilePathBE);

                    BEFileList.Add(FilePathBE);

                    crystalReportBE.Dispose();
                }
            }

            if (BreakageExpiraryList.Capacity > 0)
            {
                if (BEFileList.Count > 0)
                {
                    CombineMultiplePDFs(BEFileList, Server.MapPath("~/CryRpts/FinalBE.pdf"));
                    FinalFileList.Add(Server.MapPath("~/CryRpts/FinalBE.pdf"));
                }
            }

            #endregion

            CombineMultiplePDFs(FinalFileList, Server.MapPath("~/CryRpts/FinalRpt" + DDLCustomer.SelectedValue + DDLMonth.SelectedItem.Text + ".pdf"));
            string selectedmonth = DDLMonth.SelectedItem.Text;
            string subPath = "D:/SMNPPL by LAXMAYA/generated PDF for STTMT & INVC/Statement/StmtFilesCurrent/" + selectedmonth;//DateTime.Now.ToString("MMMM"); // your code goes here
            //string subPath = "D:/Statement/StmtFilesCurrent/" + selectedmonth;//DateTime.Now.ToString("MMMM"); // your code goes here
            bool exists = System.IO.Directory.Exists(subPath);
            if (!exists)
            {
                System.IO.Directory.CreateDirectory(subPath);
            }
            //string pdfFile = Path.Combine(subPath, filename);

            CombineMultiplePDFs(FinalFileList, subPath + "/SMNPPL_" + DDLMonth.SelectedItem.ToString() + " Statement " + DDLCustomer.SelectedItem.ToString() + DDLCustomer.SelectedValue + ".pdf");

            string CombineFilePath = Server.MapPath("~/CryRpts/FinalRpt.pdf");

            string MailFilePath = subPath + "/SMNPPL_" + DDLMonth.SelectedItem.ToString() + " Statement "
                                                            + DDLCustomer.SelectedItem.ToString() + DDLCustomer.SelectedValue + ".pdf";

            try
            {
                SaveStatementFileToServer(MailFilePath, DDLCustomer.SelectedValue.ToString());
            }
            catch { }
            //  if (CBSingleMail.Checked)
            sendMailStmt(MailFilePath, DDLCustomer.SelectedValue);

            //#region Insert Resulted Data Into Server
            //SaveStatementFileToServer();
            //#endregion

        }
        catch (Exception ex)
        { }
    }

    #region Insert Resulted Data Into Server
    private void SaveStatementFileToServer(string filepath, string custID)
    {
        try
        {
            string[] file = filepath.Split('/');
            //string subfolder =  DateTime.Now.ToString("MMMM");
            string Pdf_FilePath = filepath;//"D:/Statement/StmtFilesCurrent/"+subfolder+"/SMNPPL_" + DDLMonth.SelectedItem.ToString() + " Statement " + DDLCustomer.SelectedItem.ToString() + DDLCustomer.SelectedValue + ".pdf";
            string Pdf_FileName = file[4];//"SMNPPL_" + DDLMonth.SelectedItem.ToString() + " Statement " + DDLCustomer.SelectedItem.ToString() + DDLCustomer.SelectedValue + ".pdf";
            string Pdf_ContentData = "application/pdf";
            FileStream fs = new FileStream(Pdf_FilePath, FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            Byte[] bytes = br.ReadBytes((Int32)fs.Length);
            br.Close();
            fs.Close();

            string Query_Select = "SELECT * FROM SMNPPL_SavedStatement WHERE Customer='" + custID
                + "' AND Month='" + DDLMonth.SelectedItem.ToString().Trim() + "' AND Year='" + TBYear.Text.Trim() + "'";
            DataSet DS_ExistingRecords = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Query_Select);
            if (DS_ExistingRecords.Tables[0].Rows.Count > 0)
            {

                //  string strQuery = "INSERT INTO SMNPPL_SavedStatement (Customer,Month,Year,FileName,FileContentType,FileData) values (@Customer,@Month,@Year,@FileName,@FileContentType,@FileData)";

                string strQuery = "UPDATE SMNPPL_SavedStatement set FileData = @FileData,updated_dt = @updated_dt where   ID='" + DS_ExistingRecords.Tables[0].Rows[0][0].ToString() + "'  ";
                SqlCommand cmd = new SqlCommand(strQuery);
                cmd.Parameters.Add("@FileData", SqlDbType.Binary).Value = bytes;
                cmd.Parameters.Add("@updated_dt", SqlDbType.VarChar).Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");//DateTime.Now.ToString("MM/dd/yyyy");

                String strConnString = System.Configuration.ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(strConnString);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    // return true;
                }

                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                    //  return false;
                }
                finally
                {
                    con.Close();
                    con.Dispose();

                }

            }
            else
            {

                string strQuery = "INSERT INTO SMNPPL_SavedStatement (Customer,Month,Year,FileName,FileContentType,FileData,EntDate) values (@Customer,@Month,@Year,@FileName,@FileContentType,@FileData,@EntDate)";
                SqlCommand cmd = new SqlCommand(strQuery);
                cmd.Parameters.Add("@Customer", SqlDbType.VarChar).Value = custID;
                cmd.Parameters.Add("@Month", SqlDbType.VarChar).Value = DDLMonth.SelectedItem.Text.ToString();
                cmd.Parameters.Add("@Year", SqlDbType.VarChar).Value = TBYear.Text.Trim().ToString();
                cmd.Parameters.Add("@FileName", SqlDbType.VarChar).Value = Pdf_FileName;
                cmd.Parameters.Add("@FileContentType", SqlDbType.VarChar).Value = Pdf_ContentData;
                cmd.Parameters.Add("@FileData", SqlDbType.Binary).Value = bytes;
                cmd.Parameters.Add("@EntDate", SqlDbType.VarChar).Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"); //DateTime.Now.ToString("MM/dd/yyyy");
                String strConnString = System.Configuration.ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(strConnString);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    // return true;
                }

                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                    //  return false;
                }
                finally
                {
                    con.Close();
                    con.Dispose();
                }
            }

        }
        catch (Exception ex)
        {

        }
    }
    #endregion

    protected void LBGetAPI_Click(object sender, EventArgs e)
    {
        //"../ProvideFile.asmx/GetStatementRecord?jsn={"Action":"GET_STMT","CustID":"9203","Month":"May","Year":"2020"}");
        Response.Redirect("../ProvideFile.asmx");
    }

    private DataTable GetChequeDetails(string CustomerID)
    {
        DataTable DT = new DataTable();
        try
        {
            string FDate = TBYear.Text.Trim() + "-" + DDLMonth.SelectedValue.ToString() + "-" + "01";
            string qury = "select * from Trn where acno='" + CustomerID + "' and dc='Cr' and vtype='RT' and narr like 'CHQ%' AND vdt>'" + FDate + "'";
            DataSet DSp = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, qury);
            if (DSp.Tables[0].Rows.Count > 0)
                DT = DSp.Tables[0];
            else
            {
                if (DT.Columns.Count == 0)
                {
                    DT.Columns.Add("VoucherNo");
                    DT.Columns.Add("Date");
                    DT.Columns.Add("AccName");
                    DT.Columns.Add("Narration");
                    DT.Columns.Add("Debit");
                    DT.Columns.Add("Credit");
                }
            }

        }

        catch (Exception ex)
        { }
        return DT;
    }

    private string GetItem(int selIndex)
    {
        string SelectedItem = "";
        try
        {
            int PreIndex = selIndex - 1;
            if (PreIndex == 0)
                PreIndex = DDLMonth.Items.Count - 1;

            SelectedItem = DDLMonth.Items[PreIndex].Text.ToString() + "-" + TBYear.Text.Trim().ToString();
        }
        catch (Exception ex)
        { }
        return SelectedItem;
    }

    private DataTable GetCompany()
    {
        DataTable DTCompany = new DataTable();
        try
        {
            string Qry = "SELECT * FROM Control";
            DataSet DSData = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (DSData.Tables[0].Rows.Count > 0)
                DTCompany = DSData.Tables[0];
        }
        catch (Exception ex)
        {

        }
        return DTCompany;
    }

    private DataTable GetCustomer(int CustID)
    {
        DataTable DTCust = new DataTable();
        try
        {
            string Qry = "SELECT * FROM Acm WHERE code='" + CustID + "'";
            DataSet DSData = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (DSData.Tables[0].Rows.Count > 0)
                DTCust = DSData.Tables[0];
        }
        catch (Exception ex)
        {

        }
        return DTCust;
    }

    private string AmountInWord(string p)
    {
        string isNegative = "";
        string number = Convert.ToDouble(p).ToString();

        if (number.Contains("-"))
        {
            isNegative = "Minus ";
            number = number.Substring(1, number.Length - 1);
        }
        if (number == "0")
        {
            return ("Zero Only");
        }
        else
        {
            return (isNegative + ConvertToWords(number));
        }
    }

    private static String ConvertToWords(String numb)
    {
        String val = "", wholeNo = numb, points = "", andStr = "", pointStr = "";
        String endStr = "Only";
        try
        {
            int decimalPlace = numb.IndexOf(".");
            if (decimalPlace > 0)
            {
                wholeNo = numb.Substring(0, decimalPlace);
                points = numb.Substring(decimalPlace + 1);
                if (Convert.ToInt32(points) > 0)
                {
                    andStr = "and";// just to separate whole numbers from points/cents  
                    endStr = "Paisa " + endStr;//Cents  
                    pointStr = ConvertDecimals(points);
                }
            }
            val = String.Format("{0} {1}{2} {3}", ConvertWholeNumber(wholeNo).Trim(), andStr, pointStr, endStr);
        }
        catch { }
        return val;
    }

    private static String ConvertWholeNumber(String Number)
    {
        string word = "";
        try
        {
            bool beginsZero = false;//tests for 0XX
            bool isDone = false;//test if already translated
            double dblAmt = (Convert.ToDouble(Number));
            //if ((dblAmt > 0) && number.StartsWith("0"))
            if (dblAmt > 0)
            {//test for zero or digit zero in a nuemric
                beginsZero = Number.StartsWith("0");

                int numDigits = Number.Length;
                int pos = 0;//store digit grouping
                String place = "";//digit grouping name:hundres,thousand,etc...
                switch (numDigits)
                {
                    case 1://ones' range

                        word = ones(Number);
                        isDone = true;
                        break;
                    case 2://tens' range
                        word = tens(Number);
                        isDone = true;
                        break;
                    case 3://hundreds' range
                        pos = (numDigits % 3) + 1;
                        place = " Hundred ";
                        break;
                    case 4://thousands' range
                    case 5:
                    case 6:
                        pos = (numDigits % 4) + 1;
                        place = " Thousand ";
                        break;
                    case 7://millions' range
                    case 8:
                    case 9:
                        pos = (numDigits % 7) + 1;
                        place = " Million ";
                        break;
                    case 10://Billions's range
                    case 11:
                    case 12:

                        pos = (numDigits % 10) + 1;
                        place = " Billion ";
                        break;
                    //add extra case options for anything above Billion...
                    default:
                        isDone = true;
                        break;
                }
                if (!isDone)
                {//if transalation is not done, continue...(Recursion comes in now!!)
                    if (Number.Substring(0, pos) != "0" && Number.Substring(pos) != "0")
                    {
                        try
                        {
                            word = ConvertWholeNumber(Number.Substring(0, pos)) + place + ConvertWholeNumber(Number.Substring(pos));
                        }
                        catch { }
                    }
                    else
                    {
                        word = ConvertWholeNumber(Number.Substring(0, pos)) + ConvertWholeNumber(Number.Substring(pos));
                    }

                    //check for trailing zeros
                    //if (beginsZero) word = " and " + word.Trim();
                }
                //ignore digit grouping names
                if (word.Trim().Equals(place.Trim())) word = "";
            }
        }
        catch { }
        return word.Trim();
    }

    private static String tens(String Number)
    {
        int _Number = Convert.ToInt32(Number);
        String name = null;
        switch (_Number)
        {
            case 10:
                name = "Ten";
                break;
            case 11:
                name = "Eleven";
                break;
            case 12:
                name = "Twelve";
                break;
            case 13:
                name = "Thirteen";
                break;
            case 14:
                name = "Fourteen";
                break;
            case 15:
                name = "Fifteen";
                break;
            case 16:
                name = "Sixteen";
                break;
            case 17:
                name = "Seventeen";
                break;
            case 18:
                name = "Eighteen";
                break;
            case 19:
                name = "Nineteen";
                break;
            case 20:
                name = "Twenty";
                break;
            case 30:
                name = "Thirty";
                break;
            case 40:
                name = "Fourty";
                break;
            case 50:
                name = "Fifty";
                break;
            case 60:
                name = "Sixty";
                break;
            case 70:
                name = "Seventy";
                break;
            case 80:
                name = "Eighty";
                break;
            case 90:
                name = "Ninety";
                break;
            default:
                if (_Number > 0)
                {
                    name = tens(Number.Substring(0, 1) + "0") + " " + ones(Number.Substring(1));
                }
                break;
        }
        return name;
    }

    private static String ones(String Number)
    {
        int _Number = Convert.ToInt32(Number);
        String name = "";
        switch (_Number)
        {

            case 1:
                name = "One";
                break;
            case 2:
                name = "Two";
                break;
            case 3:
                name = "Three";
                break;
            case 4:
                name = "Four";
                break;
            case 5:
                name = "Five";
                break;
            case 6:
                name = "Six";
                break;
            case 7:
                name = "Seven";
                break;
            case 8:
                name = "Eight";
                break;
            case 9:
                name = "Nine";
                break;
        }
        return name;
    }

    private static String ConvertDecimals(String number)
    {
        String cd = "", digit = "", engOne = "";
        for (int i = 0; i < number.Length; i++)
        {
            digit = number[i].ToString();
            if (digit.Equals("0"))
            {
                engOne = "Zero";
            }
            else
            {
                engOne = ones(digit);
            }
            cd += " " + engOne;
        }
        return cd;
    }

    private DataTable GenerateLedgerDS(string CsutomerID)
    {
        SaleReturnIDList = new List<int>();
        BreakageExpiraryList = new List<int>();
        TotalSales = 0; TotalBE = 0;

        DataTable DSLdgr1 = new DataTable();
        if (DSLdgr1.Columns.Count == 0)
        {
            DSLdgr1.Columns.Add("KeyValue", typeof(int));
            DSLdgr1.Columns.Add("VoucherNo", typeof(string));
            DSLdgr1.Columns.Add("Date", typeof(string));
            DSLdgr1.Columns.Add("AccName", typeof(string));
            DSLdgr1.Columns.Add("Narration", typeof(string));
            DSLdgr1.Columns.Add("Debit", typeof(decimal));
            DSLdgr1.Columns.Add("Credit", typeof(decimal));
        }

        DateTime StartingDate = new DateTime(Convert.ToInt32(TBYear.Text), Convert.ToInt32(DDLMonth.SelectedValue), 1);
        DateTime EndingDate = new DateTime(Convert.ToInt32(TBYear.Text), Convert.ToInt32(DDLMonth.SelectedValue), 1).AddMonths(1).AddDays(-1);
        foreach (DateTime date in GetDateRange(StartingDate, EndingDate))
        {
            string Qry11 = "select acno,vdt, Vno,vtype, amt, dc, narr  from Trn where acno='" + CsutomerID + "' and vdt ='" + date + "' and dc='Cr' ";
            DataSet ds11 = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry11);
            if (ds11.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds11.Tables[0].Rows.Count; i++)
                {
                    string AccName = "Sale";
                    string VoucherNo = CsutomerID + "/" + ds11.Tables[0].Rows[i]["Vno"].ToString();
                    string VoucherName = ds11.Tables[0].Rows[i]["vtype"].ToString();
                    if (VoucherName == "BE")
                    {
                        BreakageExpiraryList.Add(Convert.ToInt32(ds11.Tables[0].Rows[i]["Vno"].ToString()));
                        TotalBE += Convert.ToDecimal(ds11.Tables[0].Rows[i]["amt"].ToString());
                        VoucherNo = ds11.Tables[0].Rows[i]["vtype"].ToString() + " / " + ds11.Tables[0].Rows[i]["Vno"].ToString();
                        AccName = (VoucherName == "R5") ? "Sale Return" : (VoucherName == "BE") ? "Breakage Expiry" : "Sale";
                    }
                    else if (VoucherName == "R5")
                    {
                        SaleReturnIDList.Add(Convert.ToInt32(ds11.Tables[0].Rows[i]["vno"].ToString()));
                        TotalSales += Convert.ToDecimal(ds11.Tables[0].Rows[i]["amt"].ToString());
                        AccName = "Sale Return";
                        VoucherNo = ds11.Tables[0].Rows[i]["vtype"].ToString() + " / " + ds11.Tables[0].Rows[i]["Vno"].ToString();
                    }
                    else if (VoucherName == "RT")
                    {
                        AccName = "Payment Received";
                        VoucherNo = ds11.Tables[0].Rows[i]["vtype"].ToString() + " / " + ds11.Tables[0].Rows[i]["Vno"].ToString();
                    }
                    //DTSttLedger.Rows.Add(DDLCustomer.SelectedValue,
                    //                     VoucherNo,
                    //                     date.ToString("dd/MM/yyyy"),
                    //                     AccName,
                    //                     ds11.Tables[0].Rows[i]["narr"].ToString(),
                    //                     Convert.ToDecimal(0.00),
                    //                     Convert.ToDecimal(ds11.Tables[0].Rows[i]["amt"].ToString()));
                }
            }

            string Qry21 = "select acno,vdt, vno,vtype, amt, dc, narr  from Trn where acno='" + CsutomerID + "' and vdt = '" + date + "' and dc='Dr'";
            DataSet ds21 = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry21);
            if (ds21.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds21.Tables[0].Rows.Count; i++)
                {
                    string AccName = "Sale";
                    string VoucherNo = CsutomerID + "/" + ds21.Tables[0].Rows[i]["Vno"].ToString();
                    if (ds21.Tables[0].Rows[i]["vtype"].ToString() == "R5")
                    {
                        SaleReturnIDList.Add(Convert.ToInt32(ds21.Tables[0].Rows[i]["vno"].ToString()));
                        TotalSales += Convert.ToDecimal(ds11.Tables[0].Rows[i]["amt"].ToString());
                        VoucherNo = ds21.Tables[0].Rows[i]["vtype"].ToString() + " / " + ds21.Tables[0].Rows[i]["Vno"].ToString();
                        AccName = "Sale Return";
                    }
                    else if (ds21.Tables[0].Rows[i]["vtype"].ToString() == "BE")
                    {
                        BreakageExpiraryList.Add(Convert.ToInt32(ds21.Tables[0].Rows[i]["vno"].ToString()));
                        TotalBE += Convert.ToDecimal(ds11.Tables[0].Rows[i]["amt"].ToString());
                        VoucherNo = ds21.Tables[0].Rows[i]["vtype"].ToString() + " / " + ds21.Tables[0].Rows[i]["Vno"].ToString();
                        AccName = "Breakage Expiry";
                    }
                    else
                    {
                        DSLdgr1.Rows.Add(CsutomerID,
                                             VoucherNo,
                                             date.ToString("dd/MM/yyyy"),
                                             AccName,
                                             ds21.Tables[0].Rows[i]["narr"].ToString(),
                                             Convert.ToDecimal(ds21.Tables[0].Rows[i]["amt"].ToString()),
                                             Convert.ToDecimal(0.00));
                    }
                }
            }
        }
        return DSLdgr1;
    }

    private DataSet FilterRec(string CustID, string DumpMonth)
    {
        DataSet DSReturn = new DataSet();
        try
        {
            //string Qry = "SELECT * FROM SMNPPLMonthlyStmtTracker   WHERE SMNPPLMonthlyStmtTracker.DumpMonth='" + DumpMonth + "' AND SMNPPLMonthlyStmtTracker.KeyValue='" + CustID + "'";
            string Qry = "SELECT * FROM MonthlyStmtView WHERE MonthlyStmtView.KeyValue='" + CustID + "' AND MonthlyStmtView.MonthInfo='" + DumpMonth + "'";
            DSReturn = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (DSReturn.Tables[0].Rows.Count > 0)
            {
                gvjob.DataSource = DSReturn.Tables[0];
                gvjob.DataBind();
            }
        }
        catch (Exception ex)
        { }
        return DSReturn;
    }

    private DataSet FilterRecAll(string DumpMonth)
    {
        DataSet DSReturn = new DataSet();
        try
        {
            //string Qry = "SELECT * FROM SMNPPLMonthlyStmtTracker   WHERE SMNPPLMonthlyStmtTracker.DumpMonth='" + DumpMonth + "' AND SMNPPLMonthlyStmtTracker.KeyValue='" + CustID + "'";
            string Qry = "SELECT * FROM MonthlyStmtView WHERE  MonthlyStmtView.MonthInfo='" + DumpMonth + "'";
            DSReturn = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (DSReturn.Tables[0].Rows.Count > 0)
            {
                gvjob.DataSource = DSReturn.Tables[0];
                gvjob.DataBind();
            }
        }
        catch (Exception ex)
        { }
        return DSReturn;
    }

    private List<DateTime> GetDateRange(DateTime StartingDate, DateTime EndingDate)
    {
        if (StartingDate > EndingDate)
        {
            return null;
        }
        List<DateTime> rv = new List<DateTime>();
        DateTime tmpDate = StartingDate;
        do
        {
            rv.Add(tmpDate);
            tmpDate = tmpDate.AddDays(1);
        } while (tmpDate <= EndingDate);
        return rv;
    }

    string SttpdfFile = "E:\\Testcrystal.pdf";
    string SRpdfFile = "E:\\Testcrystal1.pdf";
    string BEpdfFile = "E:\\Testcrystal2.pdf";

    string SttpdfFilePath = "";
    string SRpdfFilePath = "";
    string BEpdfFilePath = "";

    protected void LBshowRpt_Click(object sender, EventArgs e)
    {
        try
        {
            //ReportDocument crystalReport = new ReportDocument(); // creating object of crystal report
            //crystalReport.Load(Server.MapPath("~/CryRpts/Demo.rpt")); // path of report 
            //CrystalReportViewer1.ReportSource = crystalReport;

            ReportDocument crystalReport = new ReportDocument(); // creating object of crystal report
            crystalReport.Load(Server.MapPath("~/CryRpts/Test.rpt")); // path of report 
            //crystalReport.SetDataSource(DTSttLedger); // binding datatable
            CrystalReportViewer1.ReportSource = crystalReport;

            crystalReport.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, false, SttpdfFile);
            //crystalReport.ExportToDisk(ExportFormatType.PortableDocFormat, SttpdfFile);
            //sendMail(SttpdfFile);


            //crystalReport.ExportToHttpResponse(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, Response, true, "PersonDetails");
            //here i have use [ CrystalDecisions.Shared.ExportFormatType.PortableDocFormat ] to Export in PDF
        }
        catch (Exception ex)
        { }
    }

    #region Mail With Attachments
    private void sendMail(string pdfFile)
    {
        MailMessage msg = new MailMessage();
        try
        {
            //msg.From = new MailAddress("contactus@shreemarutinandan.com");
            msg.From = new MailAddress("laxmayatech@gmail.com");
            msg.To.Add("abhi.laxmaya@gmail.com");
            msg.Body = "Employee Record";
            msg.Attachments.Add(new Attachment(pdfFile));
            msg.IsBodyHtml = true;
            msg.Subject = "Emp Data Report uptil " + DateTime.Now.ToString() + " date";
            SmtpClient smt = new SmtpClient("smtp.gmail.com");
            smt.Port = 587;
          //  smt.Credentials = new NetworkCredential("contactus@shreemarutinandan.com", "SHREEALL123");
            smt.Credentials = new NetworkCredential("laxmayatech@gmail.com", "laxmaya1379");
            smt.EnableSsl = true;
            smt.Send(msg);
            string script = "<script>alert('Mail Sent Successfully')</script>";
            ClientScript.RegisterStartupScript(this.GetType(), "mailSent", script);
        }
        catch (Exception ex)
        {
            string script = "<script>alert(' SendMail::" + ex.Message + "')</script>";
            ClientScript.RegisterStartupScript(this.GetType(), "Error", script);
        }
        finally
        {
            msg.Dispose();
        }
    }

    private void sendMailStmt(string pdfFile, string CustID)
    {
        string CustEmail = "";
        string QryCustDetails = "SELECT * FROM Acm WHERE [code]='" + CustID + "'";
        DataSet DSCustDetails = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QryCustDetails);
        if (DSCustDetails.Tables[0].Rows.Count > 0)
        {
            CustEmail = DSCustDetails.Tables[0].Rows[0]["EMail"].ToString(); //"ritu.laxmayatechnologies@gmail.com";//
            string CustName = DSCustDetails.Tables[0].Rows[0]["Name"].ToString();

            if (CustEmail.Length > 0 && (CBSingleMail.Checked == true || CBAllMail.Checked == true)) //if (CustEmail.Length > 0)
            {
                MailMessage msg = new MailMessage();
                try
                {
                    string[] file = pdfFile.Split('/');

                    msg.From = new MailAddress("contactus@shreemarutinandan.com");
                    //msg.From = new MailAddress("laxmayatech@gmail.com");
                    msg.To.Add(CustEmail);
                    Attachment attachment;
                    attachment = new Attachment(pdfFile);
                    attachment.Name = file[4];
                    //  msg.Attachments.Add(new Attachment(pdfFile));
                    msg.Attachments.Add(attachment);

                    msg.IsBodyHtml = false;
                    string mailbody = "Dear " + CustName + " \r\n"
                                              + " Please find attached the copy of the Statement.";
                    msg.Body = mailbody;
                    msg.Subject = CustID + " Statement Report Of Month " + DDLMonth.SelectedItem.Text;
                    SmtpClient smt = new SmtpClient("smtp.gmail.com");
                    smt.Port = 587;
                    smt.Credentials = new NetworkCredential("contactus@shreemarutinandan.com", "shreeall123");
                    //smt.Credentials = new NetworkCredential("laxmayatech@gmail.com", "laxmaya1379");
                    smt.EnableSsl = true;
                    smt.Send(msg);
                    string script = "<script>alert('Mail Sent Successfully')</script>";
                    ClientScript.RegisterStartupScript(this.GetType(), "mailSent", script);
                }
                catch (Exception ex)
                {
                    //string script = "<script>alert('Mail Ex:" + ex.Message + "')</script>";
                    //ClientScript.RegisterStartupScript(this.GetType(), "Error", script);
                    saveFailMAil(pdfFile, DSCustDetails);
                }
                finally
                {
                    msg.Dispose();
                }
            }
            else
            {
                saveFailMAil(pdfFile, DSCustDetails);
            }

        }
    }

    public void saveFailMAil(string pdfFile, DataSet DSCustDetails)
    {
        try
        {
            string CustId = DSCustDetails.Tables[0].Rows[0]["Code"].ToString();
            string CustMob = DSCustDetails.Tables[0].Rows[0]["mobile"].ToString();
            string cname = DSCustDetails.Tables[0].Rows[0]["Name"].ToString();
            string sql = "INSERT INTO send_log_new VALUES ('" + CustMob + "','Failed to send email from webserver', 'Email Failed', 'WEBSERVER', '" + DateTime.Now.ToString() + "'," + CustId + ",'WEBSERVER')";
            int Result = SqlHelper.ExecuteNonQuery(Connection.connects(), CommandType.Text, sql);
            string selectedmonth = DDLMonth.SelectedItem.Text; //DateTime.Now.ToString("MMMM")
            string subPath = "D:/SMNPPL by LAXMAYA/generated PDF for STTMT & INVC/Statement/StmtFilesFail/" + selectedmonth + "/"; // your code goes here
       //     string subPath = "D:/Statement/StmtFilesFail/" + selectedmonth + "/"; // your code goes here
            bool exists = System.IO.Directory.Exists(subPath);
            if (!exists)
            { System.IO.Directory.CreateDirectory(subPath); }
            File.Move(pdfFile, Path.Combine(@"D:SMNPPL by LAXMAYA\generated PDF for STTMT & INVC\Statement\StmtFilesFail\" + selectedmonth, Path.GetFileName(pdfFile)));
            // SaveStatementFileToServer(subPath + Path.GetFileName(pdfFile));
        }
        catch (Exception e)
        {
            e.Message.ToString();
        }

    }


    #endregion

    #region PDF Merger
    public static void CombineMultiplePDFs(List<string> fileNames, string outFile)
    {
        // step 1: creation of a document-object
        Document document = new Document();
        //create newFileStream object which will be disposed at the end
        using (FileStream newFileStream = new FileStream(outFile, FileMode.Create))
        {
            // step 2: we create a writer that listens to the document
            PdfCopy writer = new PdfCopy(document, newFileStream);
            if (writer == null)
            {
                return;
            }

            // step 3: we open the document
            document.Open();

            foreach (string fileName in fileNames)
            {
                // we create a reader for a certain document
                PdfReader reader = new PdfReader(fileName);
                reader.ConsolidateNamedDestinations();

                // step 4: we add content
                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    PdfImportedPage page = writer.GetImportedPage(reader, i);
                    writer.AddPage(page);
                }

                PRAcroForm form = reader.AcroForm;
                if (form != null)
                {
                    writer.CopyAcroForm(reader);
                }

                reader.Close();
            }

            // step 5: we close the document and writer
            writer.Close();
            document.Close();
        }//disposes the newFileStream object
    }
    #endregion


    #region Automatic Statement Record  Work

    protected void LBAutomaticStmt_Click(object sender, EventArgs e)
    {
        try
        {
            // Get Customer Record From MonthlyStmtView
            string CurrMonth = DDLMonth.SelectedItem.Text.Trim().ToString() + "-" + TBYear.Text.Trim().ToString();
            DataSet CusMonthStmt = new DataSet();
            CusMonthStmt = FilterRecAll(CurrMonth);

            DateTime StartingDate = new DateTime(Convert.ToInt32(TBYear.Text), Convert.ToInt32(DDLMonth.SelectedValue), 1);
            DateTime EndingDate = new DateTime(Convert.ToInt32(TBYear.Text), Convert.ToInt32(DDLMonth.SelectedValue), 1).AddMonths(1).AddDays(-1);

            if (CusMonthStmt.Tables[0].Rows.Count > 0)
            {
                for (int x = 0; x < CusMonthStmt.Tables[0].Rows.Count; x++)
                {
                    string CustomerIDAuto = CusMonthStmt.Tables[0].Rows[x]["KeyValue"].ToString();

                    // Generate Ledger DataSet
                    DataTable DTSttLedger = new DataTable();
                    DTSttLedger = GenerateLedgerDS(CustomerIDAuto);

                    if (DTSttLedger.Rows.Count > 0)
                    {

                        List<string> FinalFileList = new List<string>();
                        List<string> BEFileList = new List<string>();
                        List<string> SRFileList = new List<string>();

                        #region Generate Ledger PDF

                        DataTable DTChequeLdgr = GetChequeDetails(CustomerIDAuto);

                        crystalReportStt = new ReportDocument(); // creating object of crystal report
                        crystalReportStt.Load(Server.MapPath("~/CryRpts/CurrDemo.rpt")); // path of report 
                        //crystalReportStt.SetDataSource(DTSttLedger); // binding datatable
                        crystalReportStt.Database.Tables["LedgerRecord"].SetDataSource(DTSttLedger);
                        crystalReportStt.Database.Tables["LedgerChequeRecord"].SetDataSource(DTChequeLdgr);

                        // Bind Company Parameters
                        DataTable DTControl1 = GetCompany();
                        if (DTControl1.Rows.Count > 0)
                        {
                            crystalReportStt.SetParameterValue("pCompanyName", DTControl1.Rows[0]["Compname1"].ToString());
                            crystalReportStt.SetParameterValue("pCompAdd1", DTControl1.Rows[0]["Address"].ToString());
                            crystalReportStt.SetParameterValue("pCompAdd2", DTControl1.Rows[0]["Address1"].ToString());
                            crystalReportStt.SetParameterValue("pTelno", DTControl1.Rows[0]["Tel"].ToString());
                            crystalReportStt.SetParameterValue("pGSTNo", "GST No. :" + DTControl1.Rows[0]["GSTNo"].ToString());
                            crystalReportStt.SetParameterValue("pCompStateCode", "State Code :" + DTControl1.Rows[0]["StateCode"].ToString());
                            crystalReportStt.SetParameterValue("pCompCIN", "CIN" + DTControl1.Rows[0]["CINNO"].ToString());
                            crystalReportStt.SetParameterValue("pFSSAINo", "FASSAI NO. :" + DTControl1.Rows[0]["FoodLicNo"].ToString());
                            crystalReportStt.SetParameterValue("pDLno", "DL No. :" + DTControl1.Rows[0]["Dlno"].ToString());
                            crystalReportStt.SetParameterValue("pCompEmail", "E-Mail :" + DTControl1.Rows[0]["Email"].ToString());
                        }

                        // Bind Customer Info
                        DataTable DTAcm1 = GetCustomer(Convert.ToInt32(CustomerIDAuto));
                        if (DTAcm1.Rows.Count > 0)
                        {
                            crystalReportStt.SetParameterValue("PName", DTAcm1.Rows[0]["Name"].ToString());
                            crystalReportStt.SetParameterValue("address1", DTAcm1.Rows[0]["address"].ToString());
                            crystalReportStt.SetParameterValue("address2", DTAcm1.Rows[0]["address1"].ToString());
                            crystalReportStt.SetParameterValue("address3", DTAcm1.Rows[0]["address2"].ToString());
                            crystalReportStt.SetParameterValue("CustTel", DTAcm1.Rows[0]["telephone"].ToString());
                            crystalReportStt.SetParameterValue("CUstStateCode", DTAcm1.Rows[0]["StateCode"].ToString());
                            crystalReportStt.SetParameterValue("mInvNo", "");
                            crystalReportStt.SetParameterValue("vdt", DateTime.Now.ToString("dd/MM/yyyy"));
                            crystalReportStt.SetParameterValue("CustGST", DTAcm1.Rows[0]["GSTNo"].ToString());
                            crystalReportStt.SetParameterValue("CustDLNo", DTAcm1.Rows[0]["DLNO"].ToString());
                            crystalReportStt.SetParameterValue("CustFassaiNo", "");
                            crystalReportStt.SetParameterValue("pCustomerCode", DTAcm1.Rows[0]["Altercode"].ToString());
                            crystalReportStt.SetParameterValue("pKeyValue", DTAcm1.Rows[0]["code"].ToString());
                        }

                        string Qry = "SELECT * FROM MonthlyStmtView WHERE MonthlyStmtView.KeyValue='" + CustomerIDAuto + "' AND MonthlyStmtView.MonthInfo='" + CurrMonth + "'";
                        DataTable DTCustInfo = new DataTable();
                        DataSet DSReturn = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
                        if (DSReturn.Tables[0].Rows.Count > 0)
                        {
                            decimal PDue = (!string.IsNullOrEmpty(DSReturn.Tables[0].Rows[0]["PreviousDue"].ToString())) ? Convert.ToDecimal(DSReturn.Tables[0].Rows[0]["PreviousDue"].ToString()) : 0;
                            decimal TInvAmt = (!string.IsNullOrEmpty(DSReturn.Tables[0].Rows[0]["LastMonthSale"].ToString())) ? Convert.ToDecimal(DSReturn.Tables[0].Rows[0]["LastMonthSale"].ToString()) : 0;
                            decimal NetOutIncludingChq = (!string.IsNullOrEmpty(DSReturn.Tables[0].Rows[0]["LastMonthSale"].ToString())) ? Convert.ToDecimal(DSReturn.Tables[0].Rows[0]["NetOutInclCheq"].ToString()) : 0;

                            decimal NetCBDis;
                            if (!string.IsNullOrEmpty(DSReturn.Tables[0].Rows[0]["DiscountAmt"].ToString()))
                                NetCBDis = Convert.ToDecimal(DSReturn.Tables[0].Rows[0]["DiscountAmt"].ToString());
                            else
                                NetCBDis = 0;

                            // Calculations Logic As Provided by Client
                            decimal GrossDueAmt, PreviousDue, TotalDueAmt, PaymentReceived, NetDueAmt;
                            PreviousDue = (PDue <= 0) ? 0 : PDue;
                            GrossDueAmt = TInvAmt - (TotalSales + TotalBE + NetCBDis);
                            TotalDueAmt = GrossDueAmt + PreviousDue;

                            if (NetOutIncludingChq <= 0)
                                PaymentReceived = 0 - TotalDueAmt;
                            else
                                PaymentReceived = NetOutIncludingChq - TotalDueAmt;

                            NetDueAmt = TotalDueAmt + PaymentReceived;


                            //decimal NewDeu = Convert.ToDecimal(DSReturn.Tables[0].Rows[0]["LastMonthSale"].ToString()) - (TotalSales + TotalBE);
                            //string FinalDue = (NetOutIncludingChq <= 0) ? "-" + NewDeu : DSReturn.Tables[0].Rows[0]["PreviousDue"].ToString();
                            //string NetDue = (NetOutIncludingChq <= 0) ? "0.00" : DSReturn.Tables[0].Rows[0]["NetOutInclCheq"].ToString();

                            crystalReportStt.SetParameterValue("pTotalInvoiceValue", TInvAmt.ToString("0.00"));
                            crystalReportStt.SetParameterValue("pTotalGrossDueAmt", GrossDueAmt.ToString("0.00"));
                            crystalReportStt.SetParameterValue("pPreDueAmt", PreviousDue.ToString("0.00"));
                            crystalReportStt.SetParameterValue("pTotalBalanceDue", TotalDueAmt.ToString("0.00"));
                            crystalReportStt.SetParameterValue("pPaymentReceived", PaymentReceived.ToString("0.00"));
                            crystalReportStt.SetParameterValue("pNetDueAmount", NetDueAmt.ToString("0.00"));
                            crystalReportStt.SetParameterValue("pTotalDueAmt", TotalDueAmt.ToString("0.00"));
                            crystalReportStt.SetParameterValue("pCBDiscount", NetCBDis.ToString("0.00"));
                        }
                        else
                        {
                            crystalReportStt.SetParameterValue("pPreDueAmt", "0.00");
                            crystalReportStt.SetParameterValue("pTotalBalanceDue", "0.00");
                            crystalReportStt.SetParameterValue("pTotalInvoiceValue", "0.00");
                            crystalReportStt.SetParameterValue("pNetDueAmount", "0.00");
                            crystalReportStt.SetParameterValue("pTotalDueAmt", "0.00");
                            crystalReportStt.SetParameterValue("pTotalGrossDueAmt", "0.00");
                            crystalReportStt.SetParameterValue("pPaymentReceived", "0.00");
                            crystalReportStt.SetParameterValue("pCBDiscount", "0.00");
                        }

                        string LastMonth = GetItem(DDLMonth.SelectedIndex);
                        string QryLM = "SELECT * FROM MonthlyStmtView WHERE MonthlyStmtView.KeyValue='" + CustomerIDAuto + "' AND MonthlyStmtView.MonthInfo='" + LastMonth + "'";
                        DataTable DTCustInfoLM = new DataTable();
                        DataSet DSReturnLM = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QryLM);
                        if (DSReturnLM.Tables[0].Rows.Count > 0)
                            crystalReportStt.SetParameterValue("pOpeningBalance", DSReturnLM.Tables[0].Rows[0][13].ToString());
                        else
                            crystalReportStt.SetParameterValue("pOpeningBalance", "");


                        crystalReportStt.SetParameterValue("pTotalSalesReturn", TotalSales.ToString("0.00"));
                        crystalReportStt.SetParameterValue("pTotalBreakageExpirary", TotalBE.ToString("0.00"));
                        crystalReportStt.SetParameterValue("pMonthDetails", DDLMonth.SelectedItem.ToString() + TBYear.Text);

                        CrystalReportViewer1.ReportSource = crystalReportStt;

                        string pss = "";

                        if (DTSttLedger.Rows.Count > 0)
                            pss = DTSttLedger.Rows[0][0].ToString();
                        else
                            pss = "Data";
                        string FilePath = Server.MapPath("~/CryRpts/" + "Stt" + pss + ".pdf");
                        crystalReportStt.ExportToDisk(ExportFormatType.PortableDocFormat, FilePath);
                        FinalFileList.Add(FilePath);
                        crystalReportStt.Dispose();

                        #endregion

                        #region Generate Sale Return PDf
                        foreach (int NoID in SaleReturnIDList)
                        {
                            DataTable DTSRLedger = new DataTable();
                            if (DTSRLedger.Columns.Count == 0)
                            {
                                DTSRLedger.Columns.Add("Srn", typeof(int));
                                DTSRLedger.Columns.Add("ItName", typeof(string));
                                DTSRLedger.Columns.Add("HSNCode", typeof(string));
                                DTSRLedger.Columns.Add("Pack", typeof(string));
                                DTSRLedger.Columns.Add("Batch", typeof(string));
                                DTSRLedger.Columns.Add("Expiry", typeof(string));
                                DTSRLedger.Columns.Add("Mrp", typeof(decimal));
                                DTSRLedger.Columns.Add("NQty", typeof(decimal));
                                DTSRLedger.Columns.Add("Ftrate", typeof(decimal));
                                DTSRLedger.Columns.Add("Itamt", typeof(decimal));
                                DTSRLedger.Columns.Add("GST", typeof(decimal));
                                DTSRLedger.Columns.Add("ItDis", typeof(decimal));
                            }

                            decimal GST28_GrossAmt = 0, GST28_Scm = 0, GST28_DisAmt = 0, GST28_Taxable = 0, GST28_CGSTAmt = 0, GST28_IGSTAmt = 0;
                            decimal GST18_GrossAmt = 0, GST18_Scm = 0, GST18_DisAmt = 0, GST18_Taxable = 0, GST18_CGSTAmt = 0, GST18_IGSTAmt = 0;
                            decimal GST12_GrossAmt = 0, GST12_Scm = 0, GST12_DisAmt = 0, GST12_Taxable = 0, GST12_CGSTAmt = 0, GST12_IGSTAmt = 0;
                            decimal GST5_GrossAmt = 0, GST5_Scm = 0, GST5_DisAmt = 0, GST5_Taxable = 0, GST5_CGSTAmt = 0, GST5_IGSTAmt = 0;
                            decimal GST0_GrossAmt = 0, GST0_Scm = 0, GST0_DisAmt = 0, GST0_Taxable = 0, GST0_CGSTAmt = 0, GST0_IGSTAmt = 0;
                            decimal T_GrossAmt = 0, T_Scm = 0, T_DisAmt = 0, T_Taxable = 0, T_CGSTAmt = 0, T_IGSTAmt = 0;
                            //'2020-02-01' AND '2020-02-29'
                            string QRy = "select * FROm SalePurchase2 WHERE Vdt between '" + StartingDate.ToString("yyyy-MM-dd") + "' AND '" + EndingDate.ToString("yyyy-MM-dd") + "'  AND Acno='" + CustomerIDAuto + "' AND Vno='" + NoID + "'";
                            DataSet DSP = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy);
                            if (DSP.Tables[0].Rows.Count > 0)
                            {
                                for (int i = 0; i < DSP.Tables[0].Rows.Count; i++)
                                {
                                    string QItemINSR = "SELECT * FROM Item WHERE code='" + DSP.Tables[0].Rows[i]["itemc"] + "'";
                                    DataSet DSItemInSR = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QItemINSR);
                                    if (DSItemInSR.Tables[0].Rows.Count > 0)
                                    {
                                        decimal IGST_TAX = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGST"]) + Convert.ToDecimal(DSP.Tables[0].Rows[i]["SGST"]);
                                        decimal amt = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString()) * Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                        DTSRLedger.Rows.Add(i + 1,
                                                            DSItemInSR.Tables[0].Rows[0]["Name"].ToString(),
                                                            DSItemInSR.Tables[0].Rows[0]["HSNCode"].ToString(),//from salepurchase
                                                            DSItemInSR.Tables[0].Rows[0]["Pack"].ToString(),
                                                            DSP.Tables[0].Rows[i]["Batch"].ToString(),
                                                            DSP.Tables[0].Rows[i]["expiry"].ToString(),
                                                            DSP.Tables[0].Rows[i]["Mrp"].ToString(), //from salepurchase
                                                            DSP.Tables[0].Rows[i]["Qty"],
                                                            DSP.Tables[0].Rows[i]["Ntrate"].ToString(),
                                                            amt.ToString(),// ntrate*qty
                                                            IGST_TAX.ToString("0.00"),   //DSP.Tables[0].Rows[0]["IGST"].ToString(),  // CGST+SGST fro //from salepurchase
                                                            DSP.Tables[0].Rows[i]["Dis"].ToString());

                                        decimal Qty, Rate, GA, SCM, DA, Taxable, CGST, IGST;
                                        switch (IGST_TAX.ToString("0.00")) // CGST+SGST //from salepurchase
                                        {
                                            case "28.00":
                                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                                GA = Qty * Rate;
                                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());// use hsamt
                                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                                //decimal SGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["SGSTAmt"].ToString());
                                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                                GST28_GrossAmt += GA;
                                                GST28_Scm += SCM;
                                                GST28_DisAmt += DA;
                                                GST28_Taxable += Taxable;
                                                GST28_CGSTAmt += CGST;
                                                GST28_IGSTAmt += IGST;
                                                break;
                                            case "18.00":
                                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                                GA = Qty * Rate;
                                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                                GST18_GrossAmt += GA;
                                                GST18_Scm += SCM;
                                                GST18_DisAmt += DA;
                                                GST18_Taxable += Taxable;
                                                GST18_CGSTAmt += CGST;
                                                GST18_IGSTAmt += IGST;
                                                break;
                                            case "12.00":
                                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                                GA = Qty * Rate;
                                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                                GST12_GrossAmt += GA;
                                                GST12_Scm += SCM;
                                                GST12_DisAmt += DA;
                                                GST12_Taxable += Taxable;
                                                GST12_CGSTAmt += CGST;
                                                GST12_IGSTAmt += IGST;
                                                break;
                                            case "5.00":
                                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                                GA = Qty * Rate;
                                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                                GST5_GrossAmt += GA;
                                                GST5_Scm += SCM;
                                                GST5_DisAmt += DA;
                                                GST5_Taxable += Taxable;
                                                GST5_CGSTAmt += CGST;
                                                GST5_IGSTAmt += IGST;
                                                break;
                                            case "0.00":
                                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                                GA = Qty * Rate;
                                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString()); // corrcted by saurabh sir 
                                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                                GST0_GrossAmt += GA;
                                                GST0_Scm += SCM;
                                                GST0_DisAmt += DA;
                                                GST0_Taxable += Taxable;
                                                GST0_CGSTAmt += CGST;
                                                GST0_IGSTAmt += IGST;
                                                break;
                                            default:
                                                break;
                                        }
                                    }
                                }



                                T_GrossAmt = GST28_GrossAmt + GST18_GrossAmt + GST12_GrossAmt + GST5_GrossAmt + GST0_GrossAmt;
                                T_Scm = GST28_Scm + GST18_Scm + GST12_Scm + GST5_Scm + GST0_Scm;
                                T_DisAmt = GST28_DisAmt + GST18_DisAmt + GST12_DisAmt + GST5_DisAmt + GST0_DisAmt;
                                T_Taxable = GST28_Taxable + GST18_Taxable + GST12_Taxable + GST5_Taxable + GST0_Taxable;
                                T_CGSTAmt = GST28_CGSTAmt + GST18_CGSTAmt + GST12_CGSTAmt + GST5_CGSTAmt + GST0_CGSTAmt;
                                T_IGSTAmt = GST28_IGSTAmt + GST18_IGSTAmt + GST12_IGSTAmt + GST5_IGSTAmt + GST0_IGSTAmt;



                                crystalReportSR = new ReportDocument(); // creating object of crystal report
                                crystalReportSR.Load(Server.MapPath("~/CryRpts/DemoSR.rpt")); // path of report 
                                DataSet DSSR = new DataSet();
                                crystalReportSR.SetDataSource(DTSRLedger); // binding dataSet

                                // Bind Company Info
                                DataTable DTControl11 = GetCompany();
                                if (DTControl11.Rows.Count > 0)
                                {
                                    crystalReportSR.SetParameterValue("pCompanyName", DTControl11.Rows[0]["Compname1"].ToString());
                                    crystalReportSR.SetParameterValue("pCompAdd1", DTControl11.Rows[0]["Address"].ToString());
                                    crystalReportSR.SetParameterValue("pCompAdd2", DTControl11.Rows[0]["Address1"].ToString());
                                    crystalReportSR.SetParameterValue("pTelno", DTControl11.Rows[0]["Tel"].ToString());
                                    crystalReportSR.SetParameterValue("pGSTNo", "GST No. : " + DTControl11.Rows[0]["GSTNo"].ToString());
                                    crystalReportSR.SetParameterValue("pCompStateCode", "State Code : " + DTControl11.Rows[0]["StateCode"].ToString());
                                    crystalReportSR.SetParameterValue("pDLno", "DL No. : " + DTControl11.Rows[0]["Dlno"].ToString());
                                    crystalReportSR.SetParameterValue("pCompCIN", "CIN : " + DTControl11.Rows[0]["CINNO"].ToString());
                                    crystalReportSR.SetParameterValue("pCompEmail", "E mail : " + DTControl11.Rows[0]["Email"].ToString());
                                    crystalReportSR.SetParameterValue("pFSSAINo", "FSSAI No. : " + DTControl11.Rows[0]["FoodLicNo"].ToString());
                                }

                                // DT For Customer
                                DataTable DTControl2 = GetCustomer(Convert.ToInt32(CustomerIDAuto));
                                if (DTControl2.Rows.Count > 0)
                                {
                                    crystalReportSR.SetParameterValue("PName", DTControl2.Rows[0]["Name"].ToString());
                                    crystalReportSR.SetParameterValue("address1", DTControl2.Rows[0]["address"].ToString());
                                    crystalReportSR.SetParameterValue("address2", DTControl2.Rows[0]["address1"].ToString());
                                    crystalReportSR.SetParameterValue("address3", DTControl2.Rows[0]["address2"].ToString());
                                    crystalReportSR.SetParameterValue("CustTel", "Tel. " + DTControl2.Rows[0]["telephone"].ToString());
                                    crystalReportSR.SetParameterValue("CUstStateCode", "State Code : " + DTControl2.Rows[0]["StateCode"].ToString());
                                    crystalReportSR.SetParameterValue("mInvNo", "MNN/19-20/ " + NoID);
                                    crystalReportSR.SetParameterValue("vdt", Convert.ToDateTime(DSP.Tables[0].Rows[0]["vdt"]).ToString("dd/MM/yyyy"));
                                    crystalReportSR.SetParameterValue("CustGST", DTControl2.Rows[0]["GSTNo"].ToString());
                                    crystalReportSR.SetParameterValue("CustDLNo", DTControl2.Rows[0]["DLNo"].ToString());
                                    crystalReportSR.SetParameterValue("CustFassaiNo", DTControl2.Rows[0]["DLNo"].ToString());
                                }

                                crystalReportSR.SetParameterValue("TotGrossGST28", GST28_GrossAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotGrossGST18", GST18_GrossAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotGrossGST12", GST12_GrossAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotGrossGST5", GST5_GrossAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotGrossGSTFree", GST0_GrossAmt.ToString("0.00"));

                                crystalReportSR.SetParameterValue("TotHsAmtGST28", GST28_Scm.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotHsAmtGST18", GST18_Scm.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotHsAmtGST12", GST12_Scm.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotHsAmtGST5", GST5_Scm.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotHsAmtGSTFree", GST0_Scm.ToString("0.00"));

                                crystalReportSR.SetParameterValue("TotDisGST28", GST28_DisAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotDisGST18", GST18_DisAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotDisGST12", GST12_DisAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotDisGST5", GST5_DisAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotDisGSTFree", GST0_DisAmt.ToString("0.00"));


                                crystalReportSR.SetParameterValue("TaxableGST28", GST28_Taxable.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TaxableGST18", GST18_Taxable.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TaxableGST12", GST12_Taxable.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TaxableGST5", GST5_Taxable.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TaxableGSTFree", GST0_Taxable.ToString("0.00"));


                                crystalReportSR.SetParameterValue("TotCGST28", GST28_CGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotCGST18", GST18_CGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotCGST12", GST12_CGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotCGST5", GST5_CGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotCGSTFree", GST0_CGSTAmt.ToString("0.00"));


                                crystalReportSR.SetParameterValue("TotSGST28", GST28_CGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotSGST18", GST18_CGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotSGST12", GST12_CGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotSGST5", GST5_CGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotSGSTFree", GST0_CGSTAmt.ToString("0.00"));


                                crystalReportSR.SetParameterValue("TotIGST28", GST28_IGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotIGST18", GST18_IGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotIGST12", GST12_IGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotIGST5", GST5_IGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("TotIGSTFree", GST0_IGSTAmt.ToString("0.00"));


                                crystalReportSR.SetParameterValue("T_GrossAmt", T_GrossAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("T_Scm", T_Scm.ToString("0.00"));
                                crystalReportSR.SetParameterValue("T_DisAmt", T_DisAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("T_Taxable", T_Taxable.ToString("0.00"));
                                crystalReportSR.SetParameterValue("T_CGSTAmt", T_CGSTAmt.ToString("0.00"));
                                crystalReportSR.SetParameterValue("T_IGSTAmt", T_IGSTAmt.ToString("0.00"));

                                crystalReportSR.SetParameterValue("NoOfItems", DTSRLedger.Rows.Count);
                                string QRy1 = "select acno,vdt, Vno,vtype, amt, dc, narr  from Trn where Vno='" + NoID + "' AND Acno='" + CustomerIDAuto + "' and Vdt between '" + StartingDate.ToString("yyyy-MM-dd") + "' AND '" + EndingDate.ToString("yyyy-MM-dd") + "'";
                                DataSet DSP1 = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy1);
                                if (DSP1.Tables[0].Rows.Count > 0)
                                {
                                    double tds = Convert.ToDouble(DSP1.Tables[0].Rows[0]["amt"].ToString()) * 0.075 / 100;
                                    double ntamt = Convert.ToDouble(DSP1.Tables[0].Rows[0]["amt"].ToString()) - tds;

                                    DataTable DTACM = GetCustomer(Convert.ToInt32(CustomerIDAuto));
                                    if (DTACM.Rows[0]["TCS"].ToString().Equals("Y"))
                                    {
                                        crystalReportSR.SetParameterValue("Tcs", tds.ToString("0.00"));
                                        crystalReportSR.SetParameterValue("ntamt", ntamt.ToString("0.00"));
                                    }
                                    else
                                    {
                                        crystalReportSR.SetParameterValue("Tcs", "");
                                        crystalReportSR.SetParameterValue("ntamt", DSP1.Tables[0].Rows[0]["amt"].ToString());
                                    }
                                    crystalReportSR.SetParameterValue("BillAmount", DSP1.Tables[0].Rows[0]["amt"].ToString());
                                    crystalReportSR.SetParameterValue("For", DTControl1.Rows[0]["Compname1"].ToString());
                                    crystalReportSR.SetParameterValue("Towards1", AmountInWord(DSP1.Tables[0].Rows[0]["amt"].ToString()));
                                }
                                CrystalReportViewer3.ReportSource = crystalReportSR;
                                string FilePathBE = Server.MapPath("~/CryRpts/" + "SR-" + NoID + ".pdf");
                                crystalReportSR.ExportToDisk(ExportFormatType.PortableDocFormat, FilePathBE);

                                SRFileList.Add(FilePathBE);

                                crystalReportSR.Dispose();
                            }
                        }
                        if (SaleReturnIDList.Capacity > 0)
                        {
                            CombineMultiplePDFs(SRFileList, Server.MapPath("~/CryRpts/FinalSR.pdf"));
                            FinalFileList.Add(Server.MapPath("~/CryRpts/FinalSR.pdf"));
                        }

                        #endregion

                        #region Generate Breakage Expiry Pdf

                        foreach (int NoID in BreakageExpiraryList)
                        {
                            DataTable DTBELedger = new DataTable();
                            if (DTBELedger.Columns.Count == 0)
                            {
                                DTBELedger.Columns.Add("SR", typeof(int));
                                DTBELedger.Columns.Add("Qty", typeof(decimal));
                                DTBELedger.Columns.Add("Pack", typeof(string));
                                DTBELedger.Columns.Add("ProdDesc", typeof(string));
                                DTBELedger.Columns.Add("HSN", typeof(string));
                                DTBELedger.Columns.Add("Batch", typeof(string));
                                DTBELedger.Columns.Add("Expiry", typeof(string));
                                DTBELedger.Columns.Add("Mrp", typeof(decimal));
                                DTBELedger.Columns.Add("Rate", typeof(decimal));
                                DTBELedger.Columns.Add("Amount", typeof(decimal));
                                DTBELedger.Columns.Add("DIS", typeof(decimal));
                                DTBELedger.Columns.Add("SCM", typeof(decimal));
                                DTBELedger.Columns.Add("GST", typeof(decimal));
                                DTBELedger.Columns.Add("NetAmt", typeof(decimal));
                                DTBELedger.Columns.Add("Status", typeof(string));
                            }

                            decimal GST28_GrossAmt = 0, GST28_Scm = 0, GST28_DisAmt = 0, GST28_Taxable = 0, GST28_CGSTAmt = 0, GST28_IGSTAmt = 0;
                            decimal GST18_GrossAmt = 0, GST18_Scm = 0, GST18_DisAmt = 0, GST18_Taxable = 0, GST18_CGSTAmt = 0, GST18_IGSTAmt = 0;
                            decimal GST12_GrossAmt = 0, GST12_Scm = 0, GST12_DisAmt = 0, GST12_Taxable = 0, GST12_CGSTAmt = 0, GST12_IGSTAmt = 0;
                            decimal GST5_GrossAmt = 0, GST5_Scm = 0, GST5_DisAmt = 0, GST5_Taxable = 0, GST5_CGSTAmt = 0, GST5_IGSTAmt = 0;
                            decimal GST0_GrossAmt = 0, GST0_Scm = 0, GST0_DisAmt = 0, GST0_Taxable = 0, GST0_CGSTAmt = 0, GST0_IGSTAmt = 0;
                            decimal T_GrossAmt = 0, T_Scm = 0, T_DisAmt = 0, T_Taxable = 0, T_CGSTAmt = 0, T_IGSTAmt = 0;

                            // '2020-02-01' AND '2020-02-29'
                            string QRy = "select * FROm SalePurchase2 WHERE Vdt between '" + StartingDate.ToString("yyyy-MM-dd") + "' AND '" + EndingDate.ToString("yyyy-MM-dd") + "' AND Acno='" + CustomerIDAuto + "' AND Vno='" + NoID + "'";
                            DataSet DSP = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy);
                            if (DSP.Tables[0].Rows.Count > 0)
                            {
                                for (int i = 0; i < DSP.Tables[0].Rows.Count; i++)
                                {
                                    string QItemINBE = "SELECT * FROM Item WHERE code='" + DSP.Tables[0].Rows[i]["itemc"] + "'";
                                    DataSet DSItemInBE = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QItemINBE);
                                    if (DSItemInBE.Tables[0].Rows.Count > 0)
                                    {
                                        decimal IGST_TAX = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGST"]) + Convert.ToDecimal(DSP.Tables[0].Rows[i]["SGST"]);
                                        decimal amt = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString()) * Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                        DTBELedger.Rows.Add(i + 1,
                                               DSP.Tables[0].Rows[i]["Qty"],
                                               DSItemInBE.Tables[0].Rows[0]["Pack"].ToString(),
                                               DSItemInBE.Tables[0].Rows[0]["Name"].ToString(),
                                               DSP.Tables[0].Rows[i]["HSNCode"].ToString(),
                                               DSP.Tables[0].Rows[i]["Batch"].ToString(),
                                               DSP.Tables[0].Rows[i]["expiry"].ToString(),
                                               DSP.Tables[0].Rows[i]["Mrp"].ToString(),
                                               DSP.Tables[0].Rows[i]["Ntrate"].ToString(),
                                               amt.ToString(),// use NTrate*Qty
                                               DSP.Tables[0].Rows[i]["Dis"].ToString(),
                                            //DSP.Tables[0].Rows[i]["ScmPer"].ToString(),
                                              DSP.Tables[0].Rows[i]["halfp"].ToString(),// use halfp instead of this
                                               IGST_TAX.ToString("0.00"),//cgst+sgst item wise 
                                               DSP.Tables[0].Rows[i]["NetAmt"].ToString(),
                                               ((DSP.Tables[0].Rows[i]["betype"].ToString() == "B") ? "Brk." : (DSP.Tables[0].Rows[i]["betype"].ToString() == "E") ? "Exp.." : "NA"));
                                        decimal Qty, Rate, GA, SCM, DA, Taxable, CGST, IGST;
                                        switch (DSP.Tables[0].Rows[0]["IGST"].ToString()) // cgst+sgst use 
                                        {
                                            case "28.00":
                                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                                GA = Qty * Rate;
                                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                                GST28_GrossAmt += GA;
                                                GST28_Scm += SCM;
                                                GST28_DisAmt += DA;
                                                GST28_Taxable += Taxable;
                                                GST28_CGSTAmt += CGST;
                                                GST28_IGSTAmt += IGST;
                                                break;
                                            case "18.00":
                                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                                GA = Qty * Rate;
                                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                                GST18_GrossAmt += GA;
                                                GST18_Scm += SCM;
                                                GST18_DisAmt += DA;
                                                GST18_Taxable += Taxable;
                                                GST18_CGSTAmt += CGST;
                                                GST18_IGSTAmt += IGST;
                                                break;
                                            case "12.00":
                                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                                GA = Qty * Rate;
                                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                                GST12_GrossAmt += GA;
                                                GST12_Scm += SCM;
                                                GST12_DisAmt += DA;
                                                GST12_Taxable += Taxable;
                                                GST12_CGSTAmt += CGST;
                                                GST12_IGSTAmt += IGST;
                                                break;
                                            case "5.00":
                                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                                GA = Qty * Rate;
                                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                                GST5_GrossAmt += GA;
                                                GST5_Scm += SCM;
                                                GST5_DisAmt += DA;
                                                GST5_Taxable += Taxable;
                                                GST5_CGSTAmt += CGST;
                                                GST5_IGSTAmt += IGST;
                                                break;
                                            case "0.00":
                                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                                GA = Qty * Rate;
                                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["hsamt"].ToString());
                                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                                GST0_GrossAmt += GA;
                                                GST0_Scm += SCM;
                                                GST0_DisAmt += DA;
                                                GST0_Taxable += Taxable;
                                                GST0_CGSTAmt += CGST;
                                                GST0_IGSTAmt += IGST;
                                                break;
                                            default:
                                                break;
                                        }
                                    }
                                }

                                T_GrossAmt = GST28_GrossAmt + GST18_GrossAmt + GST12_GrossAmt + GST5_GrossAmt + GST0_GrossAmt;
                                T_Scm = GST28_Scm + GST18_Scm + GST12_Scm + GST5_Scm + GST0_Scm;
                                T_DisAmt = GST28_DisAmt + GST18_DisAmt + GST12_DisAmt + GST5_DisAmt + GST0_DisAmt;
                                T_Taxable = GST28_Taxable + GST18_Taxable + GST12_Taxable + GST5_Taxable + GST0_Taxable;
                                T_CGSTAmt = GST28_CGSTAmt + GST18_CGSTAmt + GST12_CGSTAmt + GST5_CGSTAmt + GST0_CGSTAmt;
                                T_IGSTAmt = GST28_IGSTAmt + GST18_IGSTAmt + GST12_IGSTAmt + GST5_IGSTAmt + GST0_IGSTAmt;

                                crystalReportBE = new ReportDocument(); // creating object of crystal report
                                crystalReportBE.Load(Server.MapPath("~/CryRpts/DemoBE.rpt")); // path of report 
                                DataSet DSSR = new DataSet();
                                crystalReportBE.SetDataSource(DTBELedger); // binding dataSet

                                // Bind Company Info
                                DataTable DTControl12 = GetCompany();
                                if (DTControl12.Rows.Count > 0)
                                {
                                    crystalReportBE.SetParameterValue("pCompanyName", DTControl12.Rows[0]["Compname1"].ToString());
                                    crystalReportBE.SetParameterValue("pCompAdd1", DTControl12.Rows[0]["Address"].ToString());
                                    crystalReportBE.SetParameterValue("pCompAdd2", DTControl12.Rows[0]["Address1"].ToString());
                                    crystalReportBE.SetParameterValue("pTelno", DTControl12.Rows[0]["Tel"].ToString());
                                    crystalReportBE.SetParameterValue("pGSTNo", "GST No. :" + DTControl12.Rows[0]["GSTNo"].ToString());
                                    crystalReportBE.SetParameterValue("pCompStateCode", DTControl12.Rows[0]["StateCode"].ToString());
                                    crystalReportBE.SetParameterValue("pDLno", "DL No. :" + DTControl12.Rows[0]["Dlno"].ToString());
                                }

                                // DT For Customer
                                DataTable DTControl2 = GetCustomer(Convert.ToInt32(CustomerIDAuto));
                                if (DTControl2.Rows.Count > 0)
                                {
                                    crystalReportBE.SetParameterValue("PName", DTControl2.Rows[0]["Name"].ToString());
                                    crystalReportBE.SetParameterValue("address1", DTControl2.Rows[0]["address"].ToString());
                                    crystalReportBE.SetParameterValue("address2", DTControl2.Rows[0]["address1"].ToString());
                                    crystalReportBE.SetParameterValue("CustTel", DTControl2.Rows[0]["telephone"].ToString());
                                    crystalReportBE.SetParameterValue("CUstStateCode", DTControl2.Rows[0]["StateCode"].ToString());
                                    crystalReportBE.SetParameterValue("mInvNo", "BE / " + NoID);
                                    DateTime dt = Convert.ToDateTime(DSP.Tables[0].Rows[0]["vdt"].ToString());
                                    crystalReportBE.SetParameterValue("vdt", dt.ToString("dd/MM/yyyy"));
                                    crystalReportBE.SetParameterValue("CustGST", DTControl2.Rows[0]["GSTNo"].ToString());
                                    crystalReportBE.SetParameterValue("CustDLNo", DTControl2.Rows[0]["DLNo"].ToString());
                                }

                                crystalReportBE.SetParameterValue("TotGrossGST28", GST28_GrossAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotGrossGST18", GST18_GrossAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotGrossGST12", GST12_GrossAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotGrossGST5", GST5_GrossAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotGrossGSTFree", GST0_GrossAmt.ToString("0.00"));

                                crystalReportBE.SetParameterValue("TotHsAmtGST28", GST28_Scm.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotHsAmtGST18", GST18_Scm.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotHsAmtGST12", GST12_Scm.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotHsAmtGST5", GST5_Scm.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotHsAmtGSTFree", GST0_Scm.ToString("0.00"));

                                crystalReportBE.SetParameterValue("TotDisGST28", GST28_DisAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotDisGST18", GST18_DisAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotDisGST12", GST12_DisAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotDisGST5", GST5_DisAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotDisGSTFree", GST0_DisAmt.ToString("0.00"));


                                crystalReportBE.SetParameterValue("TaxableGST28", GST28_Taxable.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TaxableGST18", GST18_Taxable.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TaxableGST12", GST12_Taxable.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TaxableGST5", GST5_Taxable.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TaxableGSTFree", GST0_Taxable.ToString("0.00"));


                                crystalReportBE.SetParameterValue("TotCGST28", GST28_CGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotCGST18", GST18_CGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotCGST12", GST12_CGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotCGST5", GST5_CGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotCGSTFree", GST0_CGSTAmt.ToString("0.00"));


                                crystalReportBE.SetParameterValue("TotSGST28", GST28_CGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotSGST18", GST18_CGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotSGST12", GST12_CGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotSGST5", GST5_CGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotSGSTFree", GST0_CGSTAmt.ToString("0.00"));


                                crystalReportBE.SetParameterValue("TotIGST28", GST28_IGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotIGST18", GST18_IGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotIGST12", GST12_IGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotIGST5", GST5_IGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("TotIGSTFree", GST0_IGSTAmt.ToString("0.00"));

                                crystalReportBE.SetParameterValue("T_GrossAmt", T_GrossAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("T_Scm", T_Scm.ToString("0.00"));
                                crystalReportBE.SetParameterValue("T_DisAmt", T_DisAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("T_Taxable", T_Taxable.ToString("0.00"));
                                crystalReportBE.SetParameterValue("T_CGSTAmt", T_CGSTAmt.ToString("0.00"));
                                crystalReportBE.SetParameterValue("T_IGSTAmt", T_IGSTAmt.ToString("0.00"));


                                string QRy1 = "select acno,vdt, Vno,vtype, amt, dc, narr  from Trn where Vno='" + NoID + "' AND Acno='" + CustomerIDAuto + "'";
                                DataSet DSP1 = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy1);
                                if (DSP1.Tables[0].Rows.Count > 0)
                                {
                                    crystalReportBE.SetParameterValue("NoOfItems", DTBELedger.Rows.Count);
                                    crystalReportBE.SetParameterValue("BillAmount", DSP1.Tables[0].Rows[0]["amt"].ToString());
                                    crystalReportBE.SetParameterValue("For", DTControl1.Rows[0]["Compname1"].ToString());
                                    crystalReportBE.SetParameterValue("Towards1", "Amount In Words :" + AmountInWord(DSP1.Tables[0].Rows[0]["amt"].ToString()));
                                }
                                CrystalReportViewer3.ReportSource = crystalReportBE;
                                string FilePathBE = Server.MapPath("~/CryRpts/" + "BE-" + NoID + ".pdf");
                                crystalReportBE.ExportToDisk(ExportFormatType.PortableDocFormat, FilePathBE);

                                BEFileList.Add(FilePathBE);

                                crystalReportBE.Dispose();
                            }
                        }

                        if (BreakageExpiraryList.Capacity > 0)
                        {
                            CombineMultiplePDFs(BEFileList, Server.MapPath("~/CryRpts/FinalBE.pdf"));
                            FinalFileList.Add(Server.MapPath("~/CryRpts/FinalBE.pdf"));
                        }

                        #endregion

                        CombineMultiplePDFs(FinalFileList, Server.MapPath("~/CryRpts/FinalRpt" + CustomerIDAuto + DDLMonth.SelectedItem.Text + ".pdf"));
                        DataTable DTCUST = GetCustomer(Convert.ToInt32(CustomerIDAuto));
                        string CustName = DTCUST.Rows[0]["Name"].ToString();
                        string CustFinal = CustName.Replace("/", "--");

                        string CustAlCode = DTCUST.Rows[0]["Altercode"].ToString();
                        string CustAlCodeFinal = CustAlCode.Replace("*", "-");
                        string CustAlCodeFnal = CustAlCodeFinal.Replace("/", "-");
                        string selectedmonth = DDLMonth.SelectedItem.Text;
                        string subPath = "D:/SMNPPL by LAXMAYA/generated PDF for STTMT & INVC/Statement/StmtFilesCurrent/" + selectedmonth;//DateTime.Now.ToString("MMMM"); // your code goes here
                        bool exists = System.IO.Directory.Exists(subPath);
                        if (!exists)
                        {
                            System.IO.Directory.CreateDirectory(subPath);
                        }

                        CombineMultiplePDFs(FinalFileList, subPath + "/SMNPPL_" + DDLMonth.SelectedItem.ToString() + " Statement "
                                                            + CustFinal + " ( " + CustAlCodeFnal + " ) " + CustomerIDAuto + ".pdf");

                        string MailFilePath = subPath + "/SMNPPL_" + DDLMonth.SelectedItem.ToString() + " Statement "
                                                       + CustFinal + " ( " + CustAlCodeFnal + " ) " + CustomerIDAuto + ".pdf";

                        string CombineFilePath = Server.MapPath("~/CryRpts/FinalRpt.pdf");
                        //  if (CBAllMail.Checked)
                        try
                        {
                            SaveStatementFileToServer(MailFilePath, CustomerIDAuto);
                        }
                        catch { }
                        sendMailStmt(MailFilePath, CustomerIDAuto);

                        //#region Insert Resulted Data Into Server
                        //SaveStatementFileToServer();
                        //#endregion
                    }
                }
            }

        }
        catch (Exception ex)
        { }
    }


    protected void gvjob_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
            gvjob.PageIndex = e.NewPageIndex;
    }
    #endregion
}