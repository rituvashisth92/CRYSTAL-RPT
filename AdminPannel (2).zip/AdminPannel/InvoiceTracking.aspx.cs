﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Microsoft.ApplicationBlocks.Data;

public partial class AdminPannel_InvoiceTracking : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            BindRecords();
    }

    private void BindRecords()
    {
        try
        {
            DataTable DTInvTracking = new DataTable();
            if (DTInvTracking.Columns.Count == 0)
            {
                DTInvTracking.Columns.Add("TimeSlots", Type.GetType("System.String"));
                DTInvTracking.Columns.Add("OnPrinter", Type.GetType("System.Int32"));
                DTInvTracking.Columns.Add("UnderProcess", Type.GetType("System.Int32"));
                //DTInvTracking.Columns.Add("StoreIn", Type.GetType("System.Int32"));
                DTInvTracking.Columns.Add("StoreOut", Type.GetType("System.Int32"));
                //DTInvTracking.Columns.Add("Checking", Type.GetType("System.Int32"));
                DTInvTracking.Columns.Add("Modify", Type.GetType("System.Int32"));
                DTInvTracking.Columns.Add("DispatchOut", Type.GetType("System.Int32"));
                DTInvTracking.Columns.Add("NotProcessed", Type.GetType("System.Int32"));
                DTInvTracking.Columns.Add("GrandTotal", Type.GetType("System.Int32"));
            }

            string Qry1 = "select Distinct [time]  from esdata.dbo.InvoiceTrackingHourView a";
            DataSet DSTime=SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry1);
            if (DSTime.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < DSTime.Tables[0].Rows.Count; i++)
                {
                    string Qry = "select [time],[stage],COUNT(*)AS Counting  from esdata.dbo.InvoiceTrackingHourView a WHERE a.[time]='" 
                                 + DSTime.Tables[0].Rows[i]["time"].ToString() + "' Group By a.[time],a.[stage] Order By a.[time]";
                    DataSet ds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        string Time = DSTime.Tables[0].Rows[i]["time"].ToString();
                        int OnPrinter = 0, UnderProcess = 0, StoreIn = 0, StoreOut = 0,
                            Checking=0,Modify = 0, Dispatch = 0, NotProcess = 0, Total = 0;
                        for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                        {
                            switch (ds.Tables[0].Rows[j]["stage"].ToString())
                            {
                                case "2-On Printer":
                                    OnPrinter += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    Total += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    break;
                                case "3-Under Process":
                                    UnderProcess += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    Total += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    break;
                                //case "4-Store In":
                                //    StoreIn += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                //    Total += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                //    break;
                                case "5-Store out":
                                    StoreOut += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    Total += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    break;
                                //case "6-Checking":
                                //    Checking += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                //    Total += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                //    break;
                                case "7-Modify":
                                    Modify += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    Total += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    break;
                                case "8-Dispatch Out":
                                    Dispatch += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    Total += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    break;
                                case "1-Not Processed":
                                    NotProcess += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    Total += Convert.ToInt32(ds.Tables[0].Rows[j]["Counting"].ToString());
                                    break;
                                default:
                                    break;
                            }
                        }
                        // Bind DTTable Row
                        //DTInvTracking.Rows.Add(Time, OnPrinter, UnderProcess, StoreIn, StoreOut, Checking, Modify, Dispatch, NotProcess, Total);
                        DTInvTracking.Rows.Add(Time, OnPrinter, UnderProcess,  StoreOut,  Modify, Dispatch, NotProcess, Total);
                    }
                }
            }

            if (DTInvTracking.Rows.Count > 0)
            {
                GBTBTracking.DataSource = DTInvTracking;
                GBTBTracking.DataBind();
                int total = 0; ;
                GBTBTracking.FooterRow.Cells[0].Text = "Total";
                GBTBTracking.FooterRow.Cells[1].Font.Bold = true;
                GBTBTracking.FooterRow.Cells[0].HorizontalAlign = HorizontalAlign.Left;
                for (int k = 1; k < DTInvTracking.Columns.Count ; k++)
                {
                    total = DTInvTracking.AsEnumerable().Sum(row => row.Field<Int32>(DTInvTracking.Columns[k].ToString()));
                    GBTBTracking.FooterRow.Cells[k].Text = total.ToString();
                    GBTBTracking.FooterRow.Cells[k].Font.Bold = true;
                    GBTBTracking.FooterRow.BackColor = System.Drawing.Color.Beige;
                }
            }
            else
            {
                GBTBTracking.EmptyDataText = "No Record Found";
                GBTBTracking.DataBind();
            }
        }
        catch (Exception ex)
        { }
    }

    protected void LBRefresh_Click(object sender, EventArgs e)
    {
        try
        {
            BindRecords();
        }
        catch (Exception ex)
        { }
    }

    protected void GBTBTracking_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string TimeSlot = e.CommandArgument.ToString();
        string SyncTag = "";
        switch (e.CommandName.ToString())
        {
            case "OnPrinter":
                SyncTag = "2";
                break;
            case "UnderProcess":
                SyncTag = "3";
                break;
            case "StoreOut":
                SyncTag = "5";
                break;
            case "Modify":
                SyncTag = "7";
                break;
            case "DispatchOut":
                SyncTag = "8";
                break;
            case "NotProcessed":
                SyncTag = "9";
                break;
            default:
                break;
        }

        List<string> VnoList = new List<string>();

        string Qry_GetVnoList = "select DISTINCT [vno] from esdata.dbo.InvoiceTrackingHourView a WHERE a.[time]='"
                     + TimeSlot + "' and [SyncTag]='" + SyncTag + "' Order By a.[vno]";

        DataSet DS_VnoList = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry_GetVnoList);
        if (DS_VnoList.Tables[0].Rows.Count > 0)
        {
            for (int i = 0; i < DS_VnoList.Tables[0].Rows.Count; i++)
            {
                VnoList.Add(DS_VnoList.Tables[0].Rows[i]["vno"].ToString());
            }
        }
        if (VnoList.Count > 0)
        {
            string str = string.Empty;
            foreach (var item in VnoList)
                str = str + item + ",";

            str = str.Remove(str.Length - 1);

            string Qry = "Select a.vno, b.name, a.noOfItem,a.mTime from salepurchase1 a, acm b Where a.acno=b.code and a.vno in (" + str + ")";
            DataSet ds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (ds.Tables[0].Rows.Count > 0)
            {
                ModalPopupExtender1.Show();
                GVInvDetails.DataSource = ds.Tables[0];
                GVInvDetails.DataBind();
            }
        }
        else
        { }
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("../InvoiceTracking.aspx");
    }
}