﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using ClosedXML.Excel;
using Microsoft.ApplicationBlocks.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Net.Mail;
using System.Net;
using iTextSharp.text;
using System.IO;
using iTextSharp.text.pdf;

public partial class AdminPannel_NewInvoice : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string LastMinuts = "3600";
            Session["LastMinutes"] = LastMinuts;
            BindGridData(LastMinuts);
        }
        else {
           // callbtn();
        }
    }
    protected void LBFilter_Click(object sender, EventArgs e)
    {
        string LastMinuts = TBLastMinutes.Text.Trim();
        Session["LastMinutes"] = LastMinuts;
        BindGridData(LastMinuts);
    }

   

    private void BindGridData(string lastMinuts)
    {
        try
        {
            //string Qry = "select * from Salepurchase1 where SyncTag=7 and UpdatedOn > DATEADD(MINUTE, -" + lastMinuts + ", GETDATE()) and vtyp ='S5' order by UpdatedOn desc";
            string Qry = "select a.Vno,a.Vdt from BillTrackDet a where CONVERT(datetime, CONVERT(datetime, a.ScanDt, 5) + ' ' + a.mTime, 105) >DATEADD(MINUTE, -" + lastMinuts + ", GETDATE()) and Srl=2 and SubSrl=7";

            //string Qry = "SELECT * FROM InvoiceMaster";
            DataSet ds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvjob.DataSource = ds.Tables[0];
                gvjob.DataBind();
            }
            else
            {
                gvjob.DataSource = new DataTable();
                gvjob.DataBind();
                gvjob.EmptyDataText = "No Record Found!";
            }

        }
        catch (Exception ex)
        { }
    }

    protected void gvjob_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvjob.PageIndex = e.NewPageIndex;
            BindGridData(Session["LastMinutes"].ToString());
            gvjob.DataBind();
        }
        catch (Exception ex)
        { }
    }

    protected void gbjob_rowcommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            string VnoID = commandArgs[0];
            string AcnoID = commandArgs[1];

            //int VnoID = Convert.ToInt32(e.CommandArgument);
            //string AcnoID = "3320";
            Session["RecordID"] = VnoID;


            #region For Command MailRecord

            if (e.CommandName == "MailRecord")
            {
                GetExcelFile(Convert.ToInt32(VnoID));
                GetpdfFile(Convert.ToInt32(VnoID));
                string[] CustDetails = GetCustDetails(AcnoID);
                string CustName = "Laxmaya Technologies...."; // CustDetails[0];
                string CustEmail = "abhi.laxmaya@gmail.com"; // CustDetails[1];
                string MailSubject = VnoID + "  Invoice From SHREE MARUTI NANDAN PHARMACEUTICALS PVT.LTD.";
                string MailBody = @"Dear " + CustName + @",
                                
Please find attached the copy of the invoice. 

THANKS N REGARDS,
SHREE MARUTI NANDAN PHARMACEUTICALS PVT LTD.
NOIDA
CUSTOMER SATISFACTION IS OUR MOTO";

                SendEmail(CustEmail, MailSubject, MailBody);
            }

            #endregion
        }
        catch (Exception ex)
        { }
    }

    private string[] GetCustDetails(string Acno)
    {
        string[] CustMail = new string[2];
        try
        {
            string GetCustMail = "SELECT Name,Email FROM Acm WHERE code='" + Acno + "'";
            DataSet DSCustMail = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, GetCustMail);
            if (DSCustMail.Tables[0].Rows.Count > 0)
            {
                CustMail[0] = DSCustMail.Tables[0].Rows[0]["Name"].ToString();
                CustMail[1] = DSCustMail.Tables[0].Rows[0]["Email"].ToString();
            }
        }
        catch (Exception ex)
        { }
        return CustMail;
    }

    public void GetExcelFile(int VnoID)
    {
        DataSet ds = null;
        using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString))
        {
            try
            {
                string Qry = @"select b.name as Supplier, a.GSTVno as 'Bill NO.' , convert(varchar(10),a.Vdt,103) as date,e.name as company, c.Itemc as code,
                            d.Barcode,d.name,d.Pack,c.Batch, c.expiry,c.Qty, c.fqty,c.Halfp,c.Ftrate,c.Trate, c.Mrp,c.Dis,c.excise,a.Vat4 as VAT,c.AdnlVat,
                            c.NetAmt,c.LocalCent,c.scm1,c.scm2,c.ScmPer,c.HSNCode,c.CGST, c.SGST, c.igst from Salepurchase1 a, Acm b, Salepurchase2 c, Item d, Company e
                            where a.acno = b.code and a.Vno = c.Vno and a.Vdt = c.Vdt and c.Itemc = d.code and  a.Vno = '" + VnoID + "'  and d.Compcode = e.code order by d.name ";

                //string Qry = "SELECT * FROM InvoiceDetails WHERE InvID='" + VnoID + "'";

                SqlCommand cmd = new SqlCommand(Qry, con);
                cmd.CommandType = CommandType.Text;
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                ds = new DataSet();
                da.Fill(ds);
                ExportDataSetToExcel(ds);
                
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                ds.Dispose();
            }
        }
    }

    private void ExportDataSetToExcel(DataSet ds)
    {
        try
        {
            string AppLocation = "";
            AppLocation = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
            AppLocation = AppLocation.Replace("file:\\", "");
            string file = AppLocation + "\\ExcelFiles\\DataFile.xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(ds.Tables[0]);
                wb.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                wb.Style.Font.Bold = true;
                wb.SaveAs(file);
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    public void SendEmail(string MailTo, string MailSubject, string MailBody)
    {
        MailMessage mail = new MailMessage();
        try
        {
            string AppLocation = "";
            AppLocation = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase);
            AppLocation = AppLocation.Replace("file:\\", "");
            string file = AppLocation + "\\ExcelFiles\\DataFile.xlsx";

            
            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
            mail.From = new MailAddress("contactus@shreemarutinandan.com");

            mail.To.Add(MailTo);                            // Sending MailTo

            List<string> li = new List<string>();
            li.Add(MailTo);
            mail.CC.Add(string.Join<string>(",", li));       // Sending CC
            mail.Bcc.Add(string.Join<string>(",", li));      // Sending Bcc     
            mail.Subject = MailSubject;                      // Mail Subject
            mail.Body = MailBody;

            System.Net.Mail.Attachment attachment;
            attachment = new System.Net.Mail.Attachment(file); //Attaching File to Mail
            mail.Attachments.Add(attachment);

            SmtpServer.Port = Convert.ToInt32(587); //PORT
            SmtpServer.EnableSsl = true;
            SmtpServer.DeliveryMethod = SmtpDeliveryMethod.Network;
            SmtpServer.UseDefaultCredentials = true;
            SmtpServer.Credentials = new NetworkCredential("contactus@shreemarutinandan.com", "SHREEALL123");

            SmtpServer.Send(mail);
            string script = "<script>alert('Mail Sent Successfully')</script>";
            ClientScript.RegisterStartupScript(this.GetType(), "mailSent", script);
        }
        catch (Exception ex)
        {
            throw ex;
            string script = "<script>alert('" + ex.Message + "')</script>";
            ClientScript.RegisterStartupScript(this.GetType(), "Error", script);
        }
        finally
        {
            mail.Dispose();
        }
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        
        
    }

    private void UpdateJob(string JobID, string JobName, string p)
    {
        using (SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["LPConnectionString"].ConnectionString))
        {
            connection.Open();
            SqlCommand cmd = new SqlCommand("msdb.dbo.sp_update_jobschedule", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@job_id", SqlDbType.VarChar).Value = JobID;
            cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = "DailyJob";
            cmd.Parameters.Add("@freq_type", SqlDbType.VarChar).Value = 4;
            cmd.Parameters.Add("@freq_subday_interval", SqlDbType.VarChar).Value = p;
            cmd.ExecuteNonQuery();
            connection.Close();
        }
    }

    private void GetpdfFile(int VnoID)
    {
        List<int> SaleReturnIDList = new List<int>();
        List<string> FinalFileList = new List<string>();
        List<string> BEFileList = new List<string>();

        #region Generate Sale Return PDf
        foreach (int NoID in SaleReturnIDList)
        {
            DataTable DTForInvoice = new DataTable();
            if (DTForInvoice.Columns.Count == 0)
            {
                DTForInvoice.Columns.Add("Srn", typeof(int));
                DTForInvoice.Columns.Add("ItName", typeof(string));
                DTForInvoice.Columns.Add("HSNCode", typeof(string));
                DTForInvoice.Columns.Add("Pack", typeof(string));
                DTForInvoice.Columns.Add("Batch", typeof(string));
                DTForInvoice.Columns.Add("Expiry", typeof(string));
                DTForInvoice.Columns.Add("Mrp", typeof(decimal));
                DTForInvoice.Columns.Add("NQty", typeof(decimal));
                DTForInvoice.Columns.Add("Ftrate", typeof(decimal));
                DTForInvoice.Columns.Add("Itamt", typeof(decimal));
                DTForInvoice.Columns.Add("GST", typeof(decimal));
                DTForInvoice.Columns.Add("ItDis", typeof(decimal));
            }


            decimal GST28_GrossAmt = 0, GST28_Scm = 0, GST28_DisAmt = 0, GST28_Taxable = 0, GST28_CGSTAmt = 0, GST28_IGSTAmt = 0;
            decimal GST18_GrossAmt = 0, GST18_Scm = 0, GST18_DisAmt = 0, GST18_Taxable = 0, GST18_CGSTAmt = 0, GST18_IGSTAmt = 0;
            decimal GST12_GrossAmt = 0, GST12_Scm = 0, GST12_DisAmt = 0, GST12_Taxable = 0, GST12_CGSTAmt = 0, GST12_IGSTAmt = 0;
            decimal GST5_GrossAmt = 0, GST5_Scm = 0, GST5_DisAmt = 0, GST5_Taxable = 0, GST5_CGSTAmt = 0, GST5_IGSTAmt = 0;
            decimal GST0_GrossAmt = 0, GST0_Scm = 0, GST0_DisAmt = 0, GST0_Taxable = 0, GST0_CGSTAmt = 0, GST0_IGSTAmt = 0;
            decimal T_GrossAmt = 0, T_Scm = 0, T_DisAmt = 0, T_Taxable = 0, T_CGSTAmt = 0, T_IGSTAmt = 0;


            string QRy = "select * FROm SalePurchase2 WHERE Vdt between '2020-02-01' AND '2020-02-29' AND Acno='" + VnoID + "' AND Vno='" + NoID + "'";
            DataSet DSP = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy);
            if (DSP.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < DSP.Tables[0].Rows.Count; i++)
                {
                    string QItemINSR = "SELECT * FROM Item WHERE code='" + DSP.Tables[0].Rows[i]["itemc"] + "'";
                    DataSet DSItemInSR = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QItemINSR);
                    if (DSItemInSR.Tables[0].Rows.Count > 0)
                    {
                        DTForInvoice.Rows.Add(i + 1,
                                            DSItemInSR.Tables[0].Rows[0]["Name"].ToString(),
                                            DSItemInSR.Tables[0].Rows[0]["HSNCode"].ToString(),
                                            DSItemInSR.Tables[0].Rows[0]["Pack"].ToString(),
                                            DSP.Tables[0].Rows[i]["Batch"].ToString(),
                                            DSP.Tables[0].Rows[i]["expiry"].ToString(),
                                            DSItemInSR.Tables[0].Rows[0]["Mrp"].ToString(),
                                            DSP.Tables[0].Rows[i]["Qty"],
                                            DSP.Tables[0].Rows[i]["Ntrate"].ToString(),
                                            DSP.Tables[0].Rows[i]["NetAmt"].ToString(),
                                            DSItemInSR.Tables[0].Rows[0]["IGST"].ToString(),
                                            DSP.Tables[0].Rows[i]["Dis"].ToString());

                        decimal Qty, Rate, GA, SCM, DA, Taxable, CGST, IGST;
                        switch (DSItemInSR.Tables[0].Rows[0]["IGST"].ToString())
                        {
                            case "28.00":
                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                GA = Qty * Rate;
                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                GST28_GrossAmt += GA;
                                GST28_Scm += SCM;
                                GST28_DisAmt += DA;
                                GST28_Taxable += Taxable;
                                GST28_CGSTAmt += CGST;
                                GST28_IGSTAmt += IGST;
                                break;
                            case "18.00":
                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                GA = Qty * Rate;
                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                GST18_GrossAmt += GA;
                                GST18_Scm += SCM;
                                GST18_DisAmt += DA;
                                GST18_Taxable += Taxable;
                                GST18_CGSTAmt += CGST;
                                GST18_IGSTAmt += IGST;
                                break;
                            case "12.00":
                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                GA = Qty * Rate;
                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                GST12_GrossAmt += GA;
                                GST12_Scm += SCM;
                                GST12_DisAmt += DA;
                                GST12_Taxable += Taxable;
                                GST12_CGSTAmt += CGST;
                                GST12_IGSTAmt += IGST;
                                break;
                            case "5.00":
                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                GA = Qty * Rate;
                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                GST5_GrossAmt += GA;
                                GST5_Scm += SCM;
                                GST5_DisAmt += DA;
                                GST5_Taxable += Taxable;
                                GST5_CGSTAmt += CGST;
                                GST5_IGSTAmt += IGST;
                                break;
                            case "0.00":
                                Qty = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Qty"].ToString());
                                Rate = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Ntrate"].ToString());
                                GA = Qty * Rate;
                                SCM = Convert.ToDecimal(DSP.Tables[0].Rows[i]["scamt"].ToString());
                                DA = Convert.ToDecimal(DSP.Tables[0].Rows[i]["Disamt"].ToString());
                                Taxable = Convert.ToDecimal(DSP.Tables[0].Rows[i]["NetAmt"].ToString());
                                IGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["IGSTAmt"].ToString());
                                CGST = Convert.ToDecimal(DSP.Tables[0].Rows[i]["CGSTAmt"].ToString());

                                GST0_GrossAmt += GA;
                                GST0_Scm += SCM;
                                GST0_DisAmt += DA;
                                GST0_Taxable += Taxable;
                                GST0_CGSTAmt += CGST;
                                GST0_IGSTAmt += IGST;
                                break;
                            default:
                                break;
                        }
                    }
                }



                T_GrossAmt = GST28_GrossAmt + GST18_GrossAmt + GST12_GrossAmt + GST5_GrossAmt + GST0_GrossAmt;
                T_Scm = GST28_Scm + GST18_Scm + GST12_Scm + GST5_Scm + GST0_Scm;
                T_DisAmt = GST28_DisAmt + GST18_DisAmt + GST12_DisAmt + GST5_DisAmt + GST0_DisAmt;
                T_Taxable = GST28_Taxable + GST18_Taxable + GST12_Taxable + GST5_Taxable + GST0_Taxable;
                T_CGSTAmt = GST28_CGSTAmt + GST18_CGSTAmt + GST12_CGSTAmt + GST5_CGSTAmt + GST0_CGSTAmt;
                T_IGSTAmt = GST28_IGSTAmt + GST18_IGSTAmt + GST12_IGSTAmt + GST5_IGSTAmt + GST0_IGSTAmt;

                ReportDocument crystalReportSR = new ReportDocument(); // creating object of crystal report
                crystalReportSR.Load(Server.MapPath("~/CryRpts/DemoInvoice.rpt")); // path of report 
                DataSet DSSR = new DataSet();
                crystalReportSR.SetDataSource(DTForInvoice); // binding dataSet

                #region Bind Company Info
                DataTable DTControl11 = GetCompany();
                if (DTControl11.Rows.Count > 0)
                {
                    crystalReportSR.SetParameterValue("pCompanyName", DTControl11.Rows[0]["Compname1"].ToString());
                    crystalReportSR.SetParameterValue("pCompAdd1", DTControl11.Rows[0]["Address"].ToString());
                    crystalReportSR.SetParameterValue("pCompAdd2", DTControl11.Rows[0]["Address1"].ToString());
                    crystalReportSR.SetParameterValue("pTelno", DTControl11.Rows[0]["Tel"].ToString());
                    crystalReportSR.SetParameterValue("pGSTNo", "GST No. : " + DTControl11.Rows[0]["GSTNo"].ToString());
                    crystalReportSR.SetParameterValue("pCompStateCode", "State Code : " + DTControl11.Rows[0]["StateCode"].ToString());
                    crystalReportSR.SetParameterValue("pDLno", "DL No. : " + DTControl11.Rows[0]["Dlno"].ToString());
                    crystalReportSR.SetParameterValue("pCompCIN", "CIN : " + DTControl11.Rows[0]["CINNO"].ToString());
                    crystalReportSR.SetParameterValue("pCompEmail", "E mail : " + DTControl11.Rows[0]["Email"].ToString());
                    crystalReportSR.SetParameterValue("pFSSAINo", "FSSAI No. : " + DTControl11.Rows[0]["FoodLicNo"].ToString());
                }
                #endregion

                #region DT For Customer
               DataTable DTControl2 = GetCustomer(Convert.ToInt32(VnoID));
                
                if (DTControl2.Rows.Count > 0)
                {
                    crystalReportSR.SetParameterValue("PName", DTControl2.Rows[0]["Name"].ToString());
                    crystalReportSR.SetParameterValue("address1", DTControl2.Rows[0]["address"].ToString());
                    crystalReportSR.SetParameterValue("address2", DTControl2.Rows[0]["address1"].ToString());
                    crystalReportSR.SetParameterValue("address3", DTControl2.Rows[0]["address2"].ToString());
                    crystalReportSR.SetParameterValue("CustTel", "Tel. " + DTControl2.Rows[0]["telephone"].ToString());
                    crystalReportSR.SetParameterValue("CUstStateCode", "State Code : " + DTControl2.Rows[0]["StateCode"].ToString());
                    crystalReportSR.SetParameterValue("mInvNo", "MNN/19-20/ " + NoID);
                    crystalReportSR.SetParameterValue("vdt", Convert.ToDateTime(DSP.Tables[0].Rows[0]["vdt"]).ToString("dd/MM/yyyy"));
                    crystalReportSR.SetParameterValue("CustGST", DTControl2.Rows[0]["GSTNo"].ToString());
                    crystalReportSR.SetParameterValue("CustDLNo", DTControl2.Rows[0]["DLNo"].ToString());
                    crystalReportSR.SetParameterValue("CustFassaiNo", DTControl2.Rows[0]["DLNo"].ToString());
                }
                #endregion

                #region OtherParameters

                crystalReportSR.SetParameterValue("TotGrossGST28", GST28_GrossAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotGrossGST18", GST18_GrossAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotGrossGST12", GST12_GrossAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotGrossGST5", GST5_GrossAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotGrossGSTFree", GST0_GrossAmt.ToString("0.00"));

                crystalReportSR.SetParameterValue("TotHsAmtGST28", GST28_Scm.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotHsAmtGST18", GST18_Scm.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotHsAmtGST12", GST12_Scm.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotHsAmtGST5", GST5_Scm.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotHsAmtGSTFree", GST0_Scm.ToString("0.00"));

                crystalReportSR.SetParameterValue("TotDisGST28", GST28_DisAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotDisGST18", GST18_DisAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotDisGST12", GST12_DisAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotDisGST5", GST5_DisAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotDisGSTFree", GST0_DisAmt.ToString("0.00"));


                crystalReportSR.SetParameterValue("TaxableGST28", GST28_Taxable.ToString("0.00"));
                crystalReportSR.SetParameterValue("TaxableGST18", GST18_Taxable.ToString("0.00"));
                crystalReportSR.SetParameterValue("TaxableGST12", GST12_Taxable.ToString("0.00"));
                crystalReportSR.SetParameterValue("TaxableGST5", GST5_Taxable.ToString("0.00"));
                crystalReportSR.SetParameterValue("TaxableGSTFree", GST0_Taxable.ToString("0.00"));


                crystalReportSR.SetParameterValue("TotCGST28", GST28_CGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotCGST18", GST18_CGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotCGST12", GST12_CGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotCGST5", GST5_CGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotCGSTFree", GST0_CGSTAmt.ToString("0.00"));


                crystalReportSR.SetParameterValue("TotSGST28", GST28_CGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotSGST18", GST18_CGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotSGST12", GST12_CGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotSGST5", GST5_CGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotSGSTFree", GST0_CGSTAmt.ToString("0.00"));


                crystalReportSR.SetParameterValue("TotIGST28", GST28_IGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotIGST18", GST18_IGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotIGST12", GST12_IGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotIGST5", GST5_IGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("TotIGSTFree", GST0_IGSTAmt.ToString("0.00"));


                crystalReportSR.SetParameterValue("T_GrossAmt", T_GrossAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("T_Scm", T_Scm.ToString("0.00"));
                crystalReportSR.SetParameterValue("T_DisAmt", T_DisAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("T_Taxable", T_Taxable.ToString("0.00"));
                crystalReportSR.SetParameterValue("T_CGSTAmt", T_CGSTAmt.ToString("0.00"));
                crystalReportSR.SetParameterValue("T_IGSTAmt", T_IGSTAmt.ToString("0.00"));

                crystalReportSR.SetParameterValue("NoOfItems", DTForInvoice.Rows.Count);

                string QRy1 = "select acno,vdt, Vno,vtype, amt, dc, narr  from Trn where Vno='" + NoID + "' AND Acno='" + VnoID + "'";
                DataSet DSP1 = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, QRy1);
                if (DSP1.Tables[0].Rows.Count > 0)
                {
                    crystalReportSR.SetParameterValue("BillAmount", DSP1.Tables[0].Rows[0]["amt"].ToString());
                    crystalReportSR.SetParameterValue("For", DTControl11.Rows[0]["Compname1"].ToString());
                    crystalReportSR.SetParameterValue("Towards1", AmountInWord(DSP1.Tables[0].Rows[0]["amt"].ToString()));
                }

                #endregion
                CrystalReportViewer1.ReportSource = crystalReportSR;
                string FilePathBE = Server.MapPath("~/CryRpts/" + "Invoice-" + NoID + ".pdf");
                crystalReportSR.ExportToDisk(ExportFormatType.PortableDocFormat, FilePathBE);
                List<string> SRFileList = new List<string>();
                SRFileList.Add(FilePathBE);

                crystalReportSR.Dispose();
            }
        }

        #endregion

    }

    private DataTable GetCompany()
    {
        DataTable DTCompany = new DataTable();
        try
        {
            string Qry = "SELECT * FROM Control";
            DataSet DSData = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (DSData.Tables[0].Rows.Count > 0)
                DTCompany = DSData.Tables[0];
        }
        catch (Exception ex)
        {

        }
        return DTCompany;
    }
    private DataTable GetCustomer(int CustID)
    {
        DataTable DTCust = new DataTable();
        try
        {
            string Qry = "SELECT * FROM Acm WHERE code='" + CustID + "'";
            DataSet DSData = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, Qry);
            if (DSData.Tables[0].Rows.Count > 0)
                DTCust = DSData.Tables[0];
        }
        catch (Exception ex)
        {

        }
        return DTCust;
    }
    private string AmountInWord(string p)
    {
        string isNegative = "";
        string number = Convert.ToDouble(p).ToString();

        if (number.Contains("-"))
        {
            isNegative = "Minus ";
            number = number.Substring(1, number.Length - 1);
        }
        if (number == "0")
        {
            return ("Zero Only");
        }
        else
        {
            return (isNegative + ConvertToWords(number));
        }
    }

    private static String ConvertToWords(String numb)
    {
        String val = "", wholeNo = numb, points = "", andStr = "", pointStr = "";
        String endStr = "Only";
        try
        {
            int decimalPlace = numb.IndexOf(".");
            if (decimalPlace > 0)
            {
                wholeNo = numb.Substring(0, decimalPlace);
                points = numb.Substring(decimalPlace + 1);
                if (Convert.ToInt32(points) > 0)
                {
                    andStr = "and";// just to separate whole numbers from points/cents  
                    endStr = "Paisa " + endStr;//Cents  
                    pointStr = ConvertDecimals(points);
                }
            }
            val = String.Format("{0} {1}{2} {3}", ConvertWholeNumber(wholeNo).Trim(), andStr, pointStr, endStr);
        }
        catch { }
        return val;
    }
    private static String ConvertWholeNumber(String Number)
    {
        string word = "";
        try
        {
            bool beginsZero = false;//tests for 0XX
            bool isDone = false;//test if already translated
            double dblAmt = (Convert.ToDouble(Number));
            //if ((dblAmt > 0) && number.StartsWith("0"))
            if (dblAmt > 0)
            {//test for zero or digit zero in a nuemric
                beginsZero = Number.StartsWith("0");

                int numDigits = Number.Length;
                int pos = 0;//store digit grouping
                String place = "";//digit grouping name:hundres,thousand,etc...
                switch (numDigits)
                {
                    case 1://ones' range

                        word = ones(Number);
                        isDone = true;
                        break;
                    case 2://tens' range
                        word = tens(Number);
                        isDone = true;
                        break;
                    case 3://hundreds' range
                        pos = (numDigits % 3) + 1;
                        place = " Hundred ";
                        break;
                    case 4://thousands' range
                    case 5:
                    case 6:
                        pos = (numDigits % 4) + 1;
                        place = " Thousand ";
                        break;
                    case 7://millions' range
                    case 8:
                    case 9:
                        pos = (numDigits % 7) + 1;
                        place = " Million ";
                        break;
                    case 10://Billions's range
                    case 11:
                    case 12:

                        pos = (numDigits % 10) + 1;
                        place = " Billion ";
                        break;
                    //add extra case options for anything above Billion...
                    default:
                        isDone = true;
                        break;
                }
                if (!isDone)
                {//if transalation is not done, continue...(Recursion comes in now!!)
                    if (Number.Substring(0, pos) != "0" && Number.Substring(pos) != "0")
                    {
                        try
                        {
                            word = ConvertWholeNumber(Number.Substring(0, pos)) + place + ConvertWholeNumber(Number.Substring(pos));
                        }
                        catch { }
                    }
                    else
                    {
                        word = ConvertWholeNumber(Number.Substring(0, pos)) + ConvertWholeNumber(Number.Substring(pos));
                    }

                    //check for trailing zeros
                    //if (beginsZero) word = " and " + word.Trim();
                }
                //ignore digit grouping names
                if (word.Trim().Equals(place.Trim())) word = "";
            }
        }
        catch { }
        return word.Trim();
    }
    private static String tens(String Number)
    {
        int _Number = Convert.ToInt32(Number);
        String name = null;
        switch (_Number)
        {
            case 10:
                name = "Ten";
                break;
            case 11:
                name = "Eleven";
                break;
            case 12:
                name = "Twelve";
                break;
            case 13:
                name = "Thirteen";
                break;
            case 14:
                name = "Fourteen";
                break;
            case 15:
                name = "Fifteen";
                break;
            case 16:
                name = "Sixteen";
                break;
            case 17:
                name = "Seventeen";
                break;
            case 18:
                name = "Eighteen";
                break;
            case 19:
                name = "Nineteen";
                break;
            case 20:
                name = "Twenty";
                break;
            case 30:
                name = "Thirty";
                break;
            case 40:
                name = "Fourty";
                break;
            case 50:
                name = "Fifty";
                break;
            case 60:
                name = "Sixty";
                break;
            case 70:
                name = "Seventy";
                break;
            case 80:
                name = "Eighty";
                break;
            case 90:
                name = "Ninety";
                break;
            default:
                if (_Number > 0)
                {
                    name = tens(Number.Substring(0, 1) + "0") + " " + ones(Number.Substring(1));
                }
                break;
        }
        return name;
    }
    private static String ones(String Number)
    {
        int _Number = Convert.ToInt32(Number);
        String name = "";
        switch (_Number)
        {

            case 1:
                name = "One";
                break;
            case 2:
                name = "Two";
                break;
            case 3:
                name = "Three";
                break;
            case 4:
                name = "Four";
                break;
            case 5:
                name = "Five";
                break;
            case 6:
                name = "Six";
                break;
            case 7:
                name = "Seven";
                break;
            case 8:
                name = "Eight";
                break;
            case 9:
                name = "Nine";
                break;
        }
        return name;
    }
    private static String ConvertDecimals(String number)
    {
        String cd = "", digit = "", engOne = "";
        for (int i = 0; i < number.Length; i++)
        {
            digit = number[i].ToString();
            if (digit.Equals("0"))
            {
                engOne = "Zero";
            }
            else
            {
                engOne = ones(digit);
            }
            cd += " " + engOne;
        }
        return cd;
    }
}