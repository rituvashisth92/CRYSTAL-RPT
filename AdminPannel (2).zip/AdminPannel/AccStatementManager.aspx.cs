﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.ApplicationBlocks.Data;

public partial class AdminPannel_AccStatementManager : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        fetchjob();
    }

    public void fetchjob()
    {
        string query = "select job_id,name,date_created,date_modified,enabled,CASE  enabled WHEN 1 THEN 'ENABLED' else 'DISABLED'END AS Status from msdb.dbo.sysjobs order by date_created desc";
        DataSet jds = SqlHelper.ExecuteDataset(Connection.connects(), CommandType.Text, query);
        gvjob.DataSource = jds.Tables[0];
        gvjob.DataBind();
    }
}